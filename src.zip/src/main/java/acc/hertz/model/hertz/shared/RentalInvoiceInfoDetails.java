package acc.hertz.model.hertz.shared;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RentalInvoiceInfoDetails {

    @JsonProperty("PartnerCode")
    private String partnerCode;

    @JsonProperty("VendorName")
    private String vendorName;

    @JsonProperty("VendorOfficeId")
    private String vendorOfficeId;

    @JsonProperty("VendorOfficeName")
    private String vendorOfficeName;

    @JsonProperty("VendorOfficeStreet1")
    private String vendorOfficeStreet1;

    @JsonProperty("VendorOfficeStreet2")
    private String vendorOfficeStreet2;

    @JsonProperty("VendorOfficeCity")
    private String vendorOfficeCity;

    @JsonProperty("VendorOfficeStateId")
    private String vendorOfficeStateId;

    @JsonProperty("VendorOfficeState")
    private String vendorOfficeState;

    @JsonProperty("VendorOfficeZip")
    private String vendorOfficeZip;

    @JsonProperty("VendorOfficePhone")
    private String vendorOfficePhone;

    @JsonProperty("ContractId")
    private String contractId;

    @JsonProperty("ContractStatus")
    private String contractStatus;

    @JsonProperty("NoteSend")
    private String noteSend;

    @JsonProperty("PickupDate")
    private String pickupDate;

    @JsonProperty("RatePerDayAmount")
    private double ratePerDayAmount;

    @JsonProperty("StartDate")
    private String startDate;

    @JsonProperty("ExpReturnDate")
    private String expReturnDate;

    @JsonProperty("EndDate")
    private String endDate;

    @JsonProperty("RateClass")
    private String rateClass;

    @JsonProperty("VehicleClass")
    private String vehicleClass;

    @JsonProperty("programType")//"Typo made on purpose to support payload received"
    private String programType;

    @JsonProperty("VehicleColor")
    private String vehicleColor;

    @JsonProperty("VehicleId")
    private String vehicleId;

    @JsonProperty("VehicleMake")
    private String vehicleMake;

    @JsonProperty("VehicleModel")
    private String vehicleModel;

    @JsonProperty("VehicleYear")
    private String vehicleYear;

    @JsonProperty("DriverFirstName")
    private String driverFirstName;

    @JsonProperty("DriverLastName")
    private String driverLastName;

    @JsonProperty("DriverAddress1")
    private String driverAddress1;

    @JsonProperty("DriverAddress2")
    private String driverAddress2;

    @JsonProperty("DriverCity")
    private String driverCity;

    @JsonProperty("DriverState")
    private String driverState;

    @JsonProperty("DriverZip")
    private String driverZip;

    @JsonProperty("DriverBestPhone")
    private String driverBestPhone;

    @JsonProperty("DriverBestPhoneExt")
    private String driverBestPhoneExt;

    @JsonProperty("DriverEmail")
    private String driverEmail;

    @JsonProperty("DriverHomePhone")
    private String driverHomePhone;

    @JsonProperty("DriverHomePhoneExt")
    private String driverHomePhoneExt;

    @JsonProperty("DriverWorkPhone")
    private String driverWorkPhone;

    @JsonProperty("DriverWorkPhoneExt")
    private String driverWorkPhoneExt;

    // Getters and setters

    public String getPartnerCode() { return partnerCode; }

    public void setPartnerCode(String partnerCode) { this.partnerCode = partnerCode; }

    public String getVendorName() { return vendorName; }

    public void setVendorName(String vendorName) { this.vendorName = vendorName; }

    public String getVendorOfficeId() { return vendorOfficeId; }

    public void setVendorOfficeId(String vendorOfficeId) { this.vendorOfficeId = vendorOfficeId; }

    public String getVendorOfficeName() { return vendorOfficeName; }

    public void setVendorOfficeName(String vendorOfficeName) { this.vendorOfficeName = vendorOfficeName; }

    public String getVendorOfficeStreet1() { return vendorOfficeStreet1; }

    public void setVendorOfficeStreet1(String vendorOfficeStreet1) { this.vendorOfficeStreet1 = vendorOfficeStreet1; }

    public String getVendorOfficeStreet2() { return vendorOfficeStreet2; }

    public void setVendorOfficeStreet2(String vendorOfficeStreet2) { this.vendorOfficeStreet2 = vendorOfficeStreet2; }

    public String getVendorOfficeCity() { return vendorOfficeCity; }

    public void setVendorOfficeCity(String vendorOfficeCity) { this.vendorOfficeCity = vendorOfficeCity; }

    public String getVendorOfficeStateId() { return vendorOfficeStateId; }

    public void setVendorOfficeStateId(String vendorOfficeStateId) { this.vendorOfficeStateId = vendorOfficeStateId; }

    public String getVendorOfficeState() { return vendorOfficeState; }

    public void setVendorOfficeState(String vendorOfficeState) { this.vendorOfficeState = vendorOfficeState; }

    public String getVendorOfficeZip() { return vendorOfficeZip; }

    public void setVendorOfficeZip(String vendorOfficeZip) { this.vendorOfficeZip = vendorOfficeZip; }

    public String getVendorOfficePhone() { return vendorOfficePhone; }

    public void setVendorOfficePhone(String vendorOfficePhone) { this.vendorOfficePhone = vendorOfficePhone; }

    public String getContractId() { return contractId; }

    public void setContractId(String contractId) { this.contractId = contractId; }

    public String getContractStatus() { return contractStatus; }

    public void setContractStatus(String contractStatus) { this.contractStatus = contractStatus; }

    public String getNoteSend() { return noteSend; }

    public void setNoteSend(String noteSend) { this.noteSend = noteSend; }

    public String getPickupDate() { return pickupDate; }

    public void setPickupDate(String pickupDate) { this.pickupDate = pickupDate; }

    public double getRatePerDayAmount() { return ratePerDayAmount; }

    public void setRatePerDayAmount(double ratePerDayAmount) { this.ratePerDayAmount = ratePerDayAmount; }

    public String getStartDate() { return startDate; }

    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getExpReturnDate() { return expReturnDate; }

    public void setExpReturnDate(String expReturnDate) { this.expReturnDate = expReturnDate; }

    public String getEndDate() { return endDate; }

    public void setEndDate(String endDate) { this.endDate = endDate; }

    public String getRateClass() { return rateClass; }

    public void setRateClass(String rateClass) { this.rateClass = rateClass; }

    public String getVehicleClass() { return vehicleClass; }

    public void setVehicleClass(String vehicleClass) { this.vehicleClass = vehicleClass; }

    public String getProgramType() { return programType; }

    public void setProgramType(String programType) { this.programType = programType; }

    public String getVehicleColor() { return vehicleColor; }

    public void setVehicleColor(String vehicleColor) { this.vehicleColor = vehicleColor; }

    public String getVehicleId() { return vehicleId; }

    public void setVehicleId(String vehicleId) { this.vehicleId = vehicleId; }

    public String getVehicleMake() { return vehicleMake; }

    public void setVehicleMake(String vehicleMake) { this.vehicleMake = vehicleMake; }

    public String getVehicleModel() { return vehicleModel; }

    public void setVehicleModel(String vehicleModel) { this.vehicleModel = vehicleModel; }

    public String getVehicleYear() { return vehicleYear; }

    public void setVehicleYear(String vehicleYear) { this.vehicleYear = vehicleYear; }

    public String getDriverFirstName() { return driverFirstName; }

    public void setDriverFirstName(String driverFirstName) { this.driverFirstName = driverFirstName; }

    public String getDriverLastName() { return driverLastName; }

    public void setDriverLastName(String driverLastName) { this.driverLastName = driverLastName; }

    public String getDriverAddress1() { return driverAddress1; }

    public void setDriverAddress1(String driverAddress1) { this.driverAddress1 = driverAddress1; }

    public String getDriverAddress2() { return driverAddress2; }

    public void setDriverAddress2(String driverAddress2) { this.driverAddress2 = driverAddress2; }

    public String getDriverCity() { return driverCity; }

    public void setDriverCity(String driverCity) { this.driverCity = driverCity; }

    public String getDriverState() { return driverState; }

    public void setDriverState(String driverState) { this.driverState = driverState; }

    public String getDriverZip() { return driverZip; }

    public void setDriverZip(String driverZip) { this.driverZip = driverZip; }

    public String getDriverBestPhone() { return driverBestPhone; }

    public void setDriverBestPhone(String driverBestPhone) { this.driverBestPhone = driverBestPhone; }

    public String getDriverBestPhoneExt() { return driverBestPhoneExt; }

    public void setDriverBestPhoneExt(String driverBestPhoneExt) { this.driverBestPhoneExt = driverBestPhoneExt; }

    public String getDriverEmail() { return driverEmail; }

    public void setDriverEmail(String driverEmail) { this.driverEmail = driverEmail; }

    public String getDriverHomePhone() { return driverHomePhone; }

    public void setDriverHomePhone(String driverHomePhone) { this.driverHomePhone = driverHomePhone; }

    public String getDriverHomePhoneExt() { return driverHomePhoneExt; }

    public void setDriverHomePhoneExt(String driverHomePhoneExt) { this.driverHomePhoneExt = driverHomePhoneExt; }

    public String getDriverWorkPhone() { return driverWorkPhone; }

    public void setDriverWorkPhone(String driverWorkPhone) { this.driverWorkPhone = driverWorkPhone; }

    public String getDriverWorkPhoneExt() { return driverWorkPhoneExt; }

    public void setDriverWorkPhoneExt(String driverWorkPhoneExt) { this.driverWorkPhoneExt = driverWorkPhoneExt; }
}
