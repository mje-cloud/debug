package acc.hertz.model.hertz.outbound;

public class HertzAPIException extends Exception {

    private int code;
    private String message;

    public HertzAPIException(int code,String message) {
        this.code = code;
        this.message=message;
    }

    public String toString(){
        return "Code " + code + " Message " + message;
    }
}
