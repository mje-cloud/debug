package acc.hertz.client.service;


import acc.hertz.model.cloudapi.documents.CreateDocument;
import acc.hertz.model.cloudapi.documents.DocumentResponse;
import org.apache.camel.Exchange;

public interface IDocumentClient {
    DocumentResponse getDocument(Exchange exchange, String stickySessionToken, String claimPublicId , String type, String name) throws Exception;
    boolean createDocument(Exchange exchange,String stickySessionToken, String claimPublicId, String invoiceNumber, byte[] byteArrayDocument, CreateDocument createDocument) throws Exception;
}
