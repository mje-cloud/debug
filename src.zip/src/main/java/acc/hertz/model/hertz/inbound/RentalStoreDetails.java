package acc.hertz.model.hertz.inbound;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RentalStoreDetails {

    @JsonProperty("vendorDistance")
    private double vendorDistance;

    @JsonProperty("vendorServiceRadius")
    private int vendorServiceRadius;

    @JsonProperty("vendorOfficeId")
    private String vendorOfficeId;

    @JsonProperty("vendorOfficeName")
    private String vendorOfficeName;

    @JsonProperty("vendorOfficeStreet1")
    private String vendorOfficeStreet1;

    @JsonProperty("vendorOfficeStreet2")
    private String vendorOfficeStreet2;  // Nullable

    @JsonProperty("vendorOfficeCity")
    private String vendorOfficeCity;

    @JsonProperty("vendorOfficeStateId")
    private String vendorOfficeStateId;

    @JsonProperty("vendorOfficeZip")
    private String vendorOfficeZip;

    @JsonProperty("vendorOfficePhone")
    private String vendorOfficePhone;

    @JsonProperty("vendorOfficePhoneExt")
    private String vendorOfficePhoneExt;  // Nullable

    @JsonProperty("vendorOfficeHours")
    private String vendorOfficeHours;

    @JsonProperty("vendorOfficeServices")
    private String vendorOfficeServices;

    @JsonProperty("rentalRates")
    private List<RentalRateDetails> rentalRates;

    // Getters and Setters
    public double getVendorDistance() {
        return vendorDistance;
    }

    public void setVendorDistance(double vendorDistance) {
        this.vendorDistance = vendorDistance;
    }

    public int getVendorServiceRadius() {
        return vendorServiceRadius;
    }

    public void setVendorServiceRadius(int vendorServiceRadius) {
        this.vendorServiceRadius = vendorServiceRadius;
    }

    public String getVendorOfficeId() {
        return vendorOfficeId;
    }

    public void setVendorOfficeId(String vendorOfficeId) {
        this.vendorOfficeId = vendorOfficeId;
    }

    public String getVendorOfficeName() {
        return vendorOfficeName;
    }

    public void setVendorOfficeName(String vendorOfficeName) {
        this.vendorOfficeName = vendorOfficeName;
    }

    public String getVendorOfficeStreet1() {
        return vendorOfficeStreet1;
    }

    public void setVendorOfficeStreet1(String vendorOfficeStreet1) {
        this.vendorOfficeStreet1 = vendorOfficeStreet1;
    }

    public String getVendorOfficeStreet2() {
        return vendorOfficeStreet2;
    }

    public void setVendorOfficeStreet2(String vendorOfficeStreet2) {
        this.vendorOfficeStreet2 = vendorOfficeStreet2;
    }

    public String getVendorOfficeCity() {
        return vendorOfficeCity;
    }

    public void setVendorOfficeCity(String vendorOfficeCity) {
        this.vendorOfficeCity = vendorOfficeCity;
    }

    public String getVendorOfficeStateId() {
        return vendorOfficeStateId;
    }

    public void setVendorOfficeStateId(String vendorOfficeStateId) {
        this.vendorOfficeStateId = vendorOfficeStateId;
    }

    public String getVendorOfficeZip() {
        return vendorOfficeZip;
    }

    public void setVendorOfficeZip(String vendorOfficeZip) {
        this.vendorOfficeZip = vendorOfficeZip;
    }

    public String getVendorOfficePhone() {
        return vendorOfficePhone;
    }

    public void setVendorOfficePhone(String vendorOfficePhone) {
        this.vendorOfficePhone = vendorOfficePhone;
    }

    public String getVendorOfficePhoneExt() {
        return vendorOfficePhoneExt;
    }

    public void setVendorOfficePhoneExt(String vendorOfficePhoneExt) {
        this.vendorOfficePhoneExt = vendorOfficePhoneExt;
    }

    public String getVendorOfficeHours() {
        return vendorOfficeHours;
    }

    public void setVendorOfficeHours(String vendorOfficeHours) {
        this.vendorOfficeHours = vendorOfficeHours;
    }

    public String getVendorOfficeServices() {
        return vendorOfficeServices;
    }

    public void setVendorOfficeServices(String vendorOfficeServices) {
        this.vendorOfficeServices = vendorOfficeServices;
    }

    public List<RentalRateDetails> getRentalRates() {
        return rentalRates;
    }

    public void setRentalRates(List<RentalRateDetails> rentalRates) {
        this.rentalRates = rentalRates;
    }
}
