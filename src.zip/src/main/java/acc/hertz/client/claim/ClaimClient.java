package acc.hertz.client.claim;

import acc.hertz.client.core.IClient;
import acc.hertz.client.core.WebMethodType;
import acc.hertz.client.service.IClaimClient;
import acc.hertz.model.activitypattern.ActivityPost;
import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.claim.ClaimInfo;
import acc.hertz.model.cloudapi.claim.User;
import acc.hertz.model.cloudapi.contact.ClaimContactData;
import acc.hertz.model.cloudapi.contact.ClaimContactPost;
import acc.hertz.model.cloudapi.contact.VendorContactData;
import acc.hertz.model.cloudapi.servicerequest.*;
import acc.hertz.model.cloudapi.typelist.TypeLists;
import acc.hertz.model.enums.Filter;
import acc.hertz.model.enums.MimeType;
import acc.hertz.model.enums.RestRelopType;
import acc.hertz.model.response.IResponseHandler;
import acc.hertz.security.IServerSelector;
import acc.hertz.security.LocalServer;
import acc.hertz.security.authorization.AuthorizationType;
import acc.hertz.util.AppUtils;
import acc.hertz.util.GenericJSONTransformer;
import gw.api.ig.GwUtilities;
import gw.api.ig.logging.GwLogger;
import org.apache.camel.Exchange;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.commons.codec.binary.Base64;

import static acc.hertz.util.AppUtils.*;


@Named
public class ClaimClient implements IClaimClient {
    private static final Logger _log = LoggerFactory.getLogger(ClaimClient.class);
    @Inject
    private IResponseHandler IResponseHandler;
    @Inject
    private IClient client;

    @Inject
    private IServerSelector serverSelector;
    private final GenericJSONTransformer<TypeLists> typeListsTransformer = new GenericJSONTransformer<>(TypeLists.class);
    private final GenericJSONTransformer<ClaimInfo> claimInfoTransformer = new GenericJSONTransformer<>(ClaimInfo.class);
    private final GenericJSONTransformer<ClaimData> claimDataTransformer = new GenericJSONTransformer<>(ClaimData.class);
    private final GenericJSONTransformer<ServiceRequestList> serviceRequestTransformer = new GenericJSONTransformer<>(ServiceRequestList.class);
    private final GenericJSONTransformer<ClaimContactData> claimContactDataTransformer = new GenericJSONTransformer<>(ClaimContactData.class);
    private final GenericJSONTransformer<ClaimContactPost> claimContactPostTransformer = new GenericJSONTransformer<>(ClaimContactPost.class);
    private final GenericJSONTransformer<User> userTransformer = new GenericJSONTransformer<>(User.class);
    private final GenericJSONTransformer<ServiceRequestPatch> serviceRequestPatchTransformer = new GenericJSONTransformer<>(ServiceRequestPatch.class);
    private final GenericJSONTransformer<ServiceRequestPost> serviceRequestPostTransformer = new GenericJSONTransformer<>(ServiceRequestPost.class);
    private final GenericJSONTransformer<ServiceRequestAccepted> serviceRequestAcceptedTransformer = new GenericJSONTransformer<>(ServiceRequestAccepted.class);
    private final GenericJSONTransformer<ServiceRequestPostResponse> serviceResponsePostTransformer = new GenericJSONTransformer<>(ServiceRequestPostResponse.class);
    private final GenericJSONTransformer<ActivityPost> activityPostTransformer = new GenericJSONTransformer<>(ActivityPost.class);
    private final GenericJSONTransformer<ServiceRequestCancel> serviceRequestCancelTransformer = new GenericJSONTransformer<>(ServiceRequestCancel.class);
    private final GenericJSONTransformer<ServiceRequestInvoice> serviceRequestInvoiceTransformer = new GenericJSONTransformer<>(ServiceRequestInvoice.class);
    private final GenericJSONTransformer<ServiceRequestDecline> serviceRequestDeclineTransformer = new GenericJSONTransformer<>(ServiceRequestDecline.class);
    private final GenericJSONTransformer<VendorContactData> vendorContactDataTransformer = new GenericJSONTransformer<>(VendorContactData.class);


    public ClaimClient() {

    }

    public ServiceRequestInvoice addServiceRequestInvoice(String stickySessionToken,ClaimData claim, ServiceRequestList.ServiceRequest currentService, ServiceRequestInvoice serviceRequestInvoice
    ) throws Exception {
        try {
            String server = serverSelector.getServer();
            String url = AppUtils.CLOUD_API_SERVICE_REQUEST_INVOICE_POST.replace("$1", claim.getData().getAttributes().getId())
                    .replace("$2", currentService.getAttributes().getId());
            String bodyToPost = serviceRequestInvoiceTransformer.toJson(serviceRequestInvoice);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.doExecute(server + url, bodyToPost, WebMethodType.POST, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                return serviceRequestInvoiceTransformer.fromJson(AppUtils.sanitize(client.getResponseBody()));
            } else {
                throw new Exception(client.getResponseBody());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    public ServiceRequestPostResponse draftServiceRequest(ClaimData claim, ServiceRequestPost serviceRequestPost) throws Exception {
        try {
            String server = serverSelector.getServer();
            String url = AppUtils.CLOUD_API_SERVICE_REQUEST_POST.replace("$1", claim.getData().getAttributes().getId());
            String bodyToPost = serviceRequestPostTransformer.toJson(serviceRequestPost);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.doExecute(server + url, bodyToPost, WebMethodType.POST, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                return serviceResponsePostTransformer.fromJson(AppUtils.sanitize(client.getResponseBody()));
            } else {
                throw new Exception(client.getResponseBody());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    public ServiceRequestPostResponse submitServiceRequest(final String stickySessionToken,ClaimData claim, String serviceRequestId) throws Exception {
        try {
            String server = serverSelector.getServer();
            String url = CLOUD_API_SERVICE_REQUEST_SUBMIT.replace("$1", claim.getData().getAttributes().getId()).replace("$2", serviceRequestId);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.doExecute(server + url, null, WebMethodType.POST, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                return serviceResponsePostTransformer.fromJson(AppUtils.sanitize(client.getResponseBody()));
            } else {
                throw new Exception(client.getResponseBody());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    public ServiceRequestPostResponse cancelServiceRequest(ClaimData claim, String serviceRequestId, ServiceRequestCancel serviceRequestCancel) throws Exception {
        try {
            String server = serverSelector.getServer();
            String bodyToPost = serviceRequestCancelTransformer.toJson(serviceRequestCancel);
            String url = CLOUD_API_SERVICE_REQUEST_CANCEL.replace("$1", claim.getData().getAttributes().getId()).replace("$2", serviceRequestId);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.doExecute(server + url, bodyToPost, WebMethodType.POST, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                return serviceResponsePostTransformer.fromJson(AppUtils.sanitize(client.getResponseBody()));
            } else {
                throw new Exception(client.getResponseBody());
            }
        } catch (Exception e) {
            throw e;
        }
    }


    public ServiceRequestPostResponse declineServiceRequest(String stickySessionToken,ClaimData claim, String serviceRequestId, ServiceRequestDecline serviceRequestDecline) throws Exception {
        try {
            String server = serverSelector.getServer();
            String bodyToPost = serviceRequestDeclineTransformer.toJson(serviceRequestDecline);
            String url = CLOUD_API_SERVICE_REQUEST_DECLINE.replace("$1", claim.getData().getAttributes().getId()).replace("$2", serviceRequestId);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
             client.doExecute(server + url, bodyToPost, WebMethodType.POST, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                return serviceResponsePostTransformer.fromJson(AppUtils.sanitize(client.getResponseBody()));
            } else {
                throw new Exception(client.getResponseBody());
            }
        } catch (Exception e) {
            throw e;
        }
    }


    public ServiceRequestPostResponse workCompletedServiceRequest(final String stickySessionToken,ClaimData claim, String serviceRequestId) throws Exception {
        try {
            String server = serverSelector.getServer();
            String url = CLOUD_API_SERVICE_REQUEST_WORK_COMPLETED.replace("$1", claim.getData().getAttributes().getId()).replace("$2", serviceRequestId);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.doExecute(server + url, null, WebMethodType.POST, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                return serviceResponsePostTransformer.fromJson(AppUtils.sanitize(client.getResponseBody()));
            } else {
                throw new Exception(client.getResponseBody());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    public ServiceRequestPostResponse acceptServiceRequest(final String stickySessionToken,ClaimData claim, String serviceRequestId, ServiceRequestAccepted serviceRequestPost) throws Exception {
        try {
            String server = serverSelector.getServer();
            String url = CLOUD_API_SERVICE_REQUEST_ACCEPT.replace("$1", claim.getData().getAttributes().getId()).replace("$2", serviceRequestId);
            String bodyToPost = serviceRequestAcceptedTransformer.toJson(serviceRequestPost);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.addHeaderParameter("x-gwre-session", claim.getData().getAttributes().getId());
            client.doExecute(server + url, bodyToPost, WebMethodType.POST, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                return serviceResponsePostTransformer.fromJson(AppUtils.sanitize(client.getResponseBody()));
            } else {
                throw new Exception(client.getResponseBody());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    public ServiceRequestPostResponse patchServiceRequest(ClaimData claim, ServiceRequestList.ServiceRequest currentServiceRequest, ServiceRequestPost serviceRequestPost) throws Exception {
        try {
            String server = serverSelector.getServer();
            String url = AppUtils.CLOUD_API_SERVICE_REQUEST_PATCH.replace("$1", claim.getData().getAttributes().getId()).replace("$2", currentServiceRequest.getAttributes().getId());
            String bodyToPatch = serviceRequestPostTransformer.toJson(serviceRequestPost);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.addHeaderParameter("x-gwre-session", claim.getData().getAttributes().getId());
             client.doExecute(server + url, bodyToPatch, WebMethodType.PATCH, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                return serviceResponsePostTransformer.fromJson(AppUtils.sanitize(client.getResponseBody()));
            } else {
                throw new Exception(client.getResponseBody());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    public boolean postActivityWarning(ClaimData claim, ActivityPost body) throws Exception {
        try {
            String server = serverSelector.getServer();
            String url = AppUtils.CLAIM_POST_ACTIVITIES.replace("$1", claim.getData().getAttributes().getId());
            String bodyToPost = activityPostTransformer.toJson(body);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
           client.doExecute(server + url, bodyToPost, WebMethodType.POST, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                return true;
            } else {
                throw new Exception(AppUtils.sanitize(client.getResponseBody()));
            }
        } catch (Exception e) {
            throw e;
        }
    }

    public boolean addInvoiceServiceRequest(final String stickySessionToken,ClaimData claim, ServiceRequestList.ServiceRequest serviceRequest, ServiceRequestPatch serviceRequestPatch) throws Exception {
        try {
            String server = serverSelector.getServer();
            String url = AppUtils.CLOUD_API_SERVICE_REQUEST_PATCH.replace("$1", claim.getData().getAttributes().getId()).replace("$2", serviceRequest.getAttributes().getId());
            String bodyToPost = serviceRequestPatchTransformer.toJson(serviceRequestPatch);
            client.clearHeaders();
            client.addHeaderParameter(AppUtils.API_X_GWRE_SESSION, stickySessionToken);
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.doExecute(server + url, bodyToPost, WebMethodType.PATCH, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
               return true;
            } else {
                throw new Exception(AppUtils.sanitize(client.getResponseBody()));
            }
        } catch (Exception e) {
            throw e;
        }
    }

    public User getUserAssigned(String userId) throws Exception {
        String server = serverSelector.getServer();
        client.clearHeaders();
        client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
        String url = server + CLOUD_API_ASSIGNED_USER_REQUEST_GET.replace("$1", userId);
        client.doExecute(url, WebMethodType.GET, AuthorizationType.CLOUD_DETAILED_ACCESS);
        if (client.isSuccessExecuted()) {
            String jsonResponse = AppUtils.sanitize(client.getResponseBody());
            User user = userTransformer.fromJson(jsonResponse);
            return user;
        }
        return null;
    }

    public ClaimContactData getClaimContact(String claimId, String claimContactId) throws Exception {
        String server = serverSelector.getServer();
        client.clearHeaders();
        client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
        String url = server + CLOUD_API_CLAIM_CONTACT_REQUEST_GET.replace("$1", claimId).replace("$2", claimContactId);
        client.doExecute(url, WebMethodType.GET, AuthorizationType.CLOUD_DETAILED_ACCESS);
        if (client.isSuccessExecuted()) {
            String jsonResponse = AppUtils.sanitize(client.getResponseBody());
            ClaimContactData claimContactData = claimContactDataTransformer.fromJson(AppUtils.sanitize(jsonResponse));
            return claimContactData;
        }
        return null;
    }

    public ServiceRequestList getServiceRequestData(String claimId) throws Exception {
        String server = serverSelector.getServer();
        client.clearHeaders();
        client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
        String url = server + CLOUD_API_SERVICE_REQUEST_GET.replace("$1", claimId);
        client.doExecute(url, WebMethodType.GET, AuthorizationType.CLOUD_DETAILED_ACCESS);
        if (client.isSuccessExecuted()) {
            String jsonResponse = AppUtils.sanitize(client.getResponseBody());
            ServiceRequestList serviceRequest = serviceRequestTransformer.fromJson(AppUtils.sanitize(jsonResponse));
            return serviceRequest;
        } else
            throw new Exception("ReservationAppEventProcessor - Response ServiceRequest: " + client.getResponseCode() + " - " +AppUtils.sanitize( client.getResponseBody()));

    }

    public ServiceRequestList getServiceRequestData(String claimId, String filter) throws Exception {
        String server = serverSelector.getServer();
        client.clearHeaders();
        client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
       String url = server + CLOUD_API_SERVICE_REQUEST_GET.replace("$1", claimId);
        client.doExecute(url + "?" + filter, WebMethodType.GET, AuthorizationType.CLOUD_DETAILED_ACCESS);
        if (client.isSuccessExecuted()) {
            String jsonResponse = AppUtils.sanitize(client.getResponseBody());
            ServiceRequestList serviceRequest = serviceRequestTransformer.fromJson(AppUtils.sanitize(jsonResponse));
            return serviceRequest;
        }
        return null;
    }

    public ClaimInfo getClaimData(Exchange exchange, String claimId, String filter) throws Exception {
        String server = serverSelector.getServer();
        client.setExchange(exchange);
        client.clearHeaders();
        client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
         if (filter != null) {
            client.doExecute(server + CLOUD_API_CLAIMS_GET + "?" + filter, WebMethodType.GET, AuthorizationType.CLOUD_DETAILED_ACCESS);
        } else {
            client.doExecute(server + CLOUD_API_CLAIMS_GET + claimId, WebMethodType.GET, AuthorizationType.NO_AUTHORIZATION_ACCESS);
        }
        if (client.isSuccessExecuted()) {
            ClaimInfo claimInput = claimInfoTransformer.fromJson(AppUtils.sanitize(client.getResponseBody()));
            return claimInput;
        } else {
            throw new Exception(AppUtils.sanitize(client.getResponseBody()));
        }

    }

    public ClaimInfo getClaimByClaimNumber(Exchange exchange, String claimNumber) throws Exception {
        String server = serverSelector.getServer();
        String url = CLOUD_API_CLAIMS_PUBLIC + "?" + Filter.FILTER_KEYWORD.getCode() + RestRelopType.EQUALS.getCode() + Filter.CLAIM_NUMBER.getCode() + RestRelopType.EQ_OPERATOR.getCode() + claimNumber;
        client.setExchange(exchange);
        client.clearHeaders();
        client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
        client.doExecute(server + url, WebMethodType.GET, AuthorizationType.CLOUD_DETAILED_ACCESS);
        if (client.isSuccessExecuted()) {
            ClaimInfo claim = claimInfoTransformer.fromJson(AppUtils.sanitize((client.getResponseBody())));
           return claim;
        } else {
            throw new Exception(AppUtils.sanitize(client.getResponseBody()));
        }
    }


    public ClaimData getClaimData(Exchange exchange, String claimId) throws Exception {
        String filterTags = Filter.INCLUDE_FILTER.getCode() +
                RestRelopType.EQUALS.getCode() +
                Filter.VEHICLE_INCIDENT_EXT.getCode() +
                RestRelopType.COMMA_SEPARATOR.getCode() +
                Filter.POLICY_INCLUDE_EXT.getCode() +
                RestRelopType.COMMA_SEPARATOR.getCode() +
                Filter.CONTACT_INCLUDE_EXT.getCode();
        String server = serverSelector.getServer();
        client.setExchange(exchange);
        client.clearHeaders();
        client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
         client.doExecute(server + CLOUD_API_CLAIMS_GET + claimId + "?" + filterTags, WebMethodType.GET, AuthorizationType.CLOUD_DETAILED_ACCESS);
        if (client.isSuccessExecuted()) {
            String jsonResponse = sanitize(client.getResponseBody());
            ClaimData claimInput = claimDataTransformer.fromJson(AppUtils.sanitize(jsonResponse));
            return claimInput;
        } else {
            throw new Exception(AppUtils.sanitize(client.getResponseBody()));
        }

    }

    @Override
    public ClaimContactData createClaimContact(Exchange exchange, String claimId, ClaimContactPost claimContactData) throws Exception {
        try {
            String server = serverSelector.getServer();
            String url =  CLOUD_API_CLAIM_CONTACT_REQUEST_POST.replace("$1", claimId);
            String bodyToPost = claimContactPostTransformer.toJson(claimContactData);
            client.setExchange(exchange);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.doExecute(server + url, bodyToPost, WebMethodType.POST, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                ClaimContactData response = claimContactDataTransformer.fromJson(AppUtils.sanitize(client.getResponseBody()));
                return response;
            } else {
                throw new Exception(AppUtils.sanitize(client.getResponseBody()));
            }
        } catch (Exception e) {
            throw e;
        }
    }

    @Override
    public ServiceRequestList createServiceRequestData(Exchange exchange, ServiceRequestList serviceRequest, String claimId) throws Exception {
        try {
            String server = serverSelector.getServer();
            String url = AppUtils.CLOUD_API_SERVICE_REQUEST_POST.replace("$1", claimId);
            String bodyToPost = serviceRequestTransformer.toJson(serviceRequest);
            client.setExchange(exchange);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
             client.doExecute(server + url, bodyToPost, WebMethodType.POST, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                return serviceRequestTransformer.fromJson(AppUtils.sanitize(client.getResponseBody()));
            } else {
                throw new Exception(AppUtils.sanitize(client.getResponseBody()));
            }
        } catch (Exception e) {
            throw e;
        }
    }

    @Override
    public TypeLists getTypeListByName(Exchange exchange, String typeListName , String filterValue) throws Exception {
        try {

            String filter= Filter.TYPE_KEY_FILTER_KEYWORD.getCode()+RestRelopType.EQUALS+Filter.TYPE_KEY_CODE+RestRelopType.EQ_OPERATOR+filterValue;
            String server = serverSelector.getServer();
            String url =  AppUtils.CLOUD_API_TYPE_LIST_REQUEST_GET.replace("$1", typeListName);
            client.setExchange(exchange);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.doExecute(server + url + "?" + filter, WebMethodType.GET, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                TypeLists typeList = typeListsTransformer.fromJson(AppUtils.sanitize(client.getResponseBody()));
                return typeList;
            } else {
                throw new Exception(AppUtils.sanitize(client.getResponseBody()));
            }
        } catch (Exception e) {
            throw e;
        }
    }

    public VendorContactData createVendorContact(Exchange exchange, String claimId) throws Exception {
        try {
            String server = serverSelector.getServer();
            String url =  CLOUD_API_CREATE_VENDOR_CONTACT_REQUEST_POST.replace("$1", claimId);
            client.setExchange(exchange);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.doExecute(server + url, WebMethodType.POST, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                VendorContactData response = vendorContactDataTransformer.fromJson(AppUtils.sanitize(client.getResponseBody()));
                return response;
            } else {
                throw new Exception(AppUtils.sanitize(client.getResponseBody()));
            }
        } catch (Exception e) {
            throw e;
        }
    }
}