package acc.hertz.processors.composite.helper;

import acc.hertz.client.core.WebMethodType;
import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.composite.core.AbstractCompositeRequest;
import acc.hertz.model.cloudapi.composite.core.BaseRequest;
import acc.hertz.model.cloudapi.composite.core.RequestVarType;
import acc.hertz.model.cloudapi.composite.core.RequestVars;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestList;
import acc.hertz.model.enums.EntityEventType;
import acc.hertz.processors.composite.CompositeBuilder;
import acc.hertz.processors.composite.helper.payload.ActivityPostComposite;
import acc.hertz.processors.composite.helper.payload.HistoryComposite;
import acc.hertz.processors.composite.helper.payload.ServiceRequestInvoiceComposite;
import acc.hertz.processors.composite.helper.payload.ServiceRequestPatchComposite;
import acc.hertz.util.AppUtils;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.util.ArrayList;
import java.util.List;

@Named
public class CompositeRentalInvoiceHelper {
    @Inject
    private CompositeBuilder compositeBuilder;

    public AbstractCompositeRequest buildCompositeRequest(ClaimData claim,
                                                                 ServiceRequestList.ServiceRequest currentService,
                                                                 ServiceRequestPatchComposite serviceRequestPatch,
                                                                 HistoryComposite history,
                                                                 ActivityPostComposite activity) {

        AbstractCompositeRequest request = new AbstractCompositeRequest();
        request.getRequests().add(createServiceRequestPatch(claim, currentService, serviceRequestPatch));
        request.getRequests().add(createHistoryEntry(history));
        request.getRequests().add(activityCreation(claim, activity));
        return request;
    }

    private BaseRequest createServiceRequestPatch(ClaimData claim, ServiceRequestList.ServiceRequest currentService, ServiceRequestPatchComposite serviceRequestPatch) {
        String url = AppUtils.CLOUD_API_SERVICE_REQUEST_PATCH.replace("$1", claim.getData().getAttributes().getId()).replace("$2", currentService.getAttributes().getId()).replace(AppUtils.COMPOSITE_API_REST_PATH, "/");
        List<RequestVars> vars = new ArrayList<>();
        RequestVars requestVars = compositeBuilder.createVar(RequestVarType.SERVICE_REQUEST_ID.getPath(), RequestVarType.SERVICE_REQUEST_ID.getName());
        vars.add(requestVars);
        var baseRequest = compositeBuilder.getBaseRequest(serviceRequestPatch, url, WebMethodType.PATCH);
        baseRequest.setVars(vars);
        baseRequest.setIncludeResponse(true);
        return baseRequest;
    }

    private BaseRequest createHistoryEntry(HistoryComposite history) {
        String url = AppUtils.CLOUD_API_CREATE_HISTORY_ENTRY.replace(AppUtils.COMPOSITE_API_REST_PATH, "/");
        history.getData().getAttributes().getServiceRequest().setId(RequestVarType.SERVICE_REQUEST_ID.getBuildVarTypeParameter());
        history.getData().getAttributes().getServiceRequest().setType(EntityEventType.SERVICE_REQUEST.getType());
        return compositeBuilder.getBaseRequest(history, url, WebMethodType.POST);
    }

    private BaseRequest activityCreation(ClaimData claim, ActivityPostComposite activity) {
        String url = AppUtils.CLAIM_POST_ACTIVITIES.replace("$1", claim.getData().getAttributes().getId()).replace(AppUtils.COMPOSITE_API_REST_PATH, "/");
        activity.getData().getAttributes().getRelatedTo().setId(RequestVarType.SERVICE_REQUEST_ID.getBuildVarTypeParameter());
        activity.getData().getAttributes().getRelatedTo().setType(EntityEventType.SERVICE_REQUEST.getType());
        return compositeBuilder.getBaseRequest(activity, url, WebMethodType.POST);
    }
}
