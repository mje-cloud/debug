package acc.hertz.model.hertz.inbound;

import acc.hertz.model.hertz.shared.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EditAssignmentRequest {

    @JsonProperty("TransactionRequestHeader")
    private TransactionRequestHeader transactionRequestHeader;

    @JsonProperty("Policy")
    private PolicyDetails policy;

    @JsonProperty("ClaimInfo")
    private ClaimInfoDetails claimInfo;

    @JsonProperty("ClaimOffice")
    private ClaimOfficeDetails claimOffice;

    @JsonProperty("ClaimAdjuster")
    private ClaimAdjusterDetails claimAdjuster;

    @JsonProperty("RentalInfo")
    private RentalInfoDetails rentalInfo;

    @JsonProperty("RepairFacility")
    private RepairFacility repairFacility;

    // Getters and setters

    public TransactionRequestHeader getTransactionRequestHeader() { return transactionRequestHeader; }

    public void setTransactionRequestHeader(TransactionRequestHeader transactionRequestHeader) {
        this.transactionRequestHeader = transactionRequestHeader;
    }

    public PolicyDetails getPolicy() { return policy; }

    public void setPolicy(PolicyDetails policy) { this.policy = policy; }

    public ClaimInfoDetails getClaimInfo() { return claimInfo; }

    public void setClaimInfo(ClaimInfoDetails claimInfo) { this.claimInfo = claimInfo; }

    public ClaimOfficeDetails getClaimOffice() { return claimOffice; }

    public void setClaimOffice(ClaimOfficeDetails claimOffice) { this.claimOffice = claimOffice; }

    public ClaimAdjusterDetails getClaimAdjuster() { return claimAdjuster; }

    public void setClaimAdjuster(ClaimAdjusterDetails claimAdjuster) { this.claimAdjuster = claimAdjuster; }

    public RentalInfoDetails getRentalInfo() { return rentalInfo; }

    public void setRentalInfo(RentalInfoDetails rentalInfo) { this.rentalInfo = rentalInfo; }

    public RepairFacility getRepairFacility() { return repairFacility; }

    public void setRepairFacility(RepairFacility repairFacility) { this.repairFacility = repairFacility; }
}
