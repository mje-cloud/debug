package acc.hertz.model.enums;

public enum MimeType {
    PDF("application/pdf","PDF"),
    JSON("application/json","JSON");
    private final String code;

    public String getName() {
        return name;
    }

    private final String name;

    MimeType(String code, String name) {
        this.code = code;
        this.name=name;
    }

    public String getCode() {
        return code;
    }

    public static MimeType fromType(String type) {
        for (MimeType mime : values()) {
            if (mime.getCode().equals(type)) {
                return mime;
            }
        }
        throw new IllegalArgumentException("Unknown : " + type);
    }
}
