package acc.hertz.model.cloudapi.claim;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClaimInfo {
    @JsonProperty("count")
    private int  count;
    @JsonProperty("data")
    private List<Data> data;
    public List<Data> getData() {
        return data;
    }
    public void setData(List<Data>  data) {
        this.data = data;
    }

    public int getCount() {
        return count;
    }
    public void setCount(int  count) {
        this.count = count;
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Data {
        @JsonProperty("attributes")
        private Attributes attributes;

        public Attributes getAttributes() {
            return attributes;
        }

        public void setAttributes(Attributes attributes) {
            this.attributes = attributes;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Attributes {
            public String getClaimNumber() {
                return claimNumber;
            }

            public void setClaimNumber(String claimNumber) {
                this.claimNumber = claimNumber;
            }

            public String getPolicyNumber() {
                return policyNumber;
            }

            public void setPolicyNumber(String policyNumber) {
                this.policyNumber = policyNumber;
            }

            @JsonProperty("policyNumber")
            private String policyNumber;
            @JsonProperty("claimNumber")
            private String claimNumber;

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            @JsonProperty("id")
            private String id;


        }
    }
}


