package acc.hertz.util;


public class TransformerFactory {

    public static <T> GenericJSONTransformer<T> getTransformer(Class<T> clazz) {
        return new GenericJSONTransformer<>(clazz);
    }
}