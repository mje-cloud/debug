package acc.hertz.model.hertz.shared;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class RepairFacility {

    @JsonProperty("Id")
    private String id;

    @JsonProperty("OrderId")
    private String orderId;

    @JsonProperty("PurchaseOrder")
    private String purchaseOrder;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("Phone")
    private String phone;

    @JsonProperty("Email")
    private String email;

    @JsonProperty("Street1")
    private String street1;

    @JsonProperty("Street2")
    private String street2;

    @JsonProperty("State")
    private String state;

    @JsonProperty("City")
    private String city;

    @JsonProperty("Zip")
    private String zip;

    @JsonProperty("Country")
    private String country;

    @JsonProperty("AppointmentDate")
    private String appointmentDate;

    @JsonProperty("ContactLastName")
    private String contactLastName;

    @JsonProperty("ContactPhone")
    private String contactPhone;

    @JsonProperty("TotalLaborHours")
    private double totalLaborHours;

    @JsonProperty("RepairOrder")
    private List<RepairOrder> repairOrder;


}
