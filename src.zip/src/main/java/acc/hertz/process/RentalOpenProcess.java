package acc.hertz.process;

import acc.hertz.client.composite.ICompositeClient;
import acc.hertz.model.cloudapi.claim.ClaimContact;
import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.claim.VehicleIncident;
import acc.hertz.model.cloudapi.history.History;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestAccepted;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestList;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestPost;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestPostResponse;
import acc.hertz.model.enums.*;
import acc.hertz.model.hertz.outbound.BaseHertzRequest;
import acc.hertz.model.hertz.outbound.BaseHertzResponse;
import acc.hertz.model.hertz.shared.AdditionalCharges;
import acc.hertz.model.hertz.shared.ClaimInfoDetails;
import acc.hertz.model.hertz.shared.RentalInfoDetails;
import acc.hertz.processors.composite.CompositeResponseMapper;
import acc.hertz.processors.composite.helper.CompositeRentalOpenHelper;
import acc.hertz.processors.composite.helper.payload.HistoryComposite;
import acc.hertz.processors.composite.helper.payload.ServiceRequestPostComposite;
import acc.hertz.util.AppUtils;
import acc.hertz.util.Converter;
import acc.hertz.util.GenericJSONTransformer;
import acc.hertz.util.TransformerFactory;
import gw.api.ig.GwUtilities;
import org.apache.camel.Exchange;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;

import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

@Named
public class RentalOpenProcess {

    @Inject
    private ReservationHelper reservationHelper;

    @Inject
    private CompositeRentalOpenHelper compositeRentalOpenHelper;
    @Inject
    private ICompositeClient compositeClient;

    public BaseHertzResponse processRentalOpen(BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception {
        BaseHertzResponse response = null;
        VehicleIncident vehicleIncident = null;
        ClaimContact claimContactDriver = null;
        ServiceRequestPostComposite serviceRequestPost = null;
        ClaimInfoDetails claimInfoDetails = baseHertzRequest.getClaimInfo();
        RentalInfoDetails rentalInfoDetails = baseHertzRequest.getRentalInfo();
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();

        try {
            log.info("RentalOpenProcess","Inside the processRentalOpen class","ClaimNumber",baseHertzRequest.getClaimInfo().getId(), "TransactionType",   baseHertzRequest.getTransactionType(),"method",new Object() {}.getClass().getEnclosingMethod().getName());
            /**
             * 1.2If Claim exist and is open state then continue with step 2
             *
             *     1.2.1 If claim condition are not match return a message error on log and trow an exception
             *               1.2.1.1 if claim do not exist  = Claim {id} not found
             *               if claim is not in open state =  Claim {id} is not in Open state
             */
            ClaimData claim = reservationHelper.findClaim(exchange,baseHertzRequest);
            /**
             *   1.2.2 Find on cloud api if service request exists using the cloud api filter object from the service request web service  from tsd payload
             * "HertzTransactionContractID_Ext" ==  TransactionContractId from tsd payload
             *
             * "HertzTransactionGUID_Ext"" ==  TransactionGUID from tsd payload
             *       if cloud api query return matching then throw an exception "
             * Assigment ID already exists and transaction type demands to create a new service"
             *      If not match continue next step
             */
            ServiceRequestList.ServiceRequest currentServiceRequest = reservationHelper.findServiceRequestWithReservation(claim,baseHertzRequest,HistoryType.HERTZ_RENTAL_OPEN_ACC);
            var currentServiceRequestAttributes = currentServiceRequest.getAttributes();
            log.info("RentalOpenProcess","Inside the processRentalOpen class,ServiceRequest Found ","ClaimNumber",baseHertzRequest.getClaimInfo().getId(),
                    "serviceRequestNumber",   currentServiceRequestAttributes.getServiceRequestNumber(),
                    "method",new Object() {}.getClass().getEnclosingMethod().getName());

            var hertzContactStatus = currentServiceRequestAttributes.getHertzContractStatus_Ext();
            if(!hertzContactStatus.getCode().equalsIgnoreCase(ContractStatus.RESERVATION_CONFIRMED.getCode()) &&
                    !hertzContactStatus.getCode().equalsIgnoreCase(ContractStatus.RESERVATION_OPEN_WALKUP.getCode())){
                log.info("Reservation can not be opened using the current Contract Status",  new Object(){}.getClass().getEnclosingMethod().getName());
                throw new Exception("Reservation can not be opened using the current Contract Status");
            }
            var progress = currentServiceRequestAttributes.getProgress();
            if(!progress.getCode().equalsIgnoreCase(ServiceRequestProgress.DRAFT.getCode())
                    && !progress.getCode().equalsIgnoreCase(ServiceRequestProgress.REQUESTED.getCode())
            ){
                log.info("Reservation can not be open if service request is not in " + ServiceRequestProgress.DRAFT.getCode() + " or " + ServiceRequestProgress.REQUESTED.getCode(),  new Object(){}.getClass().getEnclosingMethod().getName());
                throw new Exception("Reservation can not be open if service request is not in " + ServiceRequestProgress.DRAFT.getCode() + " or " + ServiceRequestProgress.REQUESTED.getCode());
            }

            serviceRequestPost = new ServiceRequestPostComposite();
            serviceRequestPost.setData(new ServiceRequestPostComposite.Data());
            serviceRequestPost.getData().setAttributes(new ServiceRequestPostComposite.Attributes());
            /**
             * 2.Continue looking in cloud api using the claim id all vehicles incidents existing then extract each driver information to compare with the driver data
             * on TSD payload received and compare TSD claimInfo.driverFirstName and  claimInfo.driverLastName with all drivers on claims and return the first vehicle incident match.
             * 2.1 If no driver matches throw  exception with next message = Invalid driver information not matches with Claim Incident
             * 2.2 Continue step 3
             */
            vehicleIncident = reservationHelper.findVehicleIncidentById(claim,currentServiceRequest);
            if (vehicleIncident != null) {

//                serviceRequestPost.getData().getAttributes().getInstruction().setServices(new ArrayList<>());
//                serviceRequestPost.getData().getAttributes().getInstruction().addService(ServiceSubTypes.AUTO_RENTAL.getType());
                serviceRequestPost.getData().getAttributes().setHertzTransactionTSDID_Ext(baseHertzRequest.getRentalInfo().getContractId());
                serviceRequestPost.getData().getAttributes().setHertzContractStatus_Ext(new ServiceRequestPostComposite.CodeName());
                serviceRequestPost.getData().getAttributes().getHertzContractStatus_Ext().setCode(ContractStatus.RENTAL_OPEN.getCode());
                serviceRequestPost.getData().getAttributes().getHertzContractStatus_Ext().setName(ContractStatus.RENTAL_OPEN.getName());
                serviceRequestPost.getData().getAttributes().setHertzClassCode_Ext(claimInfoDetails.getRentalRequestedClass());
                serviceRequestPost.getData().getAttributes().setHertzClassName_Ext(rentalInfoDetails.getRateClass());
                serviceRequestPost.getData().getAttributes().setHertzCustomerSelfPay_Ext(currentServiceRequestAttributes.isHertzCustomerSelfPay_Ext());
                serviceRequestPost.getData().getAttributes().setHertzDateType_Ext(new ServiceRequestPostComposite.CodeName());
                serviceRequestPost.getData().getAttributes().getHertzDateType_Ext().setCode(DateType.CALENDAR_DAY.getCode());
                serviceRequestPost.getData().getAttributes().getHertzDateType_Ext().setName(DateType.CALENDAR_DAY.getName());
                serviceRequestPost.getData().getAttributes().setHertzDayCount_Ext(claimInfoDetails.getTotalDays());
                serviceRequestPost.getData().getAttributes().setHertzIncrementalDays_Ext(claimInfoDetails.getIncrementalDays());
                serviceRequestPost.getData().getAttributes().setHertzMaxAuthAmount_Ext(new ServiceRequestPostComposite.Amount());
                serviceRequestPost.getData().getAttributes().getHertzMaxAuthAmount_Ext().setAmount(String.valueOf(baseHertzRequest.getPolicy().getMaxCoverage()));
                serviceRequestPost.getData().getAttributes().getHertzMaxAuthAmount_Ext().setCurrency(reservationHelper.getDefaultCurrency());
                serviceRequestPost.getData().getAttributes().setHertzRateInclusivePrice_Ext(new ServiceRequestPostComposite.Amount());
                serviceRequestPost.getData().getAttributes().getHertzRateInclusivePrice_Ext().setAmount(AppUtils.getValidCurrencyAmount(String.valueOf(claimInfoDetails.getRentalDailyAmount())));
                serviceRequestPost.getData().getAttributes().getHertzRateInclusivePrice_Ext().setCurrency(reservationHelper.getDefaultCurrency());


                serviceRequestPost.getData().getAttributes().setHertzRentalDailyAmount_Ext(new ServiceRequestPostComposite.Amount());
                serviceRequestPost.getData().getAttributes().getHertzRentalDailyAmount_Ext().setAmount(AppUtils.getValidCurrencyAmount(String.valueOf(claimInfoDetails.getRentalDailyAmount())));
                serviceRequestPost.getData().getAttributes().getHertzRentalDailyAmount_Ext().setCurrency(reservationHelper.getDefaultCurrency());



		 /*CM-8368 CM-8719, TaxExempt field is stored in ClaimCenter,HertzPayAllTaxes_Ext is mapped to ServiceRequest.TaxExempt field in ClaimCenter.
		          sending negation of ServiceRequest.TaxExempt to Hertz and claimInfoDetails.getPayTaxes() cannot be updated back to ClaimCenter
		           */
                // serviceRequestPost.getData().getAttributes().setHertzPayAllTaxes_Ext(!AppUtils.getValidStringValue(claimInfoDetails.getPayTaxes()).equalsIgnoreCase("Y"));
                serviceRequestPost.getData().getAttributes().setHertzPercentagePay_Ext(String.valueOf(baseHertzRequest.getPolicy().getPercentPay()));
                if (rentalInfoDetails.getPickupDate() != null)
                    serviceRequestPost.getData().getAttributes().setHertzPickupDate_Ext(rentalInfoDetails.getPickupDate());

                serviceRequestPost.getData().getAttributes().setHertzRentalBeginDate_Ext(AppUtils.getDateISO8601(baseHertzRequest.getRentalInfo().getStartDate()));

                var endDate = rentalInfoDetails.getEndDate() != null ? AppUtils.getDateISO8601(rentalInfoDetails.getEndDate()) : null;
                if (endDate == null) {
                    if (baseHertzRequest.getClaimInfo().getTotalDays() > 0) {
                        endDate = Converter.parseDateToStringUSFormat(Converter.addDays(Converter.parseStringToDateUSFormat(baseHertzRequest.getRentalInfo().getStartDate()), baseHertzRequest.getClaimInfo().getTotalDays() - 1));
                        serviceRequestPost.getData().getAttributes().setHertzRentalEndDate_Ext(endDate);
                    }
                }

                if (baseHertzRequest.getClaimInfo().getAdditionalCharges() != null && !baseHertzRequest.getClaimInfo().getAdditionalCharges().isEmpty()) {
                    var ldw = baseHertzRequest.getClaimInfo().getAdditionalCharges().stream().filter(e -> e.getCode().equalsIgnoreCase(AdditionalChargeType.LOST_DAMAGE_WAIVER.getCode()) && e.getDescription().equalsIgnoreCase(AdditionalChargeType.LOST_DAMAGE_WAIVER.getName().toLowerCase())).findFirst().orElse(null);
                    serviceRequestPost.getData().getAttributes().setHertzLossDamageWaiver_Ext(ldw != null);

                    var winterTires = baseHertzRequest.getClaimInfo().getAdditionalCharges().stream().filter(e -> e.getCode().equalsIgnoreCase(AdditionalChargeType.WINTER_TIRES.getCode()) && e.getDescription().equalsIgnoreCase(AdditionalChargeType.WINTER_TIRES.getName().toLowerCase())).findFirst().orElse(null);
                    serviceRequestPost.getData().getAttributes().setHertzWinterTires_Ext(winterTires != null);
                }

                if (currentServiceRequestAttributes.isHertzCustomerSelfPay_Ext()) {
                    serviceRequestPost.getData().getAttributes().setHertzRentalEndDate_Ext(rentalInfoDetails.getStartDate());
                }
                serviceRequestPost.getData().getAttributes().setHertzRateType_Ext(new ServiceRequestPostComposite.CodeName());
                RateType rate = RateType.fromType(rentalInfoDetails.getRateClass());
                serviceRequestPost.getData().getAttributes().getHertzRateType_Ext().setCode(rate.getCode());
                serviceRequestPost.getData().getAttributes().getHertzRateType_Ext().setName(rate.getDescription());
                serviceRequestPost.getData().getAttributes().setHertzRentalCompany_Ext(new ServiceRequestPostComposite.CodeName());
                serviceRequestPost.getData().getAttributes().getHertzRentalCompany_Ext().setCode(RentalCompany.HERTZ.getCode());
                serviceRequestPost.getData().getAttributes().getHertzRentalCompany_Ext().setName(RentalCompany.HERTZ.getDescription());
                serviceRequestPost.getData().getAttributes().setHertzTransactionDate_Ext(AppUtils.getDateISO8601(baseHertzRequest.getTransactionDate()));
                RentalRole rentalRole = RentalRole.fromType(claimInfoDetails.getType());
                serviceRequestPost.getData().getAttributes().setHertzRentalRole_Ext(new ServiceRequestPostComposite.CodeName());
                serviceRequestPost.getData().getAttributes().getHertzRentalRole_Ext().setCode(rentalRole.getCode());
                serviceRequestPost.getData().getAttributes().getHertzRentalRole_Ext().setName(rentalRole.getName());

                //if (claimInfoDetails.getTotalDays() > 0)
                serviceRequestPost.getData().getAttributes().setHertzTotalDaysApproved_Ext(claimInfoDetails.getTotalDays());

                serviceRequestPost.getData().getAttributes().setHertzRequestType_Ext(false);
                serviceRequestPost.getData().getAttributes().setHertzVehicleCondition_Ext(currentServiceRequestAttributes.getHertzVehicleCondition_Ext());

                serviceRequestPost.getData().getAttributes().setHertzTransactionTSDID_Ext(rentalInfoDetails.getContractId());
                serviceRequestPost.getData().getAttributes().setHertzTransactionContractID_Ext(rentalInfoDetails.getContractId());
                serviceRequestPost.getData().getAttributes().setHertzTransactionGUID_Ext(baseHertzRequest.getTransactionGUID());
                /*Additional Charges*/
                var additionalCharges = baseHertzRequest.getClaimInfo().getAdditionalCharges();
                if( additionalCharges != null && additionalCharges.size() > 0){
                    for (AdditionalCharges charge : additionalCharges) {
                        if (AdditionalChargeType.LOST_DAMAGE_WAIVER.getCode().equalsIgnoreCase(charge.getCode())) {
                            serviceRequestPost.getData().getAttributes().setHertzLossDamageWaiver_Ext(true);
                        }
                        else if (AdditionalChargeType.WINTER_TIRES.getCode().equalsIgnoreCase(charge.getCode())) {
                            serviceRequestPost.getData().getAttributes().setHertzWinterTires_Ext(true);
                        }
                    }
                }
                else {
                    serviceRequestPost.getData().getAttributes().setHertzLossDamageWaiver_Ext(currentServiceRequestAttributes.isHertzLossDamageWaiver_Ext());
                    serviceRequestPost.getData().getAttributes().setHertzWinterTires_Ext(currentServiceRequestAttributes.isHertzWinterTires_Ext());
                }

                GenericJSONTransformer<BaseHertzRequest> baseHertzRequestTransformer = TransformerFactory.getTransformer(BaseHertzRequest.class);
                HistoryComposite history = new HistoryComposite();
                history.setData(new HistoryComposite.Data());
                history.getData().setAttributes(new HistoryComposite.Data.Attributes());
                history.getData().getAttributes().setClaim(new HistoryComposite.Data.Attributes.Claim());
                history.getData().getAttributes().getClaim().setId(claim.getData().getAttributes().getId());
                history.getData().getAttributes().getClaim().setType(EntityEventType.CLAIM.getType());
                history.getData().getAttributes().setServiceRequest(new HistoryComposite.Data.Attributes.ServiceRequest());
                history.getData().getAttributes().setUser(new HistoryComposite.Data.Attributes.User());
                history.getData().getAttributes().getUser().setId(claim.getData().getAttributes().getAssignedUser().getId());
                history.getData().getAttributes().getUser().setType(EntityEventType.USER.getType());
                history.getData().getAttributes().setType(new HistoryComposite.Data.Attributes.Type());
                history.getData().getAttributes().getType().setCode(HistoryType.HERTZ_RENTAL_OPEN_ACC.getCode());
                history.getData().getAttributes().getType().setName(HistoryType.HERTZ_RENTAL_OPEN_ACC.getName());
                history.getData().getAttributes().setDescription(HistoryType.HERTZ_RENTAL_OPEN_ACC.getDescription()
                        .replace("$1", (claimInfoDetails.getClaimNoteRentalInstructions() != null ? claimInfoDetails.getClaimNoteRentalInstructions() : ""))
                        .replace("$2", TransactionType.RENTAL_OPEN.getDescription()));
                history.getData().getAttributes().setRequest(baseHertzRequestTransformer.toJson(baseHertzRequest));


                try{
                    String stickySessionToken = UUID.randomUUID().toString();
                    var abstractRequest = compositeRentalOpenHelper.buildCompositeRequest(claim,
                            baseHertzRequest,
                            currentServiceRequest,
                            serviceRequestPost,
                            history);
                    String result = compositeClient.executeCompositeRequest(exchange, stickySessionToken, abstractRequest);
                    ServiceRequestPostResponse compositeBodyResponse = CompositeResponseMapper.mapFirstResponse(result, ServiceRequestPostResponse.class);
                    Thread.sleep(10000);
                    if(compositeBodyResponse.getData().getAttributes().getProgress().getCode().equalsIgnoreCase(ServiceRequestProgress.DRAFT.getCode())){
                        ////Move to requested state using normal Rest Call since Composite DO NOT SUPPORT submit state
                        reservationHelper.markAsSubmitted(stickySessionToken,claim,currentServiceRequest.getAttributes().getId());
                        ////Move to requested state using normal Rest Call since Composite DO NOT SUPPORT in-progress state
                        ServiceRequestAccepted accepted = new ServiceRequestAccepted();
                        accepted.setData(new ServiceRequestAccepted.Data());
                        accepted.getData().setAttributes(new ServiceRequestAccepted.Attributes());
                        accepted.getData().getAttributes().setExpectedCompletionDate(Converter.parseDateToStringUSFormat(Converter.addDays(Converter.parseStringToDateUSFormat(baseHertzRequest.getRentalInfo().getStartDate()), 30)));
                        reservationHelper.markAsInProgress(stickySessionToken,claim,currentServiceRequest.getAttributes().getId(), accepted);
                    }else {
                        if (compositeBodyResponse.getData().getAttributes().getProgress().getCode().equalsIgnoreCase(ServiceRequestProgress.REQUESTED.getCode())) {
                            ////Move to requested state using normal Rest Call since Composite DO NOT SUPPORT in-progress state
                            ServiceRequestAccepted accepted = new ServiceRequestAccepted();
                            accepted.setData(new ServiceRequestAccepted.Data());
                            accepted.getData().setAttributes(new ServiceRequestAccepted.Attributes());
                            accepted.getData().getAttributes().setExpectedCompletionDate(Converter.parseDateToStringUSFormat(Converter.addDays(Converter.parseStringToDateUSFormat(baseHertzRequest.getRentalInfo().getStartDate()), 30)));
                            reservationHelper.markAsInProgress(stickySessionToken, claim, currentServiceRequest.getAttributes().getId(), accepted);
                        }
                    }

                    //GenericJSONTransformer<BaseHertzRequest> baseHertzRequestTransformer = new GenericJSONTransformer<>(BaseHertzRequest.class);
                /*    History newHistory = new History();
                    newHistory.setData(new History.Data());
                    newHistory.getData().setAttributes(new History.Data.Attributes());
                    newHistory.getData().getAttributes().setClaim(new History.Data.Attributes.Claim());
                    newHistory.getData().getAttributes().getClaim().setId(claim.getData().getAttributes().getId());
                    newHistory.getData().getAttributes().getClaim().setType(EntityEventType.CLAIM.getType());
                    newHistory.getData().getAttributes().setServiceRequest(new History.Data.Attributes.ServiceRequest());
                    newHistory.getData().getAttributes().getServiceRequest().setId(responseRental.getData().getAttributes().getId());
                    newHistory.getData().getAttributes().getServiceRequest().setType(EntityEventType.SERVICE_REQUEST.getType());
                    newHistory.getData().getAttributes().setUser(new History.Data.Attributes.User());
                    newHistory.getData().getAttributes().getUser().setId(claim.getData().getAttributes().getAssignedUser().getId());
                    newHistory.getData().getAttributes().getUser().setType(EntityEventType.USER.getType());
                    newHistory.getData().getAttributes().setType(new History.Data.Attributes.Type());
                    newHistory.getData().getAttributes().getType().setCode(HistoryType.HERTZ_RENTAL_OPEN_ACC.getCode());
                    newHistory.getData().getAttributes().getType().setName(HistoryType.HERTZ_RENTAL_OPEN_ACC.getName());
                    newHistory.getData().getAttributes().setDescription(HistoryType.HERTZ_RENTAL_OPEN_ACC.getDescription()
                            .replace("$1",(claimInfoDetails.getClaimNoteRentalInstructions() != null ? claimInfoDetails.getClaimNoteRentalInstructions() : ""))
                            .replace("$2",TransactionType.RENTAL_OPEN.getDescription()));
                    newHistory.getData().getAttributes().setRequest(baseHertzRequestTransformer.toJson(baseHertzRequest));
                    reservationHelper.createHistoryRecord(exchange, newHistory);*/

                    response = new BaseHertzResponse();
                    response.setMessage(HistoryType.HERTZ_RENTAL_OPEN_ACC.getName() + " processed");
                    response.setMsgType("success");
                    response.setTransactionGuid(baseHertzRequest.getTransactionGUID());
                    response.setTransactionContractId(baseHertzRequest.getTransactionContractId());
                    response.setTransactionType(baseHertzRequest.getTransactionType());
                    response.setMsgGuid(baseHertzRequest.getTransactionGUID());
                    response.setTransactionDate(baseHertzRequest.getTransactionDate());
                    response.setMsgDate(Converter.parseDateToJSON(new Date()));
                }catch(Exception e){
                    throw e;
                }

            } else {

                log.info("RentalOpenProcess Class","Invalid vehicle information not matches with Claim Incident ","ClaimNumber",baseHertzRequest.getClaimInfo().getId(),
                        "serviceRequestNumber",   currentServiceRequestAttributes.getServiceRequestNumber(),
                        "method",new Object() {}.getClass().getEnclosingMethod().getName());
            }
        } catch (Exception exception) {


            log.error(
                    "ReservationRejected",
                    "Reservation cannot be opened due to current Contract Status",
                    exception,   // <-- REQUIRED Throwable (null if no exception)
                    "ClaimNumber", baseHertzRequest.getClaimInfo().getId()
            );

            throw exception;
        }
        return response;

    }

}

