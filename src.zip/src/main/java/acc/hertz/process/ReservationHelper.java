package acc.hertz.process;

import acc.hertz.client.service.IClaimClient;
import acc.hertz.client.service.IDocumentClient;
import acc.hertz.client.service.IHistoryClient;
import acc.hertz.model.activitypattern.ActivityPost;
import acc.hertz.model.cloudapi.claim.*;
import acc.hertz.model.cloudapi.contact.ClaimContactData;
import acc.hertz.model.cloudapi.contact.ClaimContactPost;
import acc.hertz.model.cloudapi.contact.VendorContactData;
import acc.hertz.model.cloudapi.documents.CreateDocument;
import acc.hertz.model.cloudapi.history.History;
import acc.hertz.model.cloudapi.servicerequest.*;
import acc.hertz.model.cloudapi.typelist.TypeLists;
import acc.hertz.model.enums.*;
import acc.hertz.model.hertz.outbound.BaseHertzRequest;
import acc.hertz.util.AppProperty;
import acc.hertz.util.AppUtils;
import acc.hertz.util.GenericJSONTransformer;
import gw.api.ig.logging.GwLogger;
import org.apache.camel.Exchange;
import acc.hertz.util.TransformerFactory;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import java.util.Base64;
import java.util.Objects;
import static acc.hertz.model.enums.HistoryType.HERTZ_RENTAL_INVOICE_ACC;
import static acc.hertz.model.enums.HistoryType.HERTZ_RENTAL_OPEN_ACC;
import static acc.hertz.model.enums.HistoryType.*;

@Named
public class ReservationHelper {
    private final GenericJSONTransformer<BaseHertzRequest> baseHertzRequestTransformer = TransformerFactory.getTransformer(BaseHertzRequest.class);
    @Inject
    private AppProperty property;
    @Inject
    private IClaimClient iClaimClient;
    @Inject
    private IDocumentClient iDocumentClient;
    @Inject
    private IHistoryClient historyClient;
    @Inject
    private GwLogger logger;

    @Inject
    public ReservationHelper(GwLogger logger) {      // <-- used (only @Inject ctor)
        this.logger = logger;
    }

    public String parseRequestAsJSON(BaseHertzRequest baseHertzRequest) throws Exception {
        return baseHertzRequestTransformer.toJson(baseHertzRequest);
    }

 /*

    public String getDefaultPayTaxes(ServiceRequestList.ServiceRequest serviceRequest) {
        String result = "";
        if (serviceRequest.getAttributes().getHertzRentalRole_Ext().getCode() == RentalRole.CLAIMANT.getCode()) {
            result = "Y";
        }else{
            result = serviceRequest.getAttributes().isHertzPayAllTaxes_Ext() ? "Y" : "";
            if (result.isEmpty()) {
                result = serviceRequest.getAttributes().getHertzRateInclusivePrice_Ext().getAmount() != null && Double.parseDouble(serviceRequest.getAttributes().getHertzRateInclusivePrice_Ext().getAmount()) != 0 ? "Y" : "N";
            }
        }

        *//**
     * Requirement/Business rules
     * Only applicable for Canada Module Enable
     * In Claim Center, if Tax Exempt = Yes, Cooperators passes PAYTAX = N in the payload
     * along with an amount approved and a policy max.
     *//*
        if(property.isCanadaModuleEnabled() && serviceRequest.getAttributes().isHertzPayAllTaxes_Ext()){
            result= "N";
        }
        return result;
    }
*/


    public ClaimContactData findContact(String claimId, String contactId) throws Exception {
        ClaimContactData claimContactRepairFacility= null;
        try{
            claimContactRepairFacility = iClaimClient.getClaimContact(claimId,contactId);

        }catch (Exception e){
            throw e;
        }
        return claimContactRepairFacility;
    }

    public User findUserAssigned(ClaimData claim) throws Exception {
        User userAssigned = null;
        try {
            userAssigned = iClaimClient.getUserAssigned(claim.getData().getAttributes().getAssignedUser().getId());
        } catch (Exception e) {
            throw e;
        }
        return userAssigned;
    }


    public User findUserAssigned(ServiceRequestList.ServiceRequest serviceRequest) throws Exception {
        User userAssigned = null;
        try{
            // Adjuster is fetched based on different conditions from ClaimCenter
            userAssigned = iClaimClient.getUserAssigned(serviceRequest.getAttributes().getHertzAdjuster_Ext().getId());
        }catch (Exception e){
            throw e;
        }
        return userAssigned;
    }

    public ClaimContactData addRepairFacility(Exchange exchange, ClaimData claim, ClaimContactPost newRepairFacility) throws Exception {
        return iClaimClient.createClaimContact(exchange, claim.getData().getAttributes().getId(), newRepairFacility);
    }

    public ClaimContactData addSpecialistVendor(Exchange exchange, ClaimData claim, ClaimContactPost newVendor) throws Exception {
        return iClaimClient.createClaimContact(exchange, claim.getData().getAttributes().getId(), newVendor);
    }

    public ClaimContactData addRentalLocationVendor(Exchange exchange, ClaimData claim, ClaimContactPost newVendor) throws Exception {
        return iClaimClient.createClaimContact(exchange, claim.getData().getAttributes().getId(), newVendor);
    }
    public TypeLists.Data.Attributes.TypeKey getTypeKey(Exchange exchange,TypeListType typeKey , String codeFilter) throws Exception {
        TypeLists result = iClaimClient.getTypeListByName(exchange, typeKey.getType(),codeFilter);
        TypeLists.Data.Attributes.TypeKey typeKeyState = result.getData().getAttributes().getTypeKeys().get(0);
        return typeKeyState;
    }
    public static String getClaimType(ServiceRequestList.ServiceRequest serviceRequest ) {
        String cType = RentalRole.CLAIMANT.getTSDCode();
        if(serviceRequest.getAttributes().getHertzRentalRole_Ext().getCode().equals(RentalRole.INSURED.getCode())){
            cType =  RentalRole.INSURED.getTSDCode();
        }
        return cType;
    }

    public static String getDefaultPayTaxes(ServiceRequestList.ServiceRequest serviceRequest) {

        if (serviceRequest.getAttributes().getHertzRentalRole_Ext().getCode() == RentalRole.CLAIMANT.getCode()) {
            return "Y";
        }
		  /*CM-8368 CM-8719, TaxExempt field is stored in ClaimCenter,HertzPayAllTaxes_Ext is mapped to ServiceRequest.TaxExempt field in ClaimCenter.
		  sending negation of ServiceRequest.TaxExempt to Hertz
		   */
        String result = !serviceRequest.getAttributes().isHertzPayAllTaxes_Ext() ? "Y" : "N";
        //CM-8719 Fixed the tax exempt mapping.
       /*
	   if (result == null || result.isEmpty()) {
            result = serviceRequest.getAttributes().getHertzRateInclusivePrice_Ext().getAmount() != null && Double.parseDouble(serviceRequest.getAttributes().getHertzRateInclusivePrice_Ext().getAmount())!=0 ? "Y" : "N";
        } */
        return result;
    }

    public boolean isCanadaModuleActive() {
        return property.isCanadaModuleEnabled();
    }

    public String getDefaultCountry() {
        if (property.isCanadaModuleEnabled()) {
            return CountryCode.CA.getCode();
        } else {
            return CountryCode.US.getCode();
        }
    }
    public String getDefaultCountryArea() {
        if (property.isCanadaModuleEnabled()) {
            return CountryCode.CA.getName();
        } else {
            return CountryCode.US.getName();
        }
    }

    public String getDefaultCurrency() {
        if (property.isCanadaModuleEnabled()) {
            return CurrencyCode.CAD.getCode();
        } else {
            return CurrencyCode.USD.getCode();
        }
    }

    public String getDefaultSource() {
        return property.getMsgSource();
    }

    public String getDefaultTaxId() {
        return property.getDefaultTaxId();
    }

    public boolean isAvailableServiceRequest(ServiceRequestList.ServiceRequest serviceRequest) {
        var currentProgress = ServiceRequestProgress.fromCode(serviceRequest.getAttributes().getProgress().getCode());
        if (serviceRequest != null
                && currentProgress != ServiceRequestProgress.DECLINED
                && currentProgress != ServiceRequestProgress.EXPIRED
                && currentProgress != ServiceRequestProgress.CANCELED) {
            return true;
        }
        return false;
    }


    public void validateClaimData(ClaimData claim, BaseHertzRequest baseHertzRequest ) throws Exception {
        if(baseHertzRequest.getClaimInfo().getId()==null){
            throw new Exception("Claim Number not found on TSD/HERTZ request");
        }
        if (claim == null) {
            throw new Exception("Claim Number not found on ClaimCenter");
        }
        if(claim.getData().getAttributes().getClaimNumber()==null){
            throw new Exception("Claim Number not found on ClaimCenter");
        }
        if (!claim.getData().getAttributes().getClaimNumber().equals(baseHertzRequest.getClaimInfo().getId())) {
            throw new Exception("Claim Number on TSD/HERTZ request not found ClaimCenter");
        }
        if (!claim.getData().getAttributes().getState().getCode().equals(ClaimStatus.OPEN.getCode())) {
            throw new Exception("Claim Number found is not in Open state");
        }

    }

    public String getUser(String userId) {
        String transactionUserId = userId;
        if (userId.length() > 15 && userId.contains("/")) {
            transactionUserId = userId.split("/")[1];
        }
        return transactionUserId;
    }

    public ServiceRequestPostResponse updateRental(ClaimData claim, ServiceRequestList.ServiceRequest serviceRequest, ServiceRequestPost serviceRequestPost) throws Exception {
        ServiceRequestPostResponse response = null;
        try {
            response = iClaimClient.patchServiceRequest(claim, serviceRequest, serviceRequestPost);
        } catch (Exception e) {
            throw e;
        }
        return response;
    }

    public boolean updateRental(final String stickySessionToken,ClaimData claim, ServiceRequestList.ServiceRequest serviceRequest, ServiceRequestPatch serviceRequestPatch) throws Exception {
        try {
            return iClaimClient.addInvoiceServiceRequest(stickySessionToken,claim, serviceRequest, serviceRequestPatch);
        } catch (Exception e) {
            throw e;
        }
    }


    public boolean addInvoiceDocument(Exchange exchange,String stickySessionToken, ClaimData claim, BaseHertzRequest baseHertzRequest, CreateDocument createDocument) throws Exception {
        try {
            byte[] contents = Base64.getDecoder().decode(baseHertzRequest.getRentalInvoice().getBinary());
            return iDocumentClient.createDocument(exchange,stickySessionToken, claim.getData().getAttributes().getId(), baseHertzRequest.getRentalInvoice().getId(), contents, createDocument);
        } catch (Exception e) {
            throw e;
        }
    }

    public boolean isExistingDocument(Exchange exchange,String stickySessionToken, ClaimData claim, CreateDocument createDocument) throws Exception {
        try {
            var document =  iDocumentClient.getDocument(exchange,stickySessionToken, claim.getData().getAttributes().getId(), createDocument.getData().getAttributes().getType().getCode(), createDocument.getData().getAttributes().getName());
            if(document.getCount() > 10){
                return true;
            }
        } catch (Exception e) {
            throw e;
        }
        return false;
    }

    public ServiceRequestPostResponse markAsDeclined(final String stickySessionToken,ClaimData claim, ServiceRequestList.ServiceRequest serviceRequest, ServiceRequestDecline serviceRequestDeclined) throws Exception {
        ServiceRequestPostResponse response = null;
        try {
            response = iClaimClient.declineServiceRequest(stickySessionToken,claim, serviceRequest.getAttributes().getId(), serviceRequestDeclined);
        } catch (Exception e) {
            throw e;
        }
        return response;
    }

    public ServiceRequestPostResponse markAsCompleted(final String stickySessionToken,ClaimData claim, ServiceRequestList.ServiceRequest serviceRequest) throws Exception {
        ServiceRequestPostResponse response = null;
        try {
            response = iClaimClient.workCompletedServiceRequest(stickySessionToken,claim, serviceRequest.getAttributes().getId());
        } catch (Exception e) {
            throw e;
        }
        return response;
    }


    public boolean createHistoryRecord(Exchange exchange,final String stickySessionToken, History newHistory) throws Exception {
        try {
            return historyClient.createHistoryEntry(exchange, stickySessionToken,newHistory);
        } catch (Exception e) {
            throw e;
        }
    }

    public boolean createActivityRecord(ClaimData claim, ActivityPost newActivity) throws Exception {
        try {
            return  iClaimClient.postActivityWarning(claim, newActivity);
        }catch(Exception e){
            throw e;
        }
    }

    public ServiceRequestPostResponse createDraftService(ClaimData claim, ServiceRequestPost serviceRequestPost) throws Exception {
        ServiceRequestPostResponse response = null;
        try {
            response = iClaimClient.draftServiceRequest(claim, serviceRequestPost);
        } catch (Exception e) {
            throw e;
        }
        return response;
    }

    public ServiceRequestInvoice createNewInvoiceForService(String stickySessionToken,ClaimData claim, ServiceRequestList.ServiceRequest currentService, ServiceRequestInvoice serviceRequestInvoice) throws Exception {
        ServiceRequestInvoice response = null;
        try {
            response = iClaimClient.addServiceRequestInvoice(stickySessionToken,claim, currentService, serviceRequestInvoice);
        } catch (Exception e) {
            throw e;
        }
        return response;
    }

    public ServiceRequestPostResponse markAsSubmitted(final String stickySessionToken,ClaimData claim, String serviceRequestId) throws Exception {
        ServiceRequestPostResponse response = null;
        try {
            //Move to requested state
            response = iClaimClient.submitServiceRequest(stickySessionToken ,claim, serviceRequestId);
        } catch (Exception e) {
            throw e;
        }
        return response;
    }

    public ServiceRequestPostResponse markAsInProgress(final String stickySessionToken,ClaimData claim, String serviceRequestId, ServiceRequestAccepted serviceRequestAccepted) throws Exception {
        ServiceRequestPostResponse response = null;
        try {
            //Move to in_progress state
            response = iClaimClient.acceptServiceRequest(stickySessionToken,claim, serviceRequestId, serviceRequestAccepted);
        } catch (Exception e) {
            throw e;
        }
        return response;
    }


    public ClaimData findClaim(Exchange exchange, BaseHertzRequest baseHertzRequest) throws Exception{
        ClaimData claim ;
        try{
            ClaimInfo claimInfo = iClaimClient.getClaimByClaimNumber(exchange, baseHertzRequest.getClaimInfo().getId());
            if(claimInfo.getCount()>0 ){
                claim = iClaimClient.getClaimData(exchange, claimInfo.getData().get(0).getAttributes().getId());
                validateClaimData(claim, baseHertzRequest);
            }else{

                logger.info("ReservationHelper",
                        "Claim Number provided by Hertz was not found on ClaimCenter",
                        "ClaimNumber",          baseHertzRequest.getClaimInfo().getId(),
                        "method",               new Object() {}.getClass().getEnclosingMethod().getName()
                );

                throw new Exception("Claim Number provided by Hertz was not found on ClaimCenter");
            }
        }catch(Exception e){
            throw e;
        }
        return claim;
    }

    public ClaimData findClaimById(Exchange exchange,String claimId) throws Exception{
        ClaimData claim ;
        try{
            claim = iClaimClient.getClaimData(exchange,claimId);
        }catch(Exception e){
            throw e;
        }
        return claim;
    }


    public ServiceRequestList.ServiceRequest findServiceRequestByFilter(String claimId,String filter) throws Exception{
        ServiceRequestList serviceRequests ;
        try{
            serviceRequests = iClaimClient.getServiceRequestData(claimId, filter);
            return serviceRequests.getData().stream().findFirst().orElse(null);
        }catch(Exception e){
            throw e;
        }
    }


    public  ServiceRequestList.ServiceRequest findServiceRequestWithReservation(ClaimData claim, BaseHertzRequest baseHertzRequest,final HistoryType type ) throws Exception{
        try{
            StringBuilder filterBuilder = new StringBuilder()
                    .append(Filter.FILTER_KEYWORD.getCode())
                    .append(RestRelopType.EQUALS.getCode())
                    .append(Filter.HERTZ_TRANSACTION_GUID_EXT.getCode())
                    .append(RestRelopType.EQ_OPERATOR.getCode())
                    .append(baseHertzRequest.getTransactionGUID());

            if (type != HERTZ_RENTAL_OPEN_ACC) {
                filterBuilder
                        .append(RestRelopType.AND_OPERATOR.getCode())
                        .append(Filter.FILTER_KEYWORD.getCode())
                        .append(RestRelopType.EQUALS.getCode())
                        .append(Filter.HERTZ_TRANSACTION_CONTRACT_ID_EXT.getCode())
                        .append(RestRelopType.EQ_OPERATOR.getCode())
                        .append(baseHertzRequest.getTransactionContractId());
            }

            String contractFilter = filterBuilder.toString();
            ServiceRequestList serviceRequests = iClaimClient.getServiceRequestData(claim.getData().getAttributes().getId(), contractFilter);
            switch (type){
                case HERTZ_WALK_UP_AUTHORIZATION_ACC:
                    if (serviceRequests != null && serviceRequests.getCount()>0) {
                        throw new Exception("TransactionContractID and TransactionGUID already exists");
                    }
                    break;
                case HERTZ_REACTIVE_EXTENSION_ACC:
                case HERTZ_RENTAL_OPEN_ACC:
                case HERTZ_RENTAL_CLOSE_ACC:
                case HERTZ_CANCEL_RESERVATION_ACC:
                case HERTZ_RENTAL_INVOICE_ACC:
                    if (serviceRequests == null || serviceRequests.getCount() == 0 ) {
                        logger.info("ReservationHelper",
                                "TransactionContractID and TransactionGUID not found for current operation",
                                "ClaimNumber",          baseHertzRequest.getClaimInfo().getId(),
                                "method",               new Object() {}.getClass().getEnclosingMethod().getName()
                        );

                        throw new Exception("TransactionContractID and TransactionGUID not found for current operation");
                    }else{
                        ServiceRequestList.ServiceRequest serviceRequest = serviceRequests.getData().stream().findFirst().orElse(null);
                        if (serviceRequest != null && type != HERTZ_RENTAL_INVOICE_ACC && type != HERTZ_CANCEL_RESERVATION_ACC && !isAvailableServiceRequest(serviceRequest)) {
                            logger.info("ReservationHelper",
                                    "TransactionContractID and TransactionGUID not found",
                                    "ClaimNumber",          baseHertzRequest.getClaimInfo().getId(),
                                    "serviceRequestNumber",serviceRequest.getAttributes().getServiceRequestNumber(),
                                    "method",               new Object() {}.getClass().getEnclosingMethod().getName()
                            );

                            throw new Exception("TransactionContractID and TransactionGUID not found");
                        }
                        return serviceRequest;
                    }
                default:
                    throw new Exception("Transaction Type received not found");
            }
        }catch (Exception e){
            throw e;
        }
        return null;
    }


    public ClaimContact findDriverClaimContact(ClaimData claim, BaseHertzRequest baseHertzRequest){
        return claim.getIncluded().getClaimContacts().stream()
                .filter(contact -> contact.getAttributes().getContactSubtype().equals(ContactSubType.PERSON.getType()) && AppUtils.getValidStringValue(contact.getAttributes().getFirstName().toLowerCase()).equals(baseHertzRequest.getClaimInfo().getDriverFirstName().toLowerCase()) &&
                        AppUtils.getValidStringValue(contact.getAttributes().getLastName().toLowerCase()).equals(baseHertzRequest.getClaimInfo().getDriverLastName().toLowerCase()))
                .findFirst()
                .orElse(null);
    }

    public ClaimContact findVendorOfficeClaimContact( ClaimData claim,BaseHertzRequest baseHertzRequest){
        return claim.getIncluded().getClaimContacts().stream()
                .filter(e -> AppUtils.getValidStringValue(e.getAttributes().getHertzIDStoreOffice_Ext()).equalsIgnoreCase(baseHertzRequest.getRentalInfo().getVendorOfficeId())).findFirst().orElse(null);

    }

    public ClaimContact findRepairFacilityClaimContact( ClaimData claim,BaseHertzRequest baseHertzRequest){
        return           claim.getIncluded()
                .getClaimContacts()
                .stream()
                .filter(Objects::nonNull)
                .filter(this::hasRepairShopRole)
                .findFirst()
                .orElse(null);


    }
    private boolean hasRepairShopRole(ClaimContact contact) {
        if (contact.getAttributes() == null || contact.getAttributes().getRoles() == null) {
            return false;
        }
        return contact.getAttributes()
                .getRoles()
                .stream()
                .filter(Objects::nonNull)
                .anyMatch(r ->
                        r.getRole() != null &&
                                r.getRole().getCode() != null &&
                                "repairshop".equalsIgnoreCase(r.getRole().getCode())
                );
    }


    public VehicleIncident findVehicleIncident(ClaimData claim){
        return claim.getIncluded().getVehicleIncidents().stream()
                //.filter(e -> e.getAttributes().getDriver()!=null &&
                //      e.getAttributes().getDriver().getId().equalsIgnoreCase(driver.getAttributes().getId()))
                .findFirst()
                .orElse(null);
    }
    public Policy findPolicy(ClaimData claim){
        return  claim.getIncluded().getPolicies().stream().filter(e -> e.getAttributes().getPolicyNumber().equalsIgnoreCase(claim.getData().getAttributes().getPolicyNumber())).findFirst().orElse(null);
    }

    public ClaimContactData findPolicyAgent(Policy policy , ClaimData claim ) throws Exception {
        return  iClaimClient.getClaimContact(claim.getData().getAttributes().getId(), policy.getAttributes().getAgent().getId());
    }
    public ClaimContactData findPolicyInsured(Policy policy , ClaimData claim ) throws Exception {
        return  iClaimClient.getClaimContact(claim.getData().getAttributes().getId(), policy.getAttributes().getInsured().getId());
    }

    public VehicleIncident findVehicleIncidentById(ClaimData claim, ServiceRequestList.ServiceRequest serviceRequest){
        return claim.getIncluded().getVehicleIncidents().stream()
                .filter(e -> e.getAttributes().getId().equalsIgnoreCase(serviceRequest.getAttributes().getIncident().getId()))
                .findFirst()
                .orElse(null);
    }
    public VendorContactData addSpecialistVendor(Exchange exchange, ClaimData claim) throws Exception {
        return iClaimClient.createVendorContact(exchange, claim.getData().getAttributes().getId());
    }
}