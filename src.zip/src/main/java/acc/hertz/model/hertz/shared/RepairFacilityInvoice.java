package acc.hertz.model.hertz.shared;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RepairFacilityInvoice {

    @JsonProperty("Id")
    private String id;

    @JsonProperty("OrderId")
    private String orderId;

    @JsonProperty("PurchaseOrder")
    private String purchaseOrder;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("Phone")
    private String phone;

    @JsonProperty("Email")
    private String email;

    @JsonProperty("Street1")
    private String street1;

    @JsonProperty("Street2")
    private String street2;

    @JsonProperty("State")
    private String state;

    @JsonProperty("City")
    private String city;

    @JsonProperty("Zip")
    private String zip;

    @JsonProperty("Country")
    private String country;

    @JsonProperty("AppontmentDate")//"Typo made on purpose to support payload received"
    private String appointmentDate;

    @JsonProperty("ContactLastName")
    private String contactLastName;

    @JsonProperty("ContactPhone")
    private String contactPhone;

    @JsonProperty("TotalLaborHours")
    private double totalLaborHours;

    @JsonProperty("RepairOrder")
    private List<RepairOrder> repairOrder;

    // Getters and setters
    public String getId() { return id; }

    public void setId(String id) { this.id = id; }

    public String getOrderId() { return orderId; }

    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getPurchaseOrder() { return purchaseOrder; }

    public void setPurchaseOrder(String purchaseOrder) { this.purchaseOrder = purchaseOrder; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public String getPhone() { return phone; }

    public void setPhone(String phone) { this.phone = phone; }

    public String getEmail() { return email; }

    public void setEmail(String email) { this.email = email; }

    public String getStreet1() { return street1; }

    public void setStreet1(String street1) { this.street1 = street1; }

    public String getStreet2() { return street2; }

    public void setStreet2(String street2) { this.street2 = street2; }

    public String getState() { return state; }

    public void setState(String state) { this.state = state; }

    public String getCity() { return city; }

    public void setCity(String city) { this.city = city; }

    public String getZip() { return zip; }

    public void setZip(String zip) { this.zip = zip; }

    public String getCountry() { return country; }

    public void setCountry(String country) { this.country = country; }

    public String getAppointmentDate() { return appointmentDate; }

    public void setAppointmentDate(String appointmentDate) { this.appointmentDate = appointmentDate; }

    public String getContactLastName() { return contactLastName; }

    public void setContactLastName(String contactLastName) { this.contactLastName = contactLastName; }

    public String getContactPhone() { return contactPhone; }

    public void setContactPhone(String contactPhone) { this.contactPhone = contactPhone; }

    public double getTotalLaborHours() { return totalLaborHours; }

    public void setTotalLaborHours(double totalLaborHours) { this.totalLaborHours = totalLaborHours; }

    public List<RepairOrder> getRepairOrder() { return repairOrder; }

    public void setRepairOrder(List<RepairOrder> repairOrder) { this.repairOrder = repairOrder; }
}
