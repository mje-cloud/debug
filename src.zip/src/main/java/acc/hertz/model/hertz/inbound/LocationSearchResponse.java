package acc.hertz.model.hertz.inbound;

import acc.hertz.model.hertz.shared.TransactionResponseHeader;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LocationSearchResponse {

    @JsonProperty("ResponseHeader")
    private TransactionResponseHeader responseHeader;

    @JsonProperty("rentalStores")
    private List<RentalStoreDetails> rentalStores;

    // Getters and Setters
    public TransactionResponseHeader getResponseHeader() {
        return responseHeader;
    }

    public void setResponseHeader(TransactionResponseHeader responseHeader) {
        this.responseHeader = responseHeader;
    }

    public List<RentalStoreDetails> getRentalStores() {
        return rentalStores;
    }

    public void setRentalStores(List<RentalStoreDetails> rentalStores) {
        this.rentalStores = rentalStores;
    }
}
