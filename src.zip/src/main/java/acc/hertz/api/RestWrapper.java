package acc.hertz.api;

import acc.hertz.client.core.IClient;
import acc.hertz.client.core.WebMethodType;
import acc.hertz.model.enums.MimeType;
import acc.hertz.model.hertz.inbound.AssignmentRequest;
import acc.hertz.model.hertz.inbound.LocationSearchRequest;
import acc.hertz.model.hertz.inbound.LocationSearchResponse;
import acc.hertz.model.hertz.outbound.HertzAPIException;
import acc.hertz.model.hertz.shared.TransactionResponseHeader;
import acc.hertz.security.authorization.AuthorizationType;
import acc.hertz.util.AppProperty;
import acc.hertz.util.AppUtils;
import acc.hertz.util.GenericJSONTransformer;
import acc.hertz.util.TransformerFactory;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static acc.hertz.util.AppUtils.*;

@Named
public class RestWrapper implements IRest {
    private final Logger log = LoggerFactory.getLogger(RestWrapper.class);
    @Inject
    private IClient client;
    @Inject
    private AppProperty properties;

    @Override
    public TransactionResponseHeader createNewReservation(AssignmentRequest assignmentRequest) throws HertzAPIException {
        TransactionResponseHeader result = null;
        GenericJSONTransformer<TransactionResponseHeader> resultTransformer = TransformerFactory.getTransformer(TransactionResponseHeader.class);
        String response;
        try {
            GenericJSONTransformer<AssignmentRequest> assignmentRequestTransformer = TransformerFactory.getTransformer(AssignmentRequest.class);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.addHeaderParameter(MSG_SOURCE, properties.getMsgSource());
            client.addHeaderParameter(MSG_SOURCE, properties.getUserNameTSD());
            client.addHeaderParameter(MSG_SOURCE_AUTHENTICATION, properties.getPasswordTSD());
            String bodyRequest = assignmentRequestTransformer.toJson(assignmentRequest);
			   log.info("Body Request of createNewReservation service is "+bodyRequest);
			 log.info("createNewReservation Url is "+properties.getApiTSDServer() + ASSIGNMENT_SERVICE);
            client.doExecute(properties.getApiTSDServer() + ASSIGNMENT_SERVICE, bodyRequest, WebMethodType.POST, AuthorizationType.TSD_TOKEN_ACCESS);
            if (client.isSuccessExecuted()) {
                response = AppUtils.sanitize(client.getResponseBody());
				 log.info("Body response of createNewReservation service is "+response);
                result = resultTransformer.fromJson(response);
            } else {
                log.error(" - There are error trying to create new reservation. \n{}", client.getResponseBody());
                throw new HertzAPIException(client.getResponseCode(),client.getResponseBody());
            }
        } catch (HertzAPIException e) {
            log.error(e.getMessage());
            throw e;

        }
        catch (Exception e) {
            log.error(e.getMessage());
            throw new HertzAPIException(0,e.getMessage());

        }
        return result;
    }
	
	

    @Override
    public LocationSearchResponse getLocation(LocationSearchRequest locationSearchRequest) throws Exception {
        LocationSearchResponse location = null;
        String response;
        try {
            GenericJSONTransformer<LocationSearchRequest> locationSearchRequestTransformer = TransformerFactory.getTransformer(LocationSearchRequest.class);
            // Disabling as it's set by CC runtime property HertzLocationSearchReturn
            //locationSearchRequest.setResultCount(Integer.parseInt(properties.getSearchLocationCount()));
            // CM-9171: Trimming fields DriverAddress1, DriverAddress2, DriverCity, DriverZip according to the Hertz accelerator valid data type
            locationSearchRequest.setDriverAddress1(AppUtils.stringSizeRefactoring(locationSearchRequest.getDriverAddress1(),35) );
            locationSearchRequest.setDriverAddress2(AppUtils.stringSizeRefactoring(locationSearchRequest.getDriverAddress2(),35) );
            locationSearchRequest.setDriverCity(AppUtils.stringSizeRefactoring(locationSearchRequest.getDriverCity(),30) );
            locationSearchRequest.setDriverZip(AppUtils.stringSizeRefactoring(locationSearchRequest.getDriverZip(),15) );

            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.addHeaderParameter(AppUtils.MSG_SOURCE, properties.getMsgSource());
            client.addHeaderParameter(AppUtils.MSG_SOURCE_GROUP, properties.getUserNameTSD());
            client.addHeaderParameter(AppUtils.MSG_SOURCE_AUTHENTICATION, properties.getPasswordTSD());
            String bodyRequest = locationSearchRequestTransformer.toJson(locationSearchRequest);
            client.doExecute(properties.getApiTSDServer() + SEARCH_LOCATION_SERVICE, bodyRequest, WebMethodType.POST, AuthorizationType.TSD_TOKEN_ACCESS);
            if (client.isSuccessExecuted()) {
                GenericJSONTransformer<LocationSearchResponse> locationSearchResponseTransformer = TransformerFactory.getTransformer(LocationSearchResponse.class);
                response = AppUtils.sanitize(client.getResponseBody());
                location = locationSearchResponseTransformer.fromJson(response);
            } else {
                log.error(" - Error response location. \n{}", client.getResponseBody());
                throw new HertzAPIException(client.getResponseCode(),client.getResponseBody());
            }
        } catch (HertzAPIException e) {
            log.error(e.getMessage());
            throw e;
        }
        catch (Exception e) {
            log.error(e.getMessage());
            throw new HertzAPIException(0,e.getMessage());

        }
        return location;
    }

    @Override
    public TransactionResponseHeader editReservation(AssignmentRequest assignmentRequest) throws HertzAPIException {
        TransactionResponseHeader result = null;
        GenericJSONTransformer<TransactionResponseHeader> resultTransformer = new GenericJSONTransformer<>(TransactionResponseHeader.class);
        String response = null;
        try {
            GenericJSONTransformer<AssignmentRequest> assignmentRequestTransformer = TransformerFactory.getTransformer(AssignmentRequest.class);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.addHeaderParameter(MSG_SOURCE, properties.getMsgSource());
            client.addHeaderParameter(MSG_SOURCE, properties.getUserNameTSD());
            client.addHeaderParameter(MSG_SOURCE_AUTHENTICATION, properties.getPasswordTSD());
            String bodyRequest = assignmentRequestTransformer.toJson(assignmentRequest);
			log.info("editReservation Url is "+properties.getApiTSDServer() + ASSIGNMENT_SERVICE);
            log.info("Body Request of editReservation service is "+bodyRequest);
            client.doExecute(properties.getApiTSDServer() + ASSIGNMENT_SERVICE, bodyRequest, WebMethodType.PUT, AuthorizationType.TSD_TOKEN_ACCESS);
            if (client.isSuccessExecuted()) {
                response = AppUtils.sanitize(client.getResponseBody());
				  log.info("Body Response of editReservation service is "+response);
                result = resultTransformer.fromJson(response);
            } else {
                log.error(" - There are error trying to create edit reservation. \n{}", client.getResponseBody());
                throw new HertzAPIException(client.getResponseCode(),client.getResponseBody());
            }
        } catch (HertzAPIException e) {
			  log.error("error in editReservation "+e.getMessage());
          
            throw e;
        }catch (Exception e) {
            log.error(e.getMessage());
            throw new HertzAPIException(0,e.getMessage());

        }
        return result;
    }

}
