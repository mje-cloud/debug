package acc.hertz.process;


import acc.hertz.client.composite.ICompositeClient;
import acc.hertz.model.activitypattern.ActivityPattern;
import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.documents.CreateDocument;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestInvoice;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestList;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestPostResponse;
import acc.hertz.model.enums.*;
import acc.hertz.model.hertz.outbound.BaseHertzRequest;
import acc.hertz.model.hertz.outbound.BaseHertzResponse;
import acc.hertz.processors.composite.CompositeResponseMapper;
import acc.hertz.processors.composite.helper.CompositeRentalInvoiceHelper;
import acc.hertz.processors.composite.helper.payload.ActivityPostComposite;
import acc.hertz.processors.composite.helper.payload.HistoryComposite;
import acc.hertz.processors.composite.helper.payload.ServiceRequestPatchComposite;
import acc.hertz.util.AppProperty;
import acc.hertz.util.Converter;
import gw.api.ig.GwUtilities;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

@Named
public class RentalInvoiceProcess {
    @Inject
    private AppProperty property;
    @Inject
    private ReservationHelper reservationHelper;

    @Inject
    private CompositeRentalInvoiceHelper compositeInvoiceHelper;
    @Inject
    private ICompositeClient compositeClient;

    public BaseHertzResponse processRentalInvoice(BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception {
        BaseHertzResponse response = null;
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
        try {
            baseHertzRequest.setTransactionGUID(baseHertzRequest.getTransactionHeaderDetails().getTransactionGuid());
            baseHertzRequest.setTransactionContractId(baseHertzRequest.getRentalInfo().getContractId());

            log.info("processRentalInvoice","Inside the processRentalInvoice class","ClaimNumber",baseHertzRequest.getClaimInfo().getId(), "TransactionType",   baseHertzRequest.getTransactionType(),"method",new Object() {}.getClass().getEnclosingMethod().getName());
            ClaimData claim = reservationHelper.findClaim(exchange,baseHertzRequest);
            ServiceRequestList.ServiceRequest currentService = reservationHelper.findServiceRequestWithReservation(claim,baseHertzRequest,HistoryType.HERTZ_RENTAL_INVOICE_ACC);

            if (baseHertzRequest.getRentalInvoice() != null) {
                if (baseHertzRequest.getRentalInvoice().getBinary() != null && !baseHertzRequest.getRentalInvoice().getBinary().isEmpty()) {
            /*        ServiceRequestPatch serviceRequestPatch = new ServiceRequestPatch();
                    serviceRequestPatch.setData(new ServiceRequestPatch.Data());
                    serviceRequestPatch.getData().setAttributes(new ServiceRequestPatch.Data.Attributes());
                    var patchServReqAttributes = serviceRequestPatch.getData().getAttributes();
                    var baseServReqClaimInfo = baseHertzRequest.getClaimInfo();
                    //var currentServiceRequestAttributes = currentService.getAttributes();
                    patchServReqAttributes.setHertzIncrementalDays_Ext(baseServReqClaimInfo.getIncrementalDays());
                    patchServReqAttributes.setHertzContractStatus_Ext(new ServiceRequestPatch.CodeName());
                    patchServReqAttributes.getHertzContractStatus_Ext().setCode(ContractStatus.RENTAL_INVOICE.getCode());
                    patchServReqAttributes.getHertzContractStatus_Ext().setName(ContractStatus.RENTAL_INVOICE.getName());
                    patchServReqAttributes.setHertzTotalDaysApproved_Ext(baseServReqClaimInfo.getTotalDays()); //Fixed the issue CM-9891
//                    serviceRequestPatch.getData().getAttributes().setHertzIncrementalDays_Ext(0);
//                    serviceRequestPatch.getData().getAttributes().setHertzRentalEndDate_Ext(currentServiceRequestAttributes.getHertzRentalEndDate_Ext());
//                    serviceRequestPatch.getData().getAttributes().setHertzTotalDaysApproved_Ext(currentServiceRequestAttributes.getHertzTotalDaysApproved_Ext());
//                    serviceRequestPatch.getData().getAttributes().setHertzFinalDay_Ext(currentServiceRequestAttributes.getHertzRentalEndDate_Ext());

                    reservationHelper.updateRental(claim,currentService, serviceRequestPatch);*/
                    CreateDocument createDocument = new CreateDocument();
                    String rawRentalEndDateValue=currentService.getAttributes().getHertzRentalEndDate_Ext();
                    String cleanedRentalEndDateValue = rawRentalEndDateValue.replaceAll("[^a-zA-Z0-9 ]", "");
                    String name = "RentalInvoice_No._" + baseHertzRequest.getRentalInvoice().getId() + "_" +cleanedRentalEndDateValue;
                    createDocument.setData(new CreateDocument.Data());
                    createDocument.getData().setAttributes(new CreateDocument.Data.Attributes());
                    createDocument.getData().getAttributes().setAuthor("Hertz");
                    createDocument.getData().getAttributes().setInbound(true);
                    createDocument.getData().getAttributes().setDescription("RentalInvoice_No._" + baseHertzRequest.getRentalInvoice().getId());
                    createDocument.getData().getAttributes().setLanguage(new CreateDocument.Data.Attributes.Language());
                    createDocument.getData().getAttributes().getLanguage().setCode("en_US");
                    createDocument.getData().getAttributes().setName(name);
                    createDocument.getData().getAttributes().setMimeType(MimeType.PDF.getCode());
                    createDocument.getData().getAttributes().setSection(new CreateDocument.Data.Attributes.Section());
                    createDocument.getData().getAttributes().getSection().setCode("misc");
                    createDocument.getData().getAttributes().setSecurityType(new CreateDocument.Data.Attributes.SecurityType());
                    createDocument.getData().getAttributes().getSecurityType().setCode("unrestricted");
                    createDocument.getData().getAttributes().setStatus(new CreateDocument.Data.Attributes.Status());
                    createDocument.getData().getAttributes().getStatus().setCode("final");
                    createDocument.getData().getAttributes().setType(new CreateDocument.Data.Attributes.Type());
                    createDocument.getData().getAttributes().getType().setCode(DocumentType.HERTZ_INVOICE_ACC.getType());
                    createDocument.getData().getAttributes().setRelatedTo(new CreateDocument.Data.Attributes.RelatedTo());
                    createDocument.getData().getAttributes().getRelatedTo().setType(EntityEventType.SERVICE_REQUEST.getType());
                    createDocument.getData().getAttributes().getRelatedTo().setId(currentService.getAttributes().getId());
                    var stickySessionToken =  UUID.randomUUID().toString();
                    if(!reservationHelper.isExistingDocument(exchange,stickySessionToken,claim,createDocument)){
                        if (reservationHelper.addInvoiceDocument(exchange,stickySessionToken, claim, baseHertzRequest, createDocument)) {
                            //Apply composite request only when document was successfully submitted using normal rest api

                            ServiceRequestPatchComposite serviceRequestPatch = new ServiceRequestPatchComposite();
                            serviceRequestPatch.setData(new ServiceRequestPatchComposite.Data());
                            serviceRequestPatch.getData().setAttributes(new ServiceRequestPatchComposite.Data.Attributes());
                            var patchServReqAttributes = serviceRequestPatch.getData().getAttributes();
                            var baseServReqClaimInfo = baseHertzRequest.getClaimInfo();
                            patchServReqAttributes.setHertzIncrementalDays_Ext(baseServReqClaimInfo.getIncrementalDays());
                            patchServReqAttributes.setHertzContractStatus_Ext(new ServiceRequestPatchComposite.CodeName());
                            patchServReqAttributes.getHertzContractStatus_Ext().setCode(ContractStatus.RENTAL_INVOICE.getCode());
                            patchServReqAttributes.getHertzContractStatus_Ext().setName(ContractStatus.RENTAL_INVOICE.getName());
                            patchServReqAttributes.setHertzTotalDaysApproved_Ext(baseServReqClaimInfo.getTotalDays()); //Fixed the issue CM-9891

                            HistoryComposite newHistory = new HistoryComposite();
                            newHistory.setData(new HistoryComposite.Data());
                            newHistory.getData().setAttributes(new HistoryComposite.Data.Attributes());
                            newHistory.getData().getAttributes().setClaim(new HistoryComposite.Data.Attributes.Claim());
                            newHistory.getData().getAttributes().getClaim().setId(claim.getData().getAttributes().getId());
                            newHistory.getData().getAttributes().getClaim().setType(EntityEventType.CLAIM.getType());
                            newHistory.getData().getAttributes().setServiceRequest(new HistoryComposite.Data.Attributes.ServiceRequest());
                            newHistory.getData().getAttributes().setUser(new HistoryComposite.Data.Attributes.User());
                            newHistory.getData().getAttributes().getUser().setId(claim.getData().getAttributes().getAssignedUser().getId());
                            newHistory.getData().getAttributes().getUser().setType(EntityEventType.USER.getType());
                            newHistory.getData().getAttributes().setType(new HistoryComposite.Data.Attributes.Type());
                            newHistory.getData().getAttributes().getType().setCode(HistoryType.HERTZ_RENTAL_INVOICE_ACC.getCode());
                            newHistory.getData().getAttributes().getType().setName(HistoryType.HERTZ_RENTAL_INVOICE_ACC.getName());
                            newHistory.getData().getAttributes().setDescription(HistoryType.HERTZ_RENTAL_INVOICE_ACC.getDescription());
                            baseHertzRequest.getRentalInvoice().setBinary("");
                            newHistory.getData().getAttributes().setRequest(reservationHelper.parseRequestAsJSON(baseHertzRequest));

                            ActivityPostComposite newActivity = new ActivityPostComposite();
                            newActivity.setData(new ActivityPostComposite.Data());
                            newActivity.getData().setAttributes(new ActivityPostComposite.Attributes());
                            newActivity.getData().getAttributes().setActivityPattern(ActivityPattern.HERTZ_RENTAL_INVOICE_ACC.getCode());
                            newActivity.getData().getAttributes().setRelatedTo(new ActivityPostComposite.RelatedTo());
                            newActivity.getData().getAttributes().setSubject(ActivityPattern.HERTZ_RENTAL_INVOICE_ACC.getSubject());
                            newActivity.getData().getAttributes().setDescription(ActivityPattern.HERTZ_RENTAL_INVOICE_ACC.getDescription());

                            var abstractRequest = compositeInvoiceHelper.buildCompositeRequest(claim,
                                    currentService,
                                    serviceRequestPatch,
                                    newHistory,
                                    newActivity);
                            String result = compositeClient.executeCompositeRequest(exchange, stickySessionToken, abstractRequest);
                            ServiceRequestPostResponse compositeBodyResponse = CompositeResponseMapper.mapFirstResponse(result, ServiceRequestPostResponse.class);
                            Thread.sleep(10000);

                            ServiceRequestInvoice newInvoice = new ServiceRequestInvoice();
                            newInvoice.setData(new ServiceRequestInvoice.Data());
                            newInvoice.getData().setAttributes(new ServiceRequestInvoice.Attributes());
                            newInvoice.getData().getAttributes().setDescription("New Rental Invoice No. " + baseHertzRequest.getRentalInvoice().getId());
                            newInvoice.getData().getAttributes().setPaymentDate(Converter.parseDateToStringUSFormat(Converter.parseStringToDateUSFormat(baseHertzRequest.getRentalInfo().getEndDate())));
                            newInvoice.getData().getAttributes().setReferenceNumber( baseHertzRequest.getRentalInvoice().getId());
                            newInvoice.getData().getAttributes().setSource(new ServiceRequestInvoice.CodeName());
                            newInvoice.getData().getAttributes().getSource().setCode(InvoiceSource.PORTAL_API.getCode());
                            newInvoice.getData().getAttributes().getSource().setName(InvoiceSource.PORTAL_API.getName());
                            newInvoice.getData().getAttributes().setLineItems(new ArrayList<>());
                            ServiceRequestInvoice.LineItem lineItem = new ServiceRequestInvoice.LineItem();
                            lineItem.setAmount(new ServiceRequestInvoice.Amount());
                            lineItem.getAmount().setAmount(new BigDecimal(String.valueOf(baseHertzRequest.getRentalInvoice().getTotalBillAmt())).toPlainString());
                            lineItem.getAmount().setCurrency(reservationHelper.getDefaultCurrency());
                            lineItem.setCategory(new ServiceRequestInvoice.CodeName());
                            lineItem.getCategory().setCode(InvoiceStatemenLineCategory.LINE_OTHER.getCode());
                            lineItem.getCategory().setName(InvoiceStatemenLineCategory.LINE_OTHER.getName());
                            lineItem.setDescription("Hertz Rental Charge");
                            newInvoice.getData().getAttributes().getLineItems().add(lineItem);
                            ////Move to requested state using normal Rest Call since Composite DO NOT SUPPORT invoice
                            reservationHelper.createNewInvoiceForService(stickySessionToken,claim,currentService,newInvoice);

                           /* History newHistory = new History();
                            newHistory.setData(new History.Data());
                            newHistory.getData().setAttributes(new History.Data.Attributes());
                            newHistory.getData().getAttributes().setClaim(new History.Data.Attributes.Claim());
                            newHistory.getData().getAttributes().getClaim().setId(claim.getData().getAttributes().getId());
                            newHistory.getData().getAttributes().getClaim().setType(EntityEventType.CLAIM.getType());
                            newHistory.getData().getAttributes().setServiceRequest(new History.Data.Attributes.ServiceRequest());
                            newHistory.getData().getAttributes().getServiceRequest().setId(currentService.getAttributes().getId());
                            newHistory.getData().getAttributes().getClaim().setType(EntityEventType.SERVICE_REQUEST.getType());
                            newHistory.getData().getAttributes().setUser(new History.Data.Attributes.User());
                            newHistory.getData().getAttributes().getUser().setId(claim.getData().getAttributes().getAssignedUser().getId());
                            newHistory.getData().getAttributes().getUser().setType(EntityEventType.USER.getType());
                            newHistory.getData().getAttributes().setType(new History.Data.Attributes.Type());
                            newHistory.getData().getAttributes().getType().setCode(HistoryType.HERTZ_RENTAL_INVOICE_ACC.getCode());
                            newHistory.getData().getAttributes().getType().setName(HistoryType.HERTZ_RENTAL_INVOICE_ACC.getName());
                            newHistory.getData().getAttributes().setDescription(HistoryType.HERTZ_RENTAL_INVOICE_ACC.getDescription().replace("$1", baseHertzRequest.getRentalInvoice().getId()));
                            baseHertzRequest.getRentalInvoice().setBinary("");
                            newHistory.getData().getAttributes().setRequest(ReservationHelper.parseRequestAsJSON(baseHertzRequest));

                            reservationHelper.createHistoryRecord(exchange, newHistory);*/

                     /*       ActivityPost newActivity = new ActivityPost();
                            newActivity.setData(new ActivityPost.Data());
                            newActivity.getData().setAttributes(new ActivityPost.Attributes());
                            newActivity.getData().getAttributes().setActivityPattern(ActivityPattern.HERTZ_RENTAL_INVOICE_ACC.getCode());
                            newActivity.getData().getAttributes().setRelatedTo(new ActivityPost.RelatedTo());
                            newActivity.getData().getAttributes().getRelatedTo().setId(currentService.getAttributes().getId());
                            newActivity.getData().getAttributes().getRelatedTo().setType(EntityEventType.SERVICE_REQUEST.getType());
                            newActivity.getData().getAttributes().setSubject(ActivityPattern.HERTZ_RENTAL_INVOICE_ACC.getSubject());
                            newActivity.getData().getAttributes().setDescription(ActivityPattern.HERTZ_RENTAL_INVOICE_ACC.getDescription());
                            reservationHelper.createActivityRecord(claim, newActivity);*/

                            response = new BaseHertzResponse();
                            response.setMessage(HistoryType.HERTZ_RENTAL_INVOICE_ACC.getName() + " processed");
                            response.setMsgType("success");
                            response.setTransactionGuid(baseHertzRequest.getTransactionGUID());
                            response.setTransactionContractId(baseHertzRequest.getTransactionContractId());
                            response.setTransactionType(baseHertzRequest.getTransactionHeaderDetails().getTransactionType());
                            response.setMsgGuid(baseHertzRequest.getTransactionHeaderDetails().getMsgGuid());
                            response.setTransactionDate(baseHertzRequest.getTransactionHeaderDetails().getTransactionDate());
                            response.setMsgDate(Converter.parseDateToJSON(new Date()));

                        }
                    } else{
                        log.info("Document invoice already exist " + createDocument.getData().getAttributes().getName() + " Type Document " + createDocument.getData().getAttributes().getType().getCode(), new Object() {
                        }.getClass().getEnclosingMethod().getName());
                        throw new Exception("Document invoice already exist"+  createDocument.getData().getAttributes().getName() + " Type Document " + createDocument.getData().getAttributes().getType().getCode());
                    }
                } else {
                    log.info("No invoice binary content found Invoice" , new Object(){}.getClass().getEnclosingMethod().getName());
                    throw new Exception("No invoice binary content found Invoice");
                }
            } else {
                log.info("No invoice information found", new Object(){}.getClass().getEnclosingMethod().getName());
                throw new Exception("No invoice information found");

            }

        } catch (Exception e) {
            log.error("RentalInvoiceProcess Error: "+ e.getMessage(), new Object(){}.getClass().getEnclosingMethod().getName(),e);
            throw e;
        }
        return response;

    }
}