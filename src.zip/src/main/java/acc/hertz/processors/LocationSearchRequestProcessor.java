package acc.hertz.processors;

import acc.hertz.api.IRest;
import acc.hertz.model.hertz.inbound.LocationSearchRequest;
import acc.hertz.model.hertz.inbound.LocationSearchResponse;
import acc.hertz.model.response.IResponseHandler;
import gw.api.ig.GwUtilities;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.hc.core5.http.HttpStatus;

import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named
public class LocationSearchRequestProcessor implements Processor {
    @Inject
    private IResponseHandler IResponseHandler;
    @Inject
    private IRest tsdRest;

    @Override
    public void process(Exchange exchange) throws Exception {
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
        try {
            LocationSearchRequest locationSearchRequest = exchange.getIn().getBody(LocationSearchRequest.class);
            if (locationSearchRequest == null) {
                log.info("LocationSearchRequestProcessor","LocationSearchRequest is null"," unable to proceed." ,new Object(){}.getClass().getEnclosingMethod().getName());
            }
            else{
               LocationSearchResponse location = tsdRest.getLocation(locationSearchRequest);
                if (location != null) {
                    log.debug("LocationSearchRequestProcessor","LocationSearchResponse retrieved successfully");
                    exchange.getMessage().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.SC_OK);
                    exchange.getMessage().setBody(location);
                } else {
                    log.info("LocationSearchRequestProcessor","LocationSearchResponse is null","There is an error trying to get the location" ,new Object(){}.getClass().getEnclosingMethod().getName());
                    IResponseHandler.handleResponse(exchange, "There is an error trying to get the location.", new String[]{exchange.getIn().getBody(LocationSearchRequest.class).toString()}, HttpStatus.SC_NOT_FOUND);
                }
            }
        } catch (Exception exception) {
            log.error("LocationSearchRequestProcessor","There is an error trying process the location" ,exception);
        }
    }
}
