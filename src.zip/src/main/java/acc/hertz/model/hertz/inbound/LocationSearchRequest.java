package acc.hertz.model.hertz.inbound;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LocationSearchRequest {

    @JsonProperty("MSGGuid")
    private String msgGuid;

    @JsonProperty("MSGDate")
    private String msgDate;

    @JsonProperty("TransactionDate")
    private String transactionDate;

    @JsonProperty("TransactionGUID")
    private String transactionGUID;

    @JsonProperty("TransactionType")
    private String transactionType;

    @JsonProperty("ResultCount")
    private int resultCount;

    @JsonProperty("DriverAddress1")
    private String driverAddress1;

    @JsonProperty("DriverAddress2")
    private String driverAddress2;

    @JsonProperty("DriverCity")
    private String driverCity;

    @JsonProperty("DriverState")
    private String driverState;

    @JsonProperty("DriverCountry")
    private String driverCountry;

    @JsonProperty("DriverZip")
    private String driverZip;

    // Constructors
    public LocationSearchRequest() {
    }
    // Getters and Setters
    public String getMsgGuid() {
        return msgGuid;
    }

    public void setMsgGuid(String msgGuid) {
        this.msgGuid = msgGuid;
    }

    public String getMsgDate() {
        return msgDate;
    }

    public void setMsgDate(String msgDate) {
        this.msgDate = msgDate;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getTransactionGUID() {
        return transactionGUID;
    }

    public void setTransactionGUID(String transactionGUID) {
        this.transactionGUID = transactionGUID;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public int getResultCount() {
        return resultCount;
    }

    public void setResultCount(int resultCount) {
        this.resultCount = resultCount;
    }

    public String getDriverAddress1() {
        return driverAddress1;
    }

    public void setDriverAddress1(String driverAddress1) {
        this.driverAddress1 = driverAddress1;
    }

    public String getDriverAddress2() {
        return driverAddress2;
    }

    public void setDriverAddress2(String driverAddress2) {
        this.driverAddress2 = driverAddress2;
    }

    public String getDriverCity() {
        return driverCity;
    }

    public void setDriverCity(String driverCity) {
        this.driverCity = driverCity;
    }

    public String getDriverState() {
        return driverState;
    }

    public void setDriverState(String driverState) {
        this.driverState = driverState;
    }

    public String getDriverCountry() {
        return driverCountry;
    }

    public void setDriverCountry(String driverCountry) {
        this.driverCountry = driverCountry;
    }

    public String getDriverZip() {
        return driverZip;
    }

    public void setDriverZip(String driverZip) {
        this.driverZip = driverZip;
    }
}
