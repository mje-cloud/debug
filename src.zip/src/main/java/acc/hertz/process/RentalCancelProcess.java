package acc.hertz.process;

import acc.hertz.client.composite.ICompositeClient;
import acc.hertz.model.activitypattern.ActivityPattern;
import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestDecline;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestList;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestPostResponse;
import acc.hertz.model.enums.*;
import acc.hertz.model.hertz.outbound.BaseHertzRequest;
import acc.hertz.model.hertz.outbound.BaseHertzResponse;
import acc.hertz.model.hertz.shared.AdditionalCharges;
import acc.hertz.processors.composite.CompositeResponseMapper;
import acc.hertz.processors.composite.helper.CompositeRentalCancelHelper;
import acc.hertz.processors.composite.helper.payload.ActivityPostComposite;
import acc.hertz.processors.composite.helper.payload.HistoryComposite;
import acc.hertz.processors.composite.helper.payload.ServiceRequestPostComposite;
import acc.hertz.util.AppProperty;
import acc.hertz.util.AppUtils;
import acc.hertz.util.Converter;
import gw.api.ig.GwUtilities;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;

import java.util.Date;
import java.util.UUID;


@Named
public class RentalCancelProcess {
    @Inject
    private AppProperty property;
    @Inject
    private ReservationHelper reservationHelper;
    @Inject
    private CompositeRentalCancelHelper compositeRentalCancelHelper;
    @Inject
    private ICompositeClient compositeClient;

    public BaseHertzResponse processRentalCancel(BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception {
        BaseHertzResponse response = null;
        ServiceRequestPostComposite serviceRequestPost = null;
        ServiceRequestList.ServiceRequest currentServiceRequest = null;
        var errorMessage = "";
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();

        try {
            ClaimData claim = reservationHelper.findClaim(exchange, baseHertzRequest);
            try {
                currentServiceRequest = reservationHelper.findServiceRequestWithReservation(claim, baseHertzRequest, HistoryType.HERTZ_CANCEL_RESERVATION_ACC);
                log.info("processRentalCancel", "Inside the processRentalCancel class", "ClaimNumber", baseHertzRequest.getClaimInfo().getId(), "TransactionType", baseHertzRequest.getTransactionType(), "method", new Object() {
                }.getClass().getEnclosingMethod().getName(), "ServiceRequestNumber", currentServiceRequest.getAttributes().getServiceRequestNumber());
            } catch (Exception e) {
                log.error("processRentalCancel", "Inside the processRentalCancel Exception block ", e, "ClaimNumber", baseHertzRequest.getClaimInfo().getId(), "TransactionType", baseHertzRequest.getTransactionType(), "method", new Object() {
                }.getClass().getEnclosingMethod().getName());
            } finally {
                if (currentServiceRequest == null) {
                    response = new BaseHertzResponse();
                    response.setMessage(HistoryType.HERTZ_CANCEL_RESERVATION_ACC.getName() + " processed but Contract ID " + baseHertzRequest.getTransactionContractId() + " not found");
                    response.setMsgType("success");
                    response.setTransactionGuid(baseHertzRequest.getTransactionGUID());
                    response.setTransactionContractId(baseHertzRequest.getTransactionContractId());
                    response.setTransactionType(baseHertzRequest.getTransactionType());
                    response.setMsgGuid(baseHertzRequest.getTransactionGUID());
                    response.setTransactionDate(baseHertzRequest.getTransactionDate());
                    response.setMsgDate(Converter.parseDateToJSON(new Date()));
                    return response;
                }
            }

            var currentServiceRequestAttributes = currentServiceRequest.getAttributes();
            var hertzContractStatusCode = currentServiceRequestAttributes.getHertzContractStatus_Ext().getCode();
            var serviceRequestProgressCode = currentServiceRequestAttributes.getProgress().getCode();
            var baseServReqClaimInfo = baseHertzRequest.getClaimInfo();
            var baseServReqRentalInfo = baseHertzRequest.getRentalInfo();

            if (hertzContractStatusCode.equalsIgnoreCase(ContractStatus.RENTAL_CLOSE.getCode()) || hertzContractStatusCode.equalsIgnoreCase(ContractStatus.RENTAL_CANCEL.getCode())) {
                log.info("processRentalCancel", "processRentalCancel processed successfully", "ClaimNumber", baseHertzRequest.getClaimInfo().getId(), "TransactionType", baseHertzRequest.getTransactionType(), "method", new Object() {
                }.getClass().getEnclosingMethod().getName(), "ServiceRequestNumber", currentServiceRequest.getAttributes().getServiceRequestNumber(), "HertzContractStatusCode", hertzContractStatusCode);
                response = new BaseHertzResponse();
                response.setMessage(HistoryType.HERTZ_CANCEL_RESERVATION_ACC.getName() + " processed");
                response.setMsgType("success");
                response.setTransactionGuid(baseHertzRequest.getTransactionGUID());
                response.setTransactionContractId(baseHertzRequest.getTransactionContractId());
                response.setTransactionType(baseHertzRequest.getTransactionType());
                response.setMsgGuid(baseHertzRequest.getTransactionGUID());
                response.setTransactionDate(baseHertzRequest.getTransactionDate());
                response.setMsgDate(Converter.parseDateToJSON(new Date()));
                return response;
            }

            if (hertzContractStatusCode.equalsIgnoreCase(ContractStatus.RESERVATION_PENDING.getCode()) ||
                    hertzContractStatusCode.equalsIgnoreCase(ContractStatus.RESERVATION_CONFIRMED.getCode()) ||
                    hertzContractStatusCode.equalsIgnoreCase(ContractStatus.RESERVATION_OPEN_WALKUP.getCode())) {
                if (!serviceRequestProgressCode.equalsIgnoreCase(ServiceRequestProgress.DRAFT.getCode())
                        && !serviceRequestProgressCode.equalsIgnoreCase(ServiceRequestProgress.REQUESTED.getCode())) {
                    log.info("processRentalCancel",
                            "Reservation can not be cancel if service request is not in ",
                            "ClaimNumber", baseHertzRequest.getClaimInfo().getId(), "TransactionType", baseHertzRequest.getTransactionType(), "method", new Object() {
                            }.getClass().getEnclosingMethod().getName(),
                            "ServiceRequestNumber", currentServiceRequest.getAttributes().getServiceRequestNumber(),
                            "HertzContractStatusCode", hertzContractStatusCode);
                    throw new Exception(errorMessage);
                }
            } else {
                log.info("processRentalCancel", " Reservation can not be cancelled using the current Contract Status ",
                        "ClaimNumber", baseHertzRequest.getClaimInfo().getId(), "TransactionType", baseHertzRequest.getTransactionType(), "method", new Object() {
                        }.getClass().getEnclosingMethod().getName(), "ServiceRequestNumber", currentServiceRequest.getAttributes().getServiceRequestNumber(), "HertzContractStatusCode", hertzContractStatusCode);
                log.info(errorMessage, new Object() {
                }.getClass().getEnclosingMethod().getName());
                throw new Exception(errorMessage);
            }

            serviceRequestPost = new ServiceRequestPostComposite();
            serviceRequestPost.setData(new ServiceRequestPostComposite.Data());
            serviceRequestPost.getData().setAttributes(new ServiceRequestPostComposite.Attributes());
            var postServReqAttributes = serviceRequestPost.getData().getAttributes();
            postServReqAttributes.setHertzContractStatus_Ext(new ServiceRequestPostComposite.CodeName());
            postServReqAttributes.getHertzContractStatus_Ext().setCode(ContractStatus.RENTAL_CANCEL.getCode());
            postServReqAttributes.getHertzContractStatus_Ext().setName(ContractStatus.RENTAL_CANCEL.getName());
            postServReqAttributes.setHertzClassCode_Ext(baseServReqClaimInfo.getRentalRequestedClass());
            postServReqAttributes.setHertzClassName_Ext(baseServReqRentalInfo.getRateClass());
            postServReqAttributes.setHertzCustomerSelfPay_Ext(currentServiceRequestAttributes.isHertzCustomerSelfPay_Ext());
            postServReqAttributes.setHertzDateType_Ext(new ServiceRequestPostComposite.CodeName());
            postServReqAttributes.getHertzDateType_Ext().setCode(DateType.CALENDAR_DAY.getCode());
            postServReqAttributes.getHertzDateType_Ext().setName(DateType.CALENDAR_DAY.getName());
            postServReqAttributes.setHertzDayCount_Ext(baseServReqClaimInfo.getTotalDays());
            postServReqAttributes.setHertzIncrementalDays_Ext(baseServReqClaimInfo.getIncrementalDays());

            postServReqAttributes.setHertzMaxAuthAmount_Ext(new ServiceRequestPostComposite.Amount());
            postServReqAttributes.getHertzMaxAuthAmount_Ext().setAmount(String.valueOf(baseHertzRequest.getPolicy().getMaxCoverage()));
            postServReqAttributes.getHertzMaxAuthAmount_Ext().setCurrency(reservationHelper.getDefaultCurrency());
            postServReqAttributes.setHertzRateInclusivePrice_Ext(new ServiceRequestPostComposite.Amount());
            postServReqAttributes.getHertzRateInclusivePrice_Ext().setAmount(AppUtils.getValidCurrencyAmount(String.valueOf(baseServReqClaimInfo.getRentalDailyAmount())));
            postServReqAttributes.getHertzRateInclusivePrice_Ext().setCurrency(reservationHelper.getDefaultCurrency());

            if (baseHertzRequest.getPolicy().getDailyMaxCoverage() > 0) {
                postServReqAttributes.setHertzRentalDailyAmount_Ext(new ServiceRequestPostComposite.Amount());
                postServReqAttributes.getHertzRentalDailyAmount_Ext().setAmount(String.valueOf(baseHertzRequest.getPolicy().getMaxCoverage()));
                postServReqAttributes.getHertzRentalDailyAmount_Ext().setCurrency(reservationHelper.getDefaultCurrency());
            } else {
                postServReqAttributes.setHertzRentalDailyAmount_Ext(new ServiceRequestPostComposite.Amount());
                postServReqAttributes.getHertzRentalDailyAmount_Ext().setAmount(String.valueOf(baseServReqClaimInfo.getRentalDailyAmount()));
                postServReqAttributes.getHertzRentalDailyAmount_Ext().setCurrency(reservationHelper.getDefaultCurrency());
            }
            if (baseServReqClaimInfo.getPayTaxes() != null)
                postServReqAttributes.setHertzPayAllTaxes_Ext(!baseServReqClaimInfo.getPayTaxes().equalsIgnoreCase("N"));

            postServReqAttributes.setHertzPercentagePay_Ext(String.valueOf(baseHertzRequest.getPolicy().getPercentPay()));
            postServReqAttributes.setHertzPickupDate_Ext(baseServReqRentalInfo.getPickupDate());
            postServReqAttributes.setHertzRentalBeginDate_Ext(AppUtils.getDateISO8601(baseServReqRentalInfo.getStartDate()));

            var endDate = baseServReqRentalInfo.getEndDate() != null ? AppUtils.getDateISO8601(baseServReqRentalInfo.getEndDate()) : null;
            if (endDate == null) {
                if (baseServReqClaimInfo.getTotalDays() > 0) {
                    endDate = Converter.parseDateToStringUSFormat(Converter.addDays(Converter.parseStringToDateUSFormat(baseServReqRentalInfo.getStartDate()), baseServReqClaimInfo.getTotalDays() - 1));
                }
            }
            postServReqAttributes.setHertzRentalEndDate_Ext(endDate);

            postServReqAttributes.setHertzRateType_Ext(new ServiceRequestPostComposite.CodeName());
            RateType rate = RateType.fromType(baseServReqRentalInfo.getRateClass());
            postServReqAttributes.getHertzRateType_Ext().setCode(rate.getCode());
            postServReqAttributes.getHertzRateType_Ext().setName(rate.getDescription());
            postServReqAttributes.setHertzRentalCompany_Ext(new ServiceRequestPostComposite.CodeName());
            postServReqAttributes.getHertzRentalCompany_Ext().setCode(RentalCompany.HERTZ.getCode());
            postServReqAttributes.getHertzRentalCompany_Ext().setName(RentalCompany.HERTZ.getDescription());
            postServReqAttributes.setHertzTransactionDate_Ext(AppUtils.getDateISO8601(baseHertzRequest.getTransactionDate()));
            RentalRole rentalRole = RentalRole.fromType(baseServReqClaimInfo.getType());
            postServReqAttributes.setHertzRentalRole_Ext(new ServiceRequestPostComposite.CodeName());
            postServReqAttributes.getHertzRentalRole_Ext().setCode(rentalRole.getCode());
            postServReqAttributes.getHertzRentalRole_Ext().setName(rentalRole.getName());

            postServReqAttributes.setHertzTotalDaysApproved_Ext(baseServReqClaimInfo.getTotalDays());
            postServReqAttributes.setHertzRequestType_Ext(false);
            postServReqAttributes.setHertzIncrementalDays_Ext(baseServReqClaimInfo.getIncrementalDays());
            postServReqAttributes.setHertzTransactionTSDID_Ext(baseServReqRentalInfo.getContractId());
            postServReqAttributes.setHertzTransactionContractID_Ext(baseServReqRentalInfo.getContractId());
            postServReqAttributes.setHertzTransactionGUID_Ext(baseHertzRequest.getTransactionGUID());

            /*Additional Charges*/
            var additionalCharges = baseHertzRequest.getClaimInfo().getAdditionalCharges();
            if (additionalCharges != null && additionalCharges.size() > 0) {
                for (AdditionalCharges charge : additionalCharges) {
                    if (AdditionalChargeType.LOST_DAMAGE_WAIVER.getCode().equalsIgnoreCase(charge.getCode())) {
                        postServReqAttributes.setHertzLossDamageWaiver_Ext(true);
                    } else if (AdditionalChargeType.WINTER_TIRES.getCode().equalsIgnoreCase(charge.getCode())) {
                        postServReqAttributes.setHertzWinterTires_Ext(true);
                    }
                }
            } else {
                postServReqAttributes.setHertzLossDamageWaiver_Ext(currentServiceRequestAttributes.isHertzLossDamageWaiver_Ext());
                postServReqAttributes.setHertzWinterTires_Ext(currentServiceRequestAttributes.isHertzWinterTires_Ext());
            }

            HistoryComposite history = new HistoryComposite();
            history.setData(new HistoryComposite.Data());
            history.getData().setAttributes(new HistoryComposite.Data.Attributes());
            history.getData().getAttributes().setClaim(new HistoryComposite.Data.Attributes.Claim());
            history.getData().getAttributes().getClaim().setId(claim.getData().getAttributes().getId());
            history.getData().getAttributes().getClaim().setType(EntityEventType.CLAIM.getType());
            history.getData().getAttributes().setServiceRequest(new HistoryComposite.Data.Attributes.ServiceRequest());
            history.getData().getAttributes().setUser(new HistoryComposite.Data.Attributes.User());
            history.getData().getAttributes().getUser().setId(claim.getData().getAttributes().getAssignedUser().getId());
            history.getData().getAttributes().getUser().setType(EntityEventType.USER.getType());
            history.getData().getAttributes().setType(new HistoryComposite.Data.Attributes.Type());
            history.getData().getAttributes().getType().setCode(HistoryType.HERTZ_CANCEL_RESERVATION_ACC.getCode());
            history.getData().getAttributes().getType().setName(HistoryType.HERTZ_CANCEL_RESERVATION_ACC.getName());
            history.getData().getAttributes().setDescription(HistoryType.HERTZ_CANCEL_RESERVATION_ACC.getDescription()
                    .replace("$1", (baseServReqClaimInfo.getClaimNoteRentalInstructions() != null ? baseServReqClaimInfo.getClaimNoteRentalInstructions() : ""))
                    .replace("$2", TransactionType.STATUS_CANCEL.getDescription()));
            history.getData().getAttributes().setRequest(reservationHelper.parseRequestAsJSON(baseHertzRequest));


            //CM-8706
            ActivityPostComposite newActivity = new ActivityPostComposite();
            newActivity.setData(new ActivityPostComposite.Data());
            newActivity.getData().setAttributes(new ActivityPostComposite.Attributes());
            newActivity.getData().getAttributes().setActivityPattern(ActivityPattern.HERTZ_RENTAL_CANCEL_ACC.getCode());
            newActivity.getData().getAttributes().setRelatedTo(new ActivityPostComposite.RelatedTo());
            newActivity.getData().getAttributes().setSubject(ActivityPattern.HERTZ_RENTAL_CANCEL_ACC.getSubject());
            newActivity.getData().getAttributes().setDescription(ActivityPattern.HERTZ_RENTAL_CANCEL_ACC.getDescription());
            try {
                String stickySessionToken = UUID.randomUUID().toString();
                var abstractRequest = compositeRentalCancelHelper.buildCompositeRequest(claim,
                        baseHertzRequest,
                        currentServiceRequest,
                        serviceRequestPost,
                        history, newActivity);
                String result = compositeClient.executeCompositeRequest(exchange, stickySessionToken, abstractRequest);
                ServiceRequestPostResponse compositeBodyResponse = CompositeResponseMapper.mapFirstResponse(result, ServiceRequestPostResponse.class);

                Thread.sleep(property.getServiceCallSleepTime());
                if (compositeBodyResponse.getData().getAttributes().getProgress().getCode().equalsIgnoreCase(ServiceRequestProgress.DRAFT.getCode())) {
                    //Move to requested state
                    reservationHelper.markAsSubmitted(stickySessionToken, claim, compositeBodyResponse.getData().getAttributes().getId());
                    //Then move to decline state using id created
                    ServiceRequestDecline decline = new ServiceRequestDecline();
                    decline.setData(new ServiceRequestDecline.Data());
                    decline.getData().setAttributes(new ServiceRequestDecline.Attributes());
                    decline.getData().getAttributes().setReason("Hertz declined the reservation " + baseHertzRequest.getTransactionGUID());
                    reservationHelper.markAsDeclined(stickySessionToken, claim, currentServiceRequest, decline);
                } else {
                    if (compositeBodyResponse.getData().getAttributes().getProgress().getCode().equalsIgnoreCase(ServiceRequestProgress.REQUESTED.getCode())) {
                        //Then move to decline state using id created
                        ServiceRequestDecline decline = new ServiceRequestDecline();
                        decline.setData(new ServiceRequestDecline.Data());
                        decline.getData().setAttributes(new ServiceRequestDecline.Attributes());
                        decline.getData().getAttributes().setReason("Hertz declined the reservation " + baseHertzRequest.getTransactionGUID());
                        reservationHelper.markAsDeclined(stickySessionToken, claim, currentServiceRequest, decline);
                    }
                }

                if (compositeBodyResponse.getData().getAttributes().getProgress().getCode().equalsIgnoreCase(ServiceRequestProgress.IN_PROGRESS.getCode())) {
                    ServiceRequestDecline decline = new ServiceRequestDecline();
                    decline.setData(new ServiceRequestDecline.Data());
                    decline.getData().setAttributes(new ServiceRequestDecline.Attributes());
                    decline.getData().getAttributes().setReason("Hertz declined the reservation " + baseHertzRequest.getTransactionGUID());
                    reservationHelper.markAsDeclined(stickySessionToken, claim, currentServiceRequest, decline);
                }

           /*     History newHistory = new History();
                newHistory.setData(new History.Data());
                newHistory.getData().setAttributes(new History.Data.Attributes());
                newHistory.getData().getAttributes().setClaim(new History.Data.Attributes.Claim());
                newHistory.getData().getAttributes().getClaim().setId(claim.getData().getAttributes().getId());
                newHistory.getData().getAttributes().getClaim().setType(EntityEventType.CLAIM.getType());
                newHistory.getData().getAttributes().setServiceRequest(new History.Data.Attributes.ServiceRequest());
                newHistory.getData().getAttributes().getServiceRequest().setId(responseRental.getData().getAttributes().getId());
                newHistory.getData().getAttributes().getClaim().setType(EntityEventType.SERVICE_REQUEST.getType());
                newHistory.getData().getAttributes().setUser(new History.Data.Attributes.User());
                newHistory.getData().getAttributes().getUser().setId(claim.getData().getAttributes().getAssignedUser().getId());
                newHistory.getData().getAttributes().getUser().setType(EntityEventType.USER.getType());
                newHistory.getData().getAttributes().setType(new History.Data.Attributes.Type());
                newHistory.getData().getAttributes().getType().setCode(HistoryType.HERTZ_CANCEL_RESERVATION_ACC.getCode());
                newHistory.getData().getAttributes().getType().setName(HistoryType.HERTZ_CANCEL_RESERVATION_ACC.getName());
                newHistory.getData().getAttributes().setDescription(HistoryType.HERTZ_CANCEL_RESERVATION_ACC.getDescription()
                        .replace("$1",(baseServReqClaimInfo.getClaimNoteRentalInstructions() != null ? baseServReqClaimInfo.getClaimNoteRentalInstructions() : ""))
                        .replace("$2",TransactionType.STATUS_CANCEL.getDescription()));
                newHistory.getData().getAttributes().setRequest(ReservationHelper.parseRequestAsJSON(baseHertzRequest));
                reservationHelper.createHistoryRecord(exchange, newHistory);

                //CM-8706
                ActivityPost newActivity = new ActivityPost();
                newActivity.setData(new ActivityPost.Data());
                newActivity.getData().setAttributes(new ActivityPost.Attributes());
                newActivity.getData().getAttributes().setActivityPattern(ActivityPattern.HERTZ_RENTAL_CANCEL_ACC.getCode());
                newActivity.getData().getAttributes().setRelatedTo(new ActivityPost.RelatedTo());
                newActivity.getData().getAttributes().getRelatedTo().setId(responseRental.getData().getAttributes().getId());
                newActivity.getData().getAttributes().getRelatedTo().setType(EntityEventType.SERVICE_REQUEST.getType());
                newActivity.getData().getAttributes().setSubject(ActivityPattern.HERTZ_RENTAL_CANCEL_ACC.getSubject());
                newActivity.getData().getAttributes().setDescription(ActivityPattern.HERTZ_RENTAL_CANCEL_ACC.getDescription());
                reservationHelper.createActivityRecord(claim, newActivity);*/

                response = new BaseHertzResponse();
                response.setMessage(HistoryType.HERTZ_CANCEL_RESERVATION_ACC.getName() + " processed");
                response.setMsgType("success");
                response.setTransactionGuid(baseHertzRequest.getTransactionGUID());
                response.setTransactionContractId(baseHertzRequest.getTransactionContractId());
                response.setTransactionType(baseHertzRequest.getTransactionType());
                response.setMsgGuid(baseHertzRequest.getTransactionGUID());
                response.setTransactionDate(baseHertzRequest.getTransactionDate());
                response.setMsgDate(Converter.parseDateToJSON(new Date()));
            } catch (Exception e) {
                log.info(e.getMessage(), new Object() {
                }.getClass().getEnclosingMethod().getName());
            }

        } catch (Exception e) {
            log.error("processRentalCancel Error", new Object() {
            }.getClass().getEnclosingMethod().getName(), e);
            throw e;
        }
        return response;
    }
}