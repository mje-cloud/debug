package acc.hertz.model.cloudapi.documents;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class DocumentResponse {

    @JsonProperty("count")
    private int count;

    @JsonProperty("data")
    private List<Data> data;

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Getter
    @Setter
    public static class Data {

        @JsonProperty("attributes")
        private Attributes attributes;

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Getter
        @Setter
        public static class Attributes {

            @JsonProperty("author")
            private String author;

            @JsonProperty("name")
            private String name;

            @JsonProperty("type")
            private Type type;

            @JsonIgnoreProperties(ignoreUnknown = true)
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @Getter
            @Setter
            public static class Type {

                @JsonProperty("code")
                private String code;

                @JsonProperty("name")
                private String name;
            }
        }
    }
}