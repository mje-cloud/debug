package acc.hertz.model.hertz.shared;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class ClaimOfficeDetails {

    @JsonProperty("Id")
    private String id;

    @JsonProperty("HertzCDP")
    private String hertzCDP;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("Phone")
    private String phone;

    @JsonProperty("PhoneExt")
    private String phoneExt;

    @JsonProperty("Street1")
    private String street1;

    @JsonProperty("Street2")
    private String street2;

    @JsonProperty("City")
    private String city;

    @JsonProperty("State")
    private String state;

    @JsonProperty("DefaultContactName")
    private String defaultContactName;

    @JsonProperty("Zip")
    private String zip;

    @JsonProperty("Email")
    private String email;

}
