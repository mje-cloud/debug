package acc.hertz.security;

public interface IServerSelector {

    public String getServer();
}
