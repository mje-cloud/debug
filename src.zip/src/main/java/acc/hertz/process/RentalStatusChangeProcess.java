package acc.hertz.process;

import acc.hertz.client.composite.ICompositeClient;
import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestAccepted;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestList;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestPost;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestPostResponse;
import acc.hertz.model.enums.*;
import acc.hertz.model.hertz.outbound.BaseHertzRequest;
import acc.hertz.model.hertz.outbound.BaseHertzResponse;
import acc.hertz.model.hertz.shared.AdditionalCharges;
import acc.hertz.model.hertz.shared.ClaimInfoDetails;
import acc.hertz.model.hertz.shared.RentalInfoDetails;
import acc.hertz.processors.composite.CompositeResponseMapper;
import acc.hertz.processors.composite.helper.CompositeRentalStatusChangeHelper;
import acc.hertz.processors.composite.helper.payload.ServiceRequestPostComposite;
import acc.hertz.util.AppUtils;
import acc.hertz.util.Converter;
import gw.api.ig.GwUtilities;
import org.apache.camel.Exchange;
import java.util.ArrayList;
import java.util.UUID;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.Date;

@Named
public class RentalStatusChangeProcess {

    @Inject
    private CompositeRentalStatusChangeHelper compositeRentalStatusChangeHelper;
    @Inject
    private ICompositeClient compositeClient;
    @Inject
    private ReservationHelper reservationHelper;
    public BaseHertzResponse processRentalStatusChange(BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception {
        BaseHertzResponse response = null;
        ServiceRequestPostComposite serviceRequestPost = null;
        ClaimInfoDetails claimInfoDetails = baseHertzRequest.getClaimInfo();
        RentalInfoDetails rentalInfoDetails = baseHertzRequest.getRentalInfo();
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();

        try {
            /**
             * 1.2If Claim exist and is open state then continue with step 2
             *
             *     1.2.1 If claim condition are not match return a message error on log and trow an exception
             *               1.2.1.1 if claim do not exist  = Claim {id} not found
             *               if claim is not in open state =  Claim {id} is not in Open state
             */
            ClaimData claim = reservationHelper.findClaim(exchange,baseHertzRequest);
            /**
             *   1.2.2 Find on cloud api if service request exists using the cloud api filter object from the service request web service  from tsd payload
             * "HertzTransactionContractID_Ext" ==  TransactionContractId from tsd payload
             *
             * "HertzTransactionGUID_Ext"" ==  TransactionGUID from tsd payload
             *       if cloud api query return matching then throw an exception "
             * Assigment ID already exists and transaction type demands to create a new service"
             *      If not match continue next step
             */
            ServiceRequestList.ServiceRequest currentServiceRequest = reservationHelper.findServiceRequestWithReservation(claim,baseHertzRequest, HistoryType.HERTZ_RENTAL_OPEN_ACC);
            try{
                currentServiceRequest = reservationHelper.findServiceRequestWithReservation(claim,baseHertzRequest, HistoryType.HERTZ_RENTAL_OPEN_ACC);
            }catch(Exception e){
                log.info(e.getMessage(), new Object(){}.getClass().getEnclosingMethod().getName());
            }
            finally{
                if(currentServiceRequest==null){
                    response = new BaseHertzResponse();
                    response.setMessage(HistoryType.HERTZ_RENTAL_CHANGE_ACC.getName() + " processed but Contract ID " + baseHertzRequest.getTransactionContractId() + " not found");
                    response.setMsgType("success");
                    response.setTransactionGuid(baseHertzRequest.getTransactionGUID());
                    response.setTransactionContractId(baseHertzRequest.getTransactionContractId());
                    response.setTransactionType(baseHertzRequest.getTransactionType());
                    response.setMsgGuid(baseHertzRequest.getTransactionGUID());
                    response.setTransactionDate(baseHertzRequest.getTransactionDate());
                    response.setMsgDate(Converter.parseDateToJSON(new Date()));
                    return response;
                }
            }

            var hertzContractStatusCode = currentServiceRequest.getAttributes().getHertzContractStatus_Ext().getCode();
            if(hertzContractStatusCode.equalsIgnoreCase(ContractStatus.RENTAL_CLOSE.getCode()) || hertzContractStatusCode.equalsIgnoreCase(ContractStatus.RENTAL_CANCEL.getCode())){
                response = new BaseHertzResponse();
                response.setMessage(HistoryType.HERTZ_RENTAL_CHANGE_ACC.getName() + " processed but Contract ID " + baseHertzRequest.getTransactionContractId() + " is already closed");
                response.setMsgType("success");
                response.setTransactionGuid(baseHertzRequest.getTransactionGUID());
                response.setTransactionContractId(baseHertzRequest.getTransactionContractId());
                response.setTransactionType(baseHertzRequest.getTransactionType());
                response.setMsgGuid(baseHertzRequest.getTransactionGUID());
                response.setTransactionDate(baseHertzRequest.getTransactionDate());
                response.setMsgDate(Converter.parseDateToJSON(new Date()));
                return response;
            }

            var currentServiceRequestAttributes = currentServiceRequest.getAttributes();
            var hertzContactStatus = currentServiceRequestAttributes.getHertzContractStatus_Ext();
            if(!hertzContactStatus.getCode().equalsIgnoreCase(ContractStatus.RESERVATION_CONFIRMED.getCode())  &&
                    !hertzContactStatus.getCode().equalsIgnoreCase(ContractStatus.RESERVATION_OPEN_WALKUP.getCode()) &&
                    !hertzContactStatus.getCode().equalsIgnoreCase(ContractStatus.RENTAL_OPEN.getCode())){
                log.info("Reservation can not be opened using the current Contract Status",  new Object(){}.getClass().getEnclosingMethod().getName());
                throw new Exception("Reservation can not be opened using the current Contract Status");
            }
            var progress= currentServiceRequestAttributes.getProgress();
            if(!progress.getCode().equalsIgnoreCase(ServiceRequestProgress.DRAFT.getCode())
                    && !progress.getCode().equalsIgnoreCase(ServiceRequestProgress.REQUESTED.getCode())
                    && !progress.getCode().equalsIgnoreCase(ServiceRequestProgress.IN_PROGRESS.getCode())
            ){
                log.info("Reservation can not be open if service request is not in " + ServiceRequestProgress.DRAFT.getCode() + " or " + ServiceRequestProgress.REQUESTED.getCode()+ " or " + ServiceRequestProgress.IN_PROGRESS.getCode(),  new Object(){}.getClass().getEnclosingMethod().getName());
                throw new Exception("Reservation can not be open if service request is not in " + ServiceRequestProgress.DRAFT.getCode() + " or " + ServiceRequestProgress.REQUESTED.getCode()+ " or " + ServiceRequestProgress.IN_PROGRESS.getCode());
            }

            serviceRequestPost = new ServiceRequestPostComposite();
            serviceRequestPost.setData(new ServiceRequestPostComposite.Data());
            serviceRequestPost.getData().setAttributes(new ServiceRequestPostComposite.Attributes());

            ServiceRequestPost.Service rentalService = new ServiceRequestPost.Service();
            rentalService.setCode(ServiceSubTypes.AUTO_RENTAL.getType());
            ContractStatus contractStatus = ContractStatus.fromCode(baseHertzRequest.getRentalInfo().getContractStatus().toLowerCase());
            serviceRequestPost.getData().getAttributes().setHertzContractStatus_Ext(new ServiceRequestPostComposite.CodeName());
            serviceRequestPost.getData().getAttributes().getHertzContractStatus_Ext().setCode(contractStatus.getCode());
            serviceRequestPost.getData().getAttributes().getHertzContractStatus_Ext().setName(contractStatus.getName());
            serviceRequestPost.getData().getAttributes().setHertzClassCode_Ext(rentalInfoDetails.getRateClass());
            serviceRequestPost.getData().getAttributes().setHertzClassName_Ext(rentalInfoDetails.getRateClass());
            serviceRequestPost.getData().getAttributes().setHertzCustomerSelfPay_Ext(currentServiceRequestAttributes.isHertzCustomerSelfPay_Ext());
            serviceRequestPost.getData().getAttributes().setHertzDateType_Ext(new ServiceRequestPostComposite.CodeName());
            serviceRequestPost.getData().getAttributes().getHertzDateType_Ext().setCode(DateType.CALENDAR_DAY.getCode());
            serviceRequestPost.getData().getAttributes().getHertzDateType_Ext().setName(DateType.CALENDAR_DAY.getName());
            serviceRequestPost.getData().getAttributes().setHertzDayCount_Ext(claimInfoDetails.getTotalDays());
            serviceRequestPost.getData().getAttributes().setHertzIncrementalDays_Ext(claimInfoDetails.getIncrementalDays());
            serviceRequestPost.getData().getAttributes().setHertzMaxAuthAmount_Ext(new ServiceRequestPostComposite.Amount());
            var maxCoverageAmount = !Double.isNaN(baseHertzRequest.getPolicy().getMaxCoverage()) ? baseHertzRequest.getPolicy().getMaxCoverage() : currentServiceRequestAttributes.getHertzMaxAuthAmount_Ext();
            serviceRequestPost.getData().getAttributes().getHertzMaxAuthAmount_Ext().setAmount(String.valueOf(maxCoverageAmount));
            serviceRequestPost.getData().getAttributes().getHertzMaxAuthAmount_Ext().setCurrency(reservationHelper.getDefaultCurrency());
            serviceRequestPost.getData().getAttributes().setHertzRateInclusivePrice_Ext(new ServiceRequestPostComposite.Amount());
            var rateInclusivePrice = !Double.isNaN(claimInfoDetails.getRentalDailyAmount()) ? claimInfoDetails.getRentalDailyAmount() : currentServiceRequestAttributes.getHertzRateInclusivePrice_Ext();
            serviceRequestPost.getData().getAttributes().getHertzRateInclusivePrice_Ext().setAmount(AppUtils.getValidCurrencyAmount(String.valueOf(rateInclusivePrice)));
            serviceRequestPost.getData().getAttributes().getHertzRateInclusivePrice_Ext().setCurrency(reservationHelper.getDefaultCurrency());

            var rentalDailyAmount = (baseHertzRequest.getPolicy().getDailyMaxCoverage() > 0) ? String.valueOf(baseHertzRequest.getPolicy().getDailyMaxCoverage()) : AppUtils.getValidCurrencyAmount(String.valueOf(claimInfoDetails.getRentalDailyAmount()));
            serviceRequestPost.getData().getAttributes().setHertzRentalDailyAmount_Ext(new ServiceRequestPostComposite.Amount());
            serviceRequestPost.getData().getAttributes().getHertzRentalDailyAmount_Ext().setAmount(rentalDailyAmount);
            serviceRequestPost.getData().getAttributes().getHertzRentalDailyAmount_Ext().setCurrency(reservationHelper.getDefaultCurrency());

           /* var payAllTaxes = claimInfoDetails.getPayTaxes() != "" ? AppUtils.getValidStringValue(claimInfoDetails.getPayTaxes()) : AppUtils.getValidStringValue(String.valueOf(currentServiceRequestAttributes.isHertzPayAllTaxes_Ext()));
            serviceRequestPost.getData().getAttributes().setHertzPayAllTaxes_Ext(payAllTaxes.equalsIgnoreCase("Y")); */

            var percentagePay = !Double.isNaN(baseHertzRequest.getPolicy().getPercentPay()) ? String.valueOf(baseHertzRequest.getPolicy().getPercentPay()) : currentServiceRequestAttributes.getHertzPercentagePay_Ext();
            serviceRequestPost.getData().getAttributes().setHertzPercentagePay_Ext(percentagePay);

            var pickupDate = rentalInfoDetails.getPickupDate() != "" ? rentalInfoDetails.getPickupDate() : currentServiceRequestAttributes.getHertzPickupDate_Ext();
            serviceRequestPost.getData().getAttributes().setHertzPickupDate_Ext(pickupDate);

            serviceRequestPost.getData().getAttributes().setHertzRentalBeginDate_Ext(AppUtils.getDateISO8601(baseHertzRequest.getRentalInfo().getStartDate()));
            var endDate = rentalInfoDetails.getEndDate() != null ? AppUtils.getDateISO8601(rentalInfoDetails.getEndDate()) : null;
            if (endDate == null) {
                if (baseHertzRequest.getClaimInfo().getTotalDays() > 0) {
                    endDate = Converter.parseDateToStringUSFormat(Converter.addDays(Converter.parseStringToDateUSFormat(baseHertzRequest.getRentalInfo().getStartDate()), baseHertzRequest.getClaimInfo().getTotalDays() - 1));
                    serviceRequestPost.getData().getAttributes().setHertzRentalEndDate_Ext(endDate);
                }
            }

            if (currentServiceRequestAttributes.isHertzCustomerSelfPay_Ext()) {
                serviceRequestPost.getData().getAttributes().setHertzRentalEndDate_Ext(rentalInfoDetails.getStartDate());
            }

            serviceRequestPost.getData().getAttributes().setHertzRentalEndDate_Ext(endDate);
            serviceRequestPost.getData().getAttributes().setHertzRateType_Ext(new ServiceRequestPostComposite.CodeName());
            if (rentalInfoDetails.getRateClass() != "") {
                RateType rate = RateType.fromType(rentalInfoDetails.getRateClass());
                serviceRequestPost.getData().getAttributes().getHertzRateType_Ext().setCode(rate.getCode());
                serviceRequestPost.getData().getAttributes().getHertzRateType_Ext().setName(rate.getDescription());
            }

            serviceRequestPost.getData().getAttributes().setHertzRentalCompany_Ext(new ServiceRequestPostComposite.CodeName());
            serviceRequestPost.getData().getAttributes().getHertzRentalCompany_Ext().setCode(RentalCompany.HERTZ.getCode());
            serviceRequestPost.getData().getAttributes().getHertzRentalCompany_Ext().setName(RentalCompany.HERTZ.getDescription());
            serviceRequestPost.getData().getAttributes().setHertzTransactionDate_Ext(AppUtils.getDateISO8601(baseHertzRequest.getTransactionDate()));

            if (claimInfoDetails.getType() != "") {
                RentalRole rentalRole = RentalRole.fromType(claimInfoDetails.getType());
                serviceRequestPost.getData().getAttributes().setHertzRentalRole_Ext(new ServiceRequestPostComposite.CodeName());
                serviceRequestPost.getData().getAttributes().getHertzRentalRole_Ext().setCode(rentalRole.getCode());
                serviceRequestPost.getData().getAttributes().getHertzRentalRole_Ext().setName(rentalRole.getName());
            }

            serviceRequestPost.getData().getAttributes().setHertzTotalDaysApproved_Ext(claimInfoDetails.getTotalDays());

            serviceRequestPost.getData().getAttributes().setHertzRequestType_Ext(false);
            serviceRequestPost.getData().getAttributes().setHertzTransactionContractID_Ext(baseHertzRequest.getRentalInfo().getContractId());
            serviceRequestPost.getData().getAttributes().setHertzTransactionTSDID_Ext(baseHertzRequest.getRentalInfo().getContractId());
            serviceRequestPost.getData().getAttributes().setHertzTransactionGUID_Ext(baseHertzRequest.getTransactionGUID());

            /*Additional Charges*/
            var additionalCharges = baseHertzRequest.getClaimInfo().getAdditionalCharges();
            if( additionalCharges != null && additionalCharges.size() > 0){
                for (AdditionalCharges charge : additionalCharges) {
                    if (AdditionalChargeType.LOST_DAMAGE_WAIVER.getCode().equalsIgnoreCase(charge.getCode())) {
                        serviceRequestPost.getData().getAttributes().setHertzLossDamageWaiver_Ext(true);
                    }
                    else if (AdditionalChargeType.WINTER_TIRES.getCode().equalsIgnoreCase(charge.getCode())) {
                        serviceRequestPost.getData().getAttributes().setHertzWinterTires_Ext(true);
                    }
                }
            }
            else {
                serviceRequestPost.getData().getAttributes().setHertzLossDamageWaiver_Ext(currentServiceRequestAttributes.isHertzLossDamageWaiver_Ext());
                serviceRequestPost.getData().getAttributes().setHertzWinterTires_Ext(currentServiceRequestAttributes.isHertzWinterTires_Ext());
            }

            String stickySessionToken = UUID.randomUUID().toString();
            var abstractRequest = compositeRentalStatusChangeHelper.buildCompositeRequest(claim, baseHertzRequest,
                    currentServiceRequest,
                    serviceRequestPost);
            String result = compositeClient.executeCompositeRequest(exchange, stickySessionToken, abstractRequest);
            ServiceRequestPostResponse compositeBodyResponse = CompositeResponseMapper.mapFirstResponse(result, ServiceRequestPostResponse.class);

            Thread.sleep(10000);
            if(compositeBodyResponse!=null){
                if (compositeBodyResponse.getData().getAttributes().getProgress().getCode().equalsIgnoreCase(ServiceRequestProgress.DRAFT.getCode())) {
                    ////Move to requested state using normal Rest Call since Composite DO NOT SUPPORT  requested state using
                    reservationHelper.markAsSubmitted(stickySessionToken, claim, currentServiceRequest.getAttributes().getId());
                    ////Move to requested state using normal Rest Call since Composite DO NOT SUPPORT in-progress state
                    ServiceRequestAccepted accepted = new ServiceRequestAccepted();
                    accepted.setData(new ServiceRequestAccepted.Data());
                    accepted.getData().setAttributes(new ServiceRequestAccepted.Attributes());
                    accepted.getData().getAttributes().setExpectedCompletionDate(Converter.parseDateToStringUSFormat(Converter.addDays(Converter.parseStringToDateUSFormat(baseHertzRequest.getRentalInfo().getStartDate()), 30)));
                    reservationHelper.markAsInProgress(stickySessionToken, claim, currentServiceRequest.getAttributes().getId(), accepted);
                } else {
                    if (compositeBodyResponse.getData().getAttributes().getProgress().getCode().equalsIgnoreCase(ServiceRequestProgress.REQUESTED.getCode())) {
                        ////Move to requested state using normal Rest Call since Composite DO NOT SUPPORT in-progress state
                        ServiceRequestAccepted accepted = new ServiceRequestAccepted();
                        accepted.setData(new ServiceRequestAccepted.Data());
                        accepted.getData().setAttributes(new ServiceRequestAccepted.Attributes());
                        accepted.getData().getAttributes().setExpectedCompletionDate(Converter.parseDateToStringUSFormat(Converter.addDays(Converter.parseStringToDateUSFormat(baseHertzRequest.getRentalInfo().getStartDate()), 30)));
                        reservationHelper.markAsInProgress(stickySessionToken, claim, currentServiceRequest.getAttributes().getId(), accepted);
                    }
                }
                response = new BaseHertzResponse();
                response.setMessage("Service request changed");
                response.setMsgType("success");
                response.setTransactionGuid(baseHertzRequest.getTransactionGUID());
                response.setTransactionContractId(baseHertzRequest.getTransactionContractId());
                response.setTransactionType(baseHertzRequest.getTransactionType());
                response.setMsgGuid(baseHertzRequest.getTransactionGUID());
                response.setTransactionDate(baseHertzRequest.getTransactionDate());
                response.setMsgDate(Converter.parseDateToJSON(new Date()));
            }
            else{
                log.info("Unable to parse Composite Response to ServiceRequestPostResponse", new Object() {
                }.getClass().getEnclosingMethod().getName());
            }

        } catch (Exception e) {
            log.error("Error", new Object() {
            }.getClass().getEnclosingMethod().getName(), e);
            throw e;
        }
        return response;

    }

}