package acc.hertz.util.log;

import gw.api.ig.GwUtilities;
import gw.api.ig.logging.GwLogger;
import org.apache.camel.Exchange;

import jakarta.inject.Named;

/**
 * Bean to manage Log methods
 * Used on routes as
 *      .bean(new LoggerBean(), "methodName")  -- Instantiate a new class
 *      .bean(LoggerBean.class, "methodName")  -- Use same class
 **/
@Named
public class LoggerBean {

    private static final String LOG_STARTED  = " ROUTE_STARTED";
    private static final String LOG_FINISHED = " ROUTE_FINISHED";
    private static final String LOG_INFO     = " ROUTE_INFO: ";

    /**
     * Method used to log error messages
     * Used on routes as ".bean(LoggerBean.class, "exceptionLogging");"
     * @param  exchange: Message exchange, is not required to specified the parameter, camel get it by default
     *
     * In case of exceptions, camel set the property "Exchange.EXCEPTION_CAUGHT" with the exception related info
     */
    public void exceptionLogging(Exchange exchange) {
        GwLogger gwLogger = GwUtilities.get(exchange.getContext()).getLogUtils();

        StringBuilder errorMessage = new StringBuilder("IG_HERTZ");
        errorMessage.append(" RouteId: ");
        errorMessage.append(exchange.getFromRouteId());
        Exception cause = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
        if(cause != null) {
            errorMessage.append(" -- Error: ");
            errorMessage.append(cause.getMessage());
        }
        gwLogger.error(" -- Error : " + errorMessage.toString(), LogEventType.ERROR_EVENT, cause);
    }

    /**
     * Method used to log info messages
     * Used on routes as ".bean(LoggerBean.class, "operationalLogging(*, 3, ${routeId}, ${body})"
     * @param  exchange: Message exchange, could be specified using a "*"
     * @param  mode:    1 -- Route started
     *                  2 -- Route finished
     *                  3 -- Informational message
     * @param  route: Route id
     */
    public void operationalLogging(Exchange exchange, Integer mode, String route) {
        operationalLogging(exchange, mode, route, "");
    }

    /**
     * Method used to log info messages
     * Used on routes as ".bean(LoggerBean.class, "operationalLogging(*, 3, ${routeId}, ${body})"
     * @param  exchange: Message exchange, could be specified using a "*"
     * @param  mode:    1 -- Route started
     *                  2 -- Route finished
     *                  3 -- Informational message
     * @param  route: Route id
     * @param  message: Additional info for mode = 3 cases
     */
    public void operationalLogging(Exchange exchange, Integer mode, String route, String message) {
        GwLogger gwLogger = GwUtilities.get(exchange.getContext()).getLogUtils();
        StringBuilder logMessage = new StringBuilder("IG_HERTZ");
        logMessage.append(" -- ");
        logMessage.append(route);
        logMessage.append(" -- ");
        switch (mode) {
            case 1:
                logMessage.append(LOG_STARTED);
                break;
            case 2:
                logMessage.append(LOG_FINISHED);
                break;
            default:
                logMessage.append(LOG_INFO);
                logMessage.append(message);
                break;
        }
        gwLogger.info(logMessage.toString(), LogEventType.INFO_EVENT);
    }
}