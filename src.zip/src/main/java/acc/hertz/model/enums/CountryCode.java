package acc.hertz.model.enums;

public enum CountryCode {
    US("US","United States (1)"),
    CA("CA","Canada (1)");
    private final String code;

    public String getName() {
        return name;
    }

    private final String name;

    CountryCode(String code, String name) {
        this.code = code;
        this.name=name;
    }

    public String getCode() {
        return code;
    }

    public static CountryCode fromType(String type) {
        for (CountryCode charge : values()) {
            if (charge.getCode().equals(type)) {
                return charge;
            }
        }
        throw new IllegalArgumentException("Unknown : " + type);
    }
}
