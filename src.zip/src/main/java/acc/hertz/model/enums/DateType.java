package acc.hertz.model.enums;

public enum DateType {
    CALENDAR_DAY("c","calendar day");

    private final String code;

    public String getName() {
        return name;
    }

    private final String name;

    DateType(String code, String name) {
        this.code = code;
        this.name=name;
    }

    public String getCode() {
        return code;
    }

    public static DateType fromType(String type) {
        for (DateType kind : values()) {
            if (kind.getCode().equals(type)) {
                return kind;
            }
        }
        throw new IllegalArgumentException("Unknown Type: " + type);
    }
}
