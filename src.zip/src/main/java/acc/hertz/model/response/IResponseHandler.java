package acc.hertz.model.response;


import acc.hertz.model.error.ErrorResponse;
import org.apache.camel.Exchange;

public interface IResponseHandler {
    ErrorResponse handleResponse(Exchange exchange, String displayKey, int httpCode) throws Exception;

    ErrorResponse handleResponse(Exchange exchange, String displayKey, String[] values, int httpCode) throws Exception;


}
