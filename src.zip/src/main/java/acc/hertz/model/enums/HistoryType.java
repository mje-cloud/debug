package acc.hertz.model.enums;

public enum HistoryType {
    HERTZ_WALK_UP_AUTHORIZATION_ACC("hertz_walk_up_authorization_acc", "Walk-Up Authorization Reservation Request","$1 Request Days"),
    HERTZ_REACTIVE_EXTENSION_ACC("hertz_reactive_extension_acc", "Open – Reactive Extension Request","$1 $2 $3 Request Days"),
    HERTZ_RENTAL_OPEN_ACC("hertz_rental_open_acc", "Rental Opened","$1 $2"),
    HERTZ_CANCEL_RESERVATION_ACC("hertz_cancel_reservation_acc", "Rental Cancelled","$1 $2"),
    HERTZ_PROACTIVE_EXTENSION_ACC("hertz_proactive_extension_acc", "Proactive Extension",""),
    HERTZ_FINAL_DAY_ACC("hertz_final_day_acc", "Edit Rental - Final Day",""),
    HERTZ_RENTAL_CLOSE_ACC("hertz_rental_close_acc", "Rental Close","$1 $2"),
    HERTZ_RENTAL_INVOICE_ACC("hertz_rental_invoice_acc", "Rental Invoice","New Rental Invoice Received with Invoice No. $1"),
    HERTZ_RENTAL_ERROR_ACC("hertz_rental_error_acc", "Error IG","Error from IG reported $1"),
    HERTZ_RENTAL_CHANGE_ACC("hertz_rental_change_acc", "Rental Change","Rental Change"),
	HERTZ_RENTAL_SUCCESS_EXT("hertz_rental_success_ext", "Success IG","Success from IG reported $1");
    private String code;
    private String name;

    public String getDescription() {
        return description;
    }

    private String description;

    HistoryType(String code,String name,String description) {
        this.code = code;
        this.name =name;
        this.description=description;
    }

    public String getCode() {
        return code;
    }
    @Override
    public String toString() {
        return String.valueOf(code);
    }
    public String getName() {
        return name;
    }
    public static HistoryType fromCode(String code) {
        for (HistoryType b : HistoryType.values()) {
            if (b.code.equals(code)) {
                return b;
            }
        }
        throw new IllegalArgumentException("Unexpected Code" + code );
    }
}
