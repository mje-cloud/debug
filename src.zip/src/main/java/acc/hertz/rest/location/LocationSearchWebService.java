package acc.hertz.rest.location;

import acc.hertz.client.core.WebMethodType;
import acc.hertz.model.enums.MimeType;
import acc.hertz.model.hertz.inbound.LocationSearchRequest;
import acc.hertz.model.hertz.inbound.LocationSearchResponse;
import acc.hertz.processors.LocationSearchRequestProcessor;
import acc.hertz.route.base.types.rest.AbstractRestRouteBuilder;
import acc.hertz.util.AppProperty;
import acc.hertz.util.AppUtils;
import acc.hertz.util.log.LoggerBean;
import gw.api.ig.failure.FailureConfiguration;
import gw.impl.ig.failure.DefaultFailureConfiguration;
import org.apache.camel.Exchange;
import org.apache.camel.model.rest.RestBindingMode;

import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named
public class LocationSearchWebService extends AbstractRestRouteBuilder {
   @Inject
   private AppProperty properties;
   @Inject
   private LocationSearchRequestProcessor locationSearchRequestProcessor;
    @Override
    public void setupEndpoints()  {
        var restService = super.generateRestEndpoint(AppUtils.SEARCH_LOCATION_SERVICE, WebMethodType.GET, AppUtils.SEARCH_LOCATION_SERVICE_TITLE, MimeType.JSON.getCode(), MimeType.JSON.getCode(), AppUtils.ROUTE_ID_LOCATION_SEARCH_WEB_SERVICE,RestBindingMode.json);
        restService.type(LocationSearchRequest.class);
        restService.id(AppUtils.SEARCH_LOCATION_SERVICE_TITLE);
        restService.outType(LocationSearchResponse.class);

        from(AppUtils.ROUTE_ID_LOCATION_SEARCH_WEB_SERVICE)
                .routeId(this.getClass().getSimpleName())
                .doTry()
                  .process(locationSearchRequestProcessor)
                .endDoTry()
                .doCatch(Exception.class)
                   .process(exchange -> {
                      Throwable caughtException = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);
                      log.error(getClass().getSimpleName() + " Failed to process search location. Reason: " + AppUtils.sanitize(caughtException.getMessage()));
                   })
                .marshal().json()
                .bean(LoggerBean.class, "operationalLogging(*, 2, ${routeId})")
                .end();
    }

    @Override
    public FailureConfiguration<?> createFailureConfiguration() {
        return new DefaultFailureConfiguration();
    }
}