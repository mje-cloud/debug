package acc.hertz.security;

import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class SecureKeyStore {

    private SecretKey privateKey;
    private SealedObject sealedObject;

    public SecureKeyStore(String key) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, IOException, InvalidAlgorithmParameterException {
        String obj = new String(key);
        //Step 1. Generate an AES key using KeyGenerator
        KeyGenerator kgen = KeyGenerator.getInstance("AES");
        kgen.init(256);
        privateKey = kgen.generateKey();
        //Step 2. Generate an Initialization Vector (IV)
        byte[] iv = new byte[16];
        SecureRandom prng = new SecureRandom();
        prng.nextBytes(iv);
        //Step 3. Create a Cipher
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        GCMParameterSpec gcmSpec = new GCMParameterSpec(128, iv);
        cipher.init(Cipher.ENCRYPT_MODE, privateKey, gcmSpec);
        //Step 5. We save it in a Sealed Object where it is encrypted with the config provided
        sealedObject = new SealedObject(obj, cipher);

    }
    public String getObject() throws IOException, NoSuchAlgorithmException, InvalidKeyException, ClassNotFoundException {
        Object value =  sealedObject.getObject(privateKey);
        return ((String)value);
    }
}

