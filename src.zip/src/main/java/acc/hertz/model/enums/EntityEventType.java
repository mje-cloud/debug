package acc.hertz.model.enums;

public enum EntityEventType {
    SERVICE_REQUEST("ServiceRequest"),
    CLAIM("Claim"),

    USER("User");

    private final String type;

    EntityEventType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public static EntityEventType fromType(String type) {
        for (EntityEventType requestType : values()) {
            if (requestType.getType().equals(type)) {
                return requestType;
            }
        }
        throw new IllegalArgumentException("Unknown ServiceRequestType: " + type);
    }
}
