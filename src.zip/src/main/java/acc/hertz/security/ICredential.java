package acc.hertz.security;

import acc.hertz.security.authorization.AuthorizationType;
import org.apache.camel.Exchange;

public interface ICredential {
      public String getCredential(Exchange exchange, AuthorizationType authorizationType) throws Exception;

}
