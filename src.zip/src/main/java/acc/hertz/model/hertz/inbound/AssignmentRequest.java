package acc.hertz.model.hertz.inbound;

import acc.hertz.model.hertz.shared.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class AssignmentRequest {

    @JsonProperty("MSGGuid")
    private String msgGuid;

    @JsonProperty("MSGDate")
    private String msgDate;

    @JsonProperty("TransactionDate")
    private String transactionDate;

    @JsonProperty("TransactionGUID")
    private String transactionGuid;

    @JsonProperty("TransactionType")
    private String transactionType;

    @JsonProperty("TransactionPassThroughId")
    private String transactionPassThoughId;

    @JsonProperty("TransactionContractId")
    private String transactionContractId;

    @JsonProperty("TransactionUserId")
    private String transactionUserId;
    @JsonProperty("TransactionTsdId")
    private String transactionTsdId;
    @JsonProperty("Policy")
    private PolicyDetails policy;

    @JsonProperty("ClaimInfo")
    private ClaimInfoDetails claimInfo;

    @JsonProperty("ClaimOffice")
    private ClaimOfficeDetails claimOffice;

    @JsonProperty("ClaimAdjuster")
    private ClaimAdjusterDetails claimAdjuster;

    @JsonProperty("RentalInfo")
    private RentalInfoDetails rentalInfo;

    @JsonProperty("RepairFacility")
    private RepairFacility repairFacility;

  }
