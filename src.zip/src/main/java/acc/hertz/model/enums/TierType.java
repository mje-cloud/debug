package acc.hertz.model.enums;

public enum TierType {
    LOW("low","Low");

    private final String code;

    public String getName() {
        return name;
    }

    private final String name;

    TierType(String code,String name) {
        this.code = code;
        this.name=name;
    }

    public String getCode() {
        return code;
    }

    public static TierType fromType(String type) {
        for (TierType requestType : values()) {
            if (requestType.getCode().equals(type)) {
                return requestType;
            }
        }
        throw new IllegalArgumentException("Unknown Type: " + type);
    }
}
