package acc.hertz.processors;

import acc.hertz.api.IAssignment;
import acc.hertz.model.enums.MessageType;
import acc.hertz.model.enums.TransactionType;
import acc.hertz.model.hertz.outbound.BaseHertzRequest;
import acc.hertz.model.hertz.outbound.BaseHertzResponse;
import acc.hertz.util.Converter;
import acc.hertz.util.GenericJSONTransformer;
import gw.api.ig.GwUtilities;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.hc.core5.http.HttpStatus;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.Date;

@Named
public class RentalRequestProcessor implements Processor {
    @Inject
    private IAssignment tsdAssignmentConsumer;
    private final GenericJSONTransformer<BaseHertzRequest> transformer = new GenericJSONTransformer<>(BaseHertzRequest.class);

    @Override
    public void process(Exchange exchange) throws Exception {
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
        BaseHertzResponse response = null;
        BaseHertzRequest baseHertzRequest=null;
        boolean success=true;
        try {
             GenericJSONTransformer<BaseHertzRequest> assignmentRequestTransformer = new GenericJSONTransformer<>(BaseHertzRequest.class);


            if(exchange.getIn().getBody(String.class)!=null && exchange.getIn().getBody(String.class).length()>0){
                baseHertzRequest = exchange.getIn().getBody(BaseHertzRequest.class);



                var transactionType = baseHertzRequest.getTransactionType() != null ? baseHertzRequest.getTransactionType().toLowerCase()
                        : baseHertzRequest.getTransactionHeaderDetails().getTransactionType() != null
                        ? baseHertzRequest.getTransactionHeaderDetails().getTransactionType().toLowerCase() : "";
                String jsonRequest=  assignmentRequestTransformer.toJson(baseHertzRequest);

                log.info("RentalRequestProcessor : Inbound Hertz request (raw): {} "+jsonRequest,transactionType);
                switch (TransactionType.fromCode(transactionType)) {
                    case NEW_ASSIGNMENT:
                        response = tsdAssignmentConsumer.createWalkUpOpenProcess(baseHertzRequest,exchange);
                        break;
                    case REQUEST_AUTH:
                        response = tsdAssignmentConsumer.reactiveExtension(baseHertzRequest,exchange);
                        break;
                    case RENTAL_OPEN:
                        response = tsdAssignmentConsumer.rentalOpenStatusChange(baseHertzRequest,exchange);
                        break;
                    case STATUS_CANCEL:
                        response = tsdAssignmentConsumer.rentalCancellationStatusChange(baseHertzRequest,exchange);
                        break;
                    case RENTAL_CLOSE:
                        response = tsdAssignmentConsumer.rentalCloseStatusChange(baseHertzRequest,exchange);
                        break;
                    case SUBMIT_INVOICE:
                        response = tsdAssignmentConsumer.createInvoice(baseHertzRequest,exchange);
                        break;
                    case STATUS_CHANGE:
                        response = tsdAssignmentConsumer.rentalStatusChange(baseHertzRequest,exchange);
                        break;
                    default:
                        success = false;
                        response = new BaseHertzResponse();
                        response.setMsgType(MessageType.REJECTED.getCode());
                        response.setMessage("Error: Invalid transaction type " +  MessageType.REJECTED.getDescription());
                        response.setTransactionGuid(baseHertzRequest.getTransactionGUID());
                        response.setTransactionContractId(baseHertzRequest.getTransactionContractId());
                        response.setTransactionType(baseHertzRequest.getTransactionType());
                        response.setMsgGuid(baseHertzRequest.getTransactionGUID());
                        exchange.getMessage().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.SC_BAD_REQUEST);
                        exchange.getMessage().setBody(response);
                        break;
                }
            }
        } catch (Exception e) {
            success=false;
            response = new BaseHertzResponse();
            response.setMsgType(MessageType.REJECTED.getCode());
            response.setMessage("Request failed. Contact support with transaction ID.");
            if(baseHertzRequest!=null){
                var transactionGUID = baseHertzRequest.getTransactionGUID() != null ? baseHertzRequest.getTransactionGUID() : baseHertzRequest.getTransactionHeaderDetails().getTransactionGuid();
                var transactionType = baseHertzRequest.getTransactionType() != null ? baseHertzRequest.getTransactionType() : baseHertzRequest.getTransactionHeaderDetails().getTransactionType();
                var msgGUID = baseHertzRequest.getTransactionGUID() != null ? baseHertzRequest.getTransactionGUID() : baseHertzRequest.getTransactionHeaderDetails().getMsgGuid();
                var transactionDate = baseHertzRequest.getTransactionDate() != null ? baseHertzRequest.getTransactionDate() : baseHertzRequest.getTransactionHeaderDetails().getTransactionDate();

                response.setTransactionGuid(transactionGUID);
                response.setTransactionContractId(baseHertzRequest.getTransactionContractId());
                response.setTransactionType(transactionType);
                response.setMsgGuid(msgGUID);
                response.setTransactionDate(transactionDate);
                response.setMsgDate(Converter.parseDateToJSON(new Date()));
            }
        }finally{
            exchange.getMessage().setHeader(Exchange.HTTP_RESPONSE_CODE, success ? HttpStatus.SC_CREATED : HttpStatus.SC_NOT_FOUND);
            exchange.getMessage().setBody(response);
        }
    }
}
