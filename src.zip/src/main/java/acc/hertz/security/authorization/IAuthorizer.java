package acc.hertz.security.authorization;

import org.apache.camel.Exchange;

public interface IAuthorizer {
  public String getCCDetailedAuthToken(Exchange exchange);
  public String getTSDAuthToken();
}
