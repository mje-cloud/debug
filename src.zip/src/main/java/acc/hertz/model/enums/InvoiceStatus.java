package acc.hertz.model.enums;

public enum InvoiceStatus {
    APPROVED("approved","Approved");
    private final String code;

    public String getName() {
        return name;
    }

    private final String name;

    InvoiceStatus(String code, String name) {
        this.code = code;
        this.name=name;
    }

    public String getCode() {
        return code;
    }

    public static InvoiceStatus fromType(String type) {
        for (InvoiceStatus charge : values()) {
            if (charge.getCode().equals(type)) {
                return charge;
            }
        }
        throw new IllegalArgumentException("Unknown : " + type);
    }
}
