package acc.hertz.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;


public class Converter {
    public static final String TIME_FORMAT ="HH:mm:ss";
    public static final String DATE_FORMAT ="MM-dd-yyyy";
    public static final String US_DATE_FORMAT ="yyyy-MM-dd";

    private static final String JAVA_FORMAT = "yyyy-MM-dd HH:mm:ssZ";
    private static final String JSON_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
    private static final String JSON_FORMAT_WITHOUT_T = "yyyy-MM-dd HH:mm:ss";
    private static final String ISO_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    public static Date parseJSONToDate(String dateJSON) {
        Date dateJson = null;
        boolean parsed = false;

        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat(ISO_FORMAT);
            inputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
            dateJson = inputFormat.parse(dateJSON);
            parsed = true;
        } catch (ParseException e) {
            System.out.println("Date format failed, trying next one");
        }

        if (!parsed) {
            try {
                SimpleDateFormat inputFormat = new SimpleDateFormat(JSON_FORMAT);
                dateJson = inputFormat.parse(dateJSON);
                parsed = true;
            } catch (ParseException e) {
                System.out.println("Date format failed, trying next one");
            }
        }

        if (!parsed) {
            try {
                SimpleDateFormat inputFormat = new SimpleDateFormat(JSON_FORMAT_WITHOUT_T);
                dateJson = inputFormat.parse(dateJSON);
                parsed = true;
            } catch (ParseException e) {
                System.out.println("Date format failed, trying next one");
            }
        }

        if (parsed) {
            try {
                SimpleDateFormat outputFormat = new SimpleDateFormat(JAVA_FORMAT);
                String formattedDate = outputFormat.format(dateJson);
                return outputFormat.parse(formattedDate);
            } catch (ParseException e) {
                System.out.println("Error formatting date");
            }
        }

        System.out.println("Date format failed, no valid format provided");
        return null;
    }

    public static Date addDays(Date date,int iDays) throws ParseException {
        Calendar dateTime = Calendar.getInstance(TimeZone.getDefault());
        dateTime.setTime(date);
        dateTime.add(Calendar.DAY_OF_MONTH, iDays);
        return dateTime.getTime();
    }

    public static Date addMonths(Date date, int iMonths) {
        Calendar dateTime = Calendar.getInstance(TimeZone.getDefault());
        dateTime.setTime(date);
        dateTime.add(Calendar.MONTH, iMonths);
        return dateTime.getTime();
    }

    public static String replaceValues(String key, String[] myValues) {
        return String.format(key, (Object[]) myValues);
    }

    public static Date parseJsonDateToUtilDate(String jsonDate) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC")); // Handle the 'Z' for UTC
        return sdf.parse(jsonDate);
    }

    public static String parseDateToJSONTimeZone(Date date )  {
        var dateFormat = new SimpleDateFormat(US_DATE_FORMAT);
        var strDate = dateFormat.format(date);
        var hourFormat = new SimpleDateFormat(TIME_FORMAT);
        var strHour = hourFormat.format(date);
        return strDate + "T" + strHour + ".000Z";
    }

    public static String parseDateToJSON(Date date )  {
        var dateFormat = new SimpleDateFormat(DATE_FORMAT);
        var strDate = dateFormat.format(date);
        var hourFormat = new SimpleDateFormat(TIME_FORMAT);
        var strHour = hourFormat.format(date);
        return strDate + "T" + strHour;
    }

    public static String parseDateToString(Date date)  {
       var dateFormat = new SimpleDateFormat(DATE_FORMAT);
       return dateFormat.format(date);
    }

    public static Date parseStringToDate(String value) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
        return dateFormat.parse(value);
    }

    public static Date parseStringToDateUSFormat(String value) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat(JSON_FORMAT);
        return dateFormat.parse(value);
    }

    public static String parseDateToStringUSFormat(Date date)  {
        var dateFormat = new SimpleDateFormat(US_DATE_FORMAT);
        return dateFormat.format(date);
    }
    public static int daysBetween(Date date1, Date date2) {
        if (date1 != null && date2 != null) {
            // Determine the earlier and later date
            Date high = date1.getTime() >= date2.getTime() ? date1 : date2;
            Date low = high == date1 ? date2 : date1;
            // Calculate the difference in days
            return differenceInDays(low, high);
        } else {
            throw new NullPointerException("Null date");
        }
    }
    public static int differenceInDays(Date startDate, Date endDate) {
        if (startDate != null && endDate != null) {
            LocalDate start = convertToLocalDate(startDate);
            LocalDate end = convertToLocalDate(endDate);

            return (int) ChronoUnit.DAYS.between(start, end);
        } else {
            throw new NullPointerException("Null date");
        }
    }
    private static LocalDate convertToLocalDate(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return LocalDate.of(
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH) + 1,
                calendar.get(Calendar.DAY_OF_MONTH)
        );
    }
    public static String dateFormatter(String value){
        String formatStr = value.substring(0, value.length() - 14);
        LocalDate date = LocalDate.parse(formatStr, DateTimeFormatter.ISO_DATE);
        return date.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
    }
}
