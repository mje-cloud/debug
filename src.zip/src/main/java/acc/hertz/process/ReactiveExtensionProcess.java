package acc.hertz.process;

import acc.hertz.client.composite.ICompositeClient;
import acc.hertz.model.activitypattern.ActivityPattern;
import acc.hertz.model.activitypattern.ActivityPost;
import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.history.History;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestList;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestPost;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestPostResponse;
import acc.hertz.model.enums.ContractStatus;
import acc.hertz.model.enums.EntityEventType;
import acc.hertz.model.enums.HistoryType;
import acc.hertz.model.enums.ServiceRequestProgress;
import acc.hertz.model.hertz.outbound.BaseHertzRequest;
import acc.hertz.model.hertz.outbound.BaseHertzResponse;
import acc.hertz.processors.composite.helper.CompositeRentalReactiveExtensionHelper;
import acc.hertz.processors.composite.helper.payload.ActivityPostComposite;
import acc.hertz.processors.composite.helper.payload.HistoryComposite;
import acc.hertz.processors.composite.helper.payload.ServiceRequestPostComposite;
import acc.hertz.util.Converter;
import gw.api.ig.GwUtilities;
import org.apache.camel.Exchange;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.Date;
import java.util.UUID;

@Named
public class ReactiveExtensionProcess {

    @Inject
    private ReservationHelper reservationHelper;
    @Inject
    private CompositeRentalReactiveExtensionHelper compositeRentalReactiveExtensionHelper;
    @Inject
    private ICompositeClient compositeClient;

    public BaseHertzResponse processReactiveExtension(BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception {
        BaseHertzResponse response = null;
        ServiceRequestPostComposite serviceRequestPatch = null;
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
        try {
            /**
             * 1.2If Claim exist and is open state then continue with step 2
             *
             *     1.2.1 If claim condition are not match return a message error on log and trow an exception
             *               1.2.1.1 if claim do not exist  = Claim {id} not found
             *               if claim is not in open state =  Claim {id} is not in Open state
             */
            ClaimData claim = reservationHelper.findClaim(exchange, baseHertzRequest);
            /**
             *   1.2.2 Find on cloud api if service request exists using the cloud api filter object from the service request web service  from tsd payload
             * "HertzTransactionContractID_Ext" ==  TransactionContractId from tsd payload
             * "HertzTransactionGUID_Ext"" ==  TransactionGUID from tsd payload
             *       if cloud api query return matching then throw an exception "
             * Assigment ID already exists and transaction type demands to create a new service"
             *      If not match continue next step
             */
            ServiceRequestList.ServiceRequest serviceRequest = reservationHelper.findServiceRequestWithReservation(claim, baseHertzRequest, HistoryType.HERTZ_REACTIVE_EXTENSION_ACC);
            if (!serviceRequest.getAttributes().getHertzContractStatus_Ext().getCode().equalsIgnoreCase(ContractStatus.RENTAL_OPEN.getCode()) &&
                    !serviceRequest.getAttributes().getHertzContractStatus_Ext().getCode().equalsIgnoreCase(ContractStatus.RESERVATION_OPEN_WALKUP.getCode())) {
                log.info("Reservation can not be extended using the current Contract Status " + serviceRequest.getAttributes().getHertzContractStatus_Ext().getCode(), new Object(){}.getClass().getEnclosingMethod().getName());
                throw new Exception("Reservation can not be extended using the current Contract Status " + serviceRequest.getAttributes().getHertzContractStatus_Ext().getCode());
            }
            if(!serviceRequest.getAttributes().getProgress().getCode().equalsIgnoreCase(ServiceRequestProgress.IN_PROGRESS.getCode())){
                log.info("Reservation can not be extended if service request is not in " + ServiceRequestProgress.IN_PROGRESS.getCode(), new Object(){}.getClass().getEnclosingMethod().getName());
                throw new Exception("Reservation can not be extended if service request is not in " + ServiceRequestProgress.IN_PROGRESS.getCode());
            }
            serviceRequestPatch = new ServiceRequestPostComposite();
            serviceRequestPatch.setData(new ServiceRequestPostComposite.Data());
            serviceRequestPatch.getData().setAttributes(new ServiceRequestPostComposite.Attributes());

            /**
             * Step 3.Mapping form service request patch
             */

            serviceRequestPatch.getData().getAttributes().setHertzIncrementalDays_Ext(baseHertzRequest.getClaimInfo().getIncrementalDays());
            serviceRequestPatch.getData().getAttributes().setHertzTotalDaysApproved_Ext(baseHertzRequest.getClaimInfo().getTotalDays());
            serviceRequestPatch.getData().getAttributes().setHertzContractStatus_Ext(new ServiceRequestPostComposite.CodeName());
            serviceRequestPatch.getData().getAttributes().getHertzContractStatus_Ext().setCode(ContractStatus.REACTIVE_EXTENSION.getCode());
            serviceRequestPatch.getData().getAttributes().getHertzContractStatus_Ext().setName(ContractStatus.REACTIVE_EXTENSION.getName());
            String hertzRentalEndDate_Ext = Converter.parseDateToJSONTimeZone(Converter.addDays(Converter.parseJsonDateToUtilDate(serviceRequest.getAttributes().getHertzRentalBeginDate_Ext()), (baseHertzRequest.getClaimInfo().getTotalDays() - 1)));
            serviceRequestPatch.getData().getAttributes().setHertzRentalEndDate_Ext(hertzRentalEndDate_Ext);

            //  ServiceRequestPostResponse responseRental = reservationHelper.updateRental(claim, serviceRequest, serviceRequestPatch);
            // if (responseRental != null) {
            /**
             * Step 4. Create the  HertzRentalStatusHistory_Ext using the api exposed on common api cloud api.
             */
            HistoryComposite newHistory = new HistoryComposite();
            newHistory.setData(new HistoryComposite.Data());
            newHistory.getData().setAttributes(new HistoryComposite.Data.Attributes());
            newHistory.getData().getAttributes().setClaim(new HistoryComposite.Data.Attributes.Claim());
            newHistory.getData().getAttributes().getClaim().setId(claim.getData().getAttributes().getId());
            newHistory.getData().getAttributes().getClaim().setType(EntityEventType.CLAIM.getType());
            newHistory.getData().getAttributes().setServiceRequest(new HistoryComposite.Data.Attributes.ServiceRequest());
            newHistory.getData().getAttributes().setUser(new HistoryComposite.Data.Attributes.User());
            newHistory.getData().getAttributes().getUser().setId(claim.getData().getAttributes().getAssignedUser().getId());
            newHistory.getData().getAttributes().getUser().setType(EntityEventType.USER.getType());
            newHistory.getData().getAttributes().setType(new HistoryComposite.Data.Attributes.Type());
            newHistory.getData().getAttributes().getType().setCode(HistoryType.HERTZ_REACTIVE_EXTENSION_ACC.getCode());
            newHistory.getData().getAttributes().getType().setName(HistoryType.HERTZ_REACTIVE_EXTENSION_ACC.getName());
            newHistory.getData().getAttributes().setDescription(HistoryType.HERTZ_REACTIVE_EXTENSION_ACC.getDescription()
                    .replace("$1", (baseHertzRequest.getClaimInfo().getClaimNoteRentalInstructions() != null ? baseHertzRequest.getClaimInfo().getClaimNoteRentalInstructions() : ""))
                    .replace("$2", (baseHertzRequest.getRentalInfo().getNoteSend() != null ? baseHertzRequest.getRentalInfo().getNoteSend() : ""))
                    .replace("$3", String.valueOf(baseHertzRequest.getClaimInfo().getTotalDays())));
            newHistory.getData().getAttributes().setRequest(reservationHelper.parseRequestAsJSON(baseHertzRequest));

            /**
             * Step 5. Create new activity warning
             */
            ActivityPostComposite newActivity = new ActivityPostComposite();
            newActivity.setData(new ActivityPostComposite.Data());
            newActivity.getData().setAttributes(new ActivityPostComposite.Attributes());
            newActivity.getData().getAttributes().setActivityPattern(ActivityPattern.HERTZ_REACTIVE_EXTENSION_ACC.getCode());
            newActivity.getData().getAttributes().setRelatedTo(new ActivityPostComposite.RelatedTo());
            newActivity.getData().getAttributes().setSubject(ActivityPattern.HERTZ_REACTIVE_EXTENSION_ACC.getSubject());
            newActivity.getData().getAttributes().setDescription(ActivityPattern.HERTZ_REACTIVE_EXTENSION_ACC.getDescription()
                    .replace("$1", (baseHertzRequest.getClaimInfo().getClaimNoteRentalInstructions() != null ? baseHertzRequest.getClaimInfo().getClaimNoteRentalInstructions() : ""))
                    .replace("$2", (baseHertzRequest.getRentalInfo().getNoteSend() != null ? baseHertzRequest.getRentalInfo().getNoteSend() : ""))
                    .replace("$3", String.valueOf(baseHertzRequest.getClaimInfo().getTotalDays())));

            String stickySessionToken = UUID.randomUUID().toString();
            var abstractRequest = compositeRentalReactiveExtensionHelper.buildCompositeRequest(claim,
                    serviceRequest,
                    serviceRequestPatch,
                    newHistory,
                    newActivity);
            compositeClient.executeCompositeRequest(exchange, stickySessionToken, abstractRequest);

            response = new BaseHertzResponse();
            response.setMessage(HistoryType.HERTZ_REACTIVE_EXTENSION_ACC.getName() + "processed and waiting for adjuster approval");
            response.setMsgType("success");
            response.setTransactionGuid(baseHertzRequest.getTransactionGUID());
            response.setTransactionContractId(baseHertzRequest.getTransactionContractId());
            response.setTransactionType(baseHertzRequest.getTransactionType());
            response.setMsgGuid(baseHertzRequest.getTransactionGUID());
            response.setTransactionDate(baseHertzRequest.getTransactionDate());
            response.setMsgDate(Converter.parseDateToJSON(new Date()));
            //}
        } catch (Exception e) {
            log.error("Error", new Object() {
            }.getClass().getEnclosingMethod().getName(), e);
            throw e;
        }
        return response;
    }


}
