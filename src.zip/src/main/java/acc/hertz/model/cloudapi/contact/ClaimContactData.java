package acc.hertz.model.cloudapi.contact;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class ClaimContactData {

    @JsonProperty("data")
    private DataAttributes data;

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class DataAttributes {

        @JsonProperty("attributes")
        private Attributes attributes;

        @JsonProperty("checksum")
        private String checksum;

        @JsonProperty("links")
        private Links links;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Attributes {
        @JsonProperty("companyName")
        private String companyName;

        @JsonProperty("authorizationID")
        private String authorizationID;

        @JsonProperty("cellPhone")
        private Phone cellPhone;
        @JsonProperty("homePhone")
        private Phone homePhone;

        @JsonProperty("contactSubtype")
        private String contactSubtype;

        @JsonProperty("dateOfBirth")
        private String dateOfBirth;

        @JsonProperty("displayName")
        private String displayName;

        @JsonProperty("emailAddress1")
        private String emailAddress1;

        @JsonProperty("emailAddress2")
        private String emailAddress2;

        @JsonProperty("firstName")
        private String firstName;

        @JsonProperty("gender")
        private CodeName gender;

        @JsonProperty("id")
        private String id;

        @JsonProperty("lastName")
        private String lastName;

        @JsonProperty("licenseNumber")
        private String licenseNumber;

        @JsonProperty("licenseState")
        private CodeName licenseState;
        @JsonProperty("internalId_Ext")
        private String internalId_Ext;
        @JsonProperty("primaryAddress")
        private Address primaryAddress;

        @JsonProperty("primaryPhone")
        private String primaryPhone;

        @JsonProperty("primaryPhoneType")
        private CodeName primaryPhoneType;

        @JsonProperty("pronounAggregate")
        private CodeName pronounAggregate;

        @JsonProperty("pronounAggregateDisplay")
        private String pronounAggregateDisplay;

        @JsonProperty("pronounObjective")
        private String pronounObjective;

        @JsonProperty("pronounPossessive")
        private String pronounPossessive;

        @JsonProperty("pronounSubjective")
        private String pronounSubjective;

        @JsonProperty("roles")
        private List<Role> roles;

        @JsonProperty("taxId")
        private String taxId;

        @JsonProperty("workPhone")
        private Phone workPhone;

        @JsonProperty("hertzIDStoreOffice_Ext")
        private String hertzIDStoreOffice_Ext;

    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Phone {

        @JsonProperty("countryCode")
        private CodeName countryCode;

        @JsonProperty("displayName")
        private String displayName;

        @JsonProperty("extension")
        private String extension;

        @JsonProperty("number")
        private String number;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class CodeName {

        @JsonProperty("code")
        private String code;

        @JsonProperty("name")
        private String name;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Address {

        @JsonProperty("addressLine1")
        private String addressLine1;

        @JsonProperty("addressLine2")
        private String addressLine2;

        @JsonProperty("addressLine3")
        private String addressLine3;

        @JsonProperty("addressType")
        private CodeName addressType;

        @JsonProperty("city")
        private String city;

        @JsonProperty("country")
        private String country;

        @JsonProperty("county")
        private String county;

        @JsonProperty("description")
        private String description;

        @JsonProperty("displayName")
        private String displayName;

        @JsonProperty("id")
        private String id;

        @JsonProperty("postalCode")
        private String postalCode;

        @JsonProperty("state")
        private CodeName state;

        @JsonProperty("province")
        private CodeName province;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Role {

        @JsonProperty("active")
        private boolean active;

        @JsonProperty("relatedTo")
        private RelatedTo relatedTo;

        @JsonProperty("role")
        private CodeName role;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class RelatedTo {

        @JsonProperty("displayName")
        private String displayName;

        @JsonProperty("id")
        private String id;

        @JsonProperty("type")
        private String type;

        @JsonProperty("uri")
        private String uri;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Links {

        @JsonProperty("self")
        private Self self;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Self {

        @JsonProperty("href")
        private String href;

        @JsonProperty("methods")
        private List<String> methods;
    }
}
