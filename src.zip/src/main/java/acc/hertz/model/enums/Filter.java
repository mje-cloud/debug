
package acc.hertz.model.enums;

public enum Filter {
  CC_REST_URL_FILTER("url-filter"),
  INCLUDE_FILTER("include"),
  POLICY_INCLUDE_EXT("policy"),
  CONTACT_INCLUDE_EXT("contacts"),
  VEHICLE_INCIDENT_EXT("vehicle-incidents"),
  CLAIM_NUMBER_FILTER("claimNumberFilter"),
  CLAIM_NUMBER("claimNumber"),
  POLICY_NUMBER("policyNumber"),
  CLAIM_PUBLIC_ID("claimPublicId"),
  TYPE_KEY_CODE("code"),
  TYPE_KEY_FILTER_KEYWORD("typekeyFilter"),
  HERTZ_TRANSACTION_GUID_EXT("hertzTransactionGUID_Ext"),
  HERTZ_TRANSACTION_TSD_ID_EXT("hertzTransactionTSDID_Ext"),
  HERTZ_SERVICE_REQUEST_RENTAL_EXT("serviceRequestId_Ext"),
  HERTZ_TRANSACTION_CONTRACT_ID_EXT("hertzTransactionContractID_Ext"),
  CLOUD_API_SEPARATOR("::"),
  FILTER_KEYWORD("filter");
  private final String code;

  private Filter(String code) {
    this.code = code;
  }

  public String getCode() {
    return code;
  }

  public String toString() {
    return code;
  }


}

