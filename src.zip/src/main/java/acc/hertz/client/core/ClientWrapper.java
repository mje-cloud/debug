package acc.hertz.client.core;


import acc.hertz.security.ICredential;
import acc.hertz.security.authorization.AuthorizationType;
import acc.hertz.util.AppUtils;
import org.apache.camel.Exchange;
import org.apache.hc.core5.http.HttpStatus;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.net.ConnectException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;

@Named
public class ClientWrapper implements IClient {

    private final String CONTENT_SECURITY_POLICY ="Content-Security-Policy";
    private final String CONTENT_SECURITY_POLICY_VALUE  ="self";
    private final String CACHE_CONTROL  ="Cache-Control";
    private final String CACHE_CONTROL_VALUE  ="no-store, max-age=0";
    private final String STRICT_TRANSPORT_SECURITY  ="Strict-Transport-Security";
    private final String STRICT_TRANSPORT_SECURITY_VALUE  ="max-age=31536000; includeSubDomains";
    private HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(360)).build();
    private HttpRequest.Builder builder;
    private final Map<String, String> headers = new HashMap<>();
    private final Map<String, Object> headerResponse = new HashMap<>();
    private int statusCode;
    private String responseBody;
    private byte[] responseBinary;
    @Inject
    private ICredential credential;

    public Exchange getExchange() {
        return exchange;
    }

    public void setExchange(Exchange exchange) {
        this.exchange = exchange;
    }

    private Exchange exchange;


    private void addSecureHeaders() {
        builder.header(CONTENT_SECURITY_POLICY, CONTENT_SECURITY_POLICY_VALUE);
        builder.header(CACHE_CONTROL, CACHE_CONTROL_VALUE);
        builder.header(STRICT_TRANSPORT_SECURITY, STRICT_TRANSPORT_SECURITY_VALUE);
    }

    @Override
    public void doExecute(String serviceURL, String body, WebMethodType webMethodType, AuthorizationType type) throws Exception {
        try {
            headerResponse.clear();
            statusCode=0;
            responseBody=null;
            builder = HttpRequest.newBuilder().timeout(Duration.ofSeconds(360));
            HttpRequest.BodyPublisher bodyPublisher;
            URI server = URI.create(serviceURL);
            if (body != null && !body.isEmpty()){
                bodyPublisher = HttpRequest.BodyPublishers.ofString(body);
            }else{
                bodyPublisher = HttpRequest.BodyPublishers.noBody();
            }
            builder = HttpRequest.newBuilder();
            switch (webMethodType) {
                case PUT:
                    builder.PUT(bodyPublisher).uri(server);
                    break;
                case DELETE:
                    if (body != null && !body.isEmpty()) {
                        builder.method(WebMethodType.DELETE.getCode(),bodyPublisher).uri(server);
                    }
                    else {
                        builder.DELETE().uri(server);
                    }
                    break;
                case GET:
                    if(body!=null && !body.isEmpty())
                        builder.method(WebMethodType.GET.getCode(),bodyPublisher).uri(server);
                    else
                        builder.GET().uri(server);
                    break;
                case POST:
                    if (body != null && !body.isEmpty())
                        builder.POST(bodyPublisher).uri(server);
                    else
                        builder.uri(server).POST(bodyPublisher);
                    break;
                case PATCH:
                    builder.method(WebMethodType.PATCH.getCode(),bodyPublisher).uri(server);
                    break;
                default:
                    return;
            }
            addSecureHeaders();
            for (String key : headers.keySet())
                builder.header(key, headers.get(key));
            if(type != AuthorizationType.NO_AUTHORIZATION_ACCESS){
                String token = credential.getCredential(exchange,type);
                builder.header(AppUtils.AUTHORIZATION, token);
            }

            HttpRequest httpRequest = builder.build();
            HttpClient httpClient = HttpClient.newHttpClient();
            // Send the request asynchronously and handle the response
            CompletableFuture<HttpResponse<String>> responseFuture = httpClient.sendAsync(httpRequest, HttpResponse.BodyHandlers.ofString());
            // Process the response when it arrives
            responseFuture.thenAccept(response -> {
                for(var header : response.headers().map().keySet()){
                    headerResponse.put(header,response.headers().map().get(header));
                }
                responseBody = response.body();
                statusCode = response.statusCode();
            }).join();
        }catch (CompletionException e ) {
            throw new Exception("Error processing Rest Client " + statusCode + " " + AppUtils.sanitize(responseBody));
        }catch (ConnectException e ) {
            throw new Exception("Error processing Rest Client " + statusCode + " " + AppUtils.sanitize(responseBody));
        } catch (Exception e ) {
            throw new Exception("Error processing Rest Client " + e.getMessage() + " " + AppUtils.sanitize(responseBody));
        }
    }

    @Override
    public void doExecuteBinary(String serviceURL, List<byte[]> body, WebMethodType webMethodType, AuthorizationType type) throws Exception {
        try {
            headerResponse.clear();
            statusCode=0;
            responseBody=null;
            builder = HttpRequest.newBuilder().timeout(Duration.ofSeconds(360));
            switch (webMethodType) {
                case POST:
                    builder.POST(HttpRequest.BodyPublishers.ofByteArrays(body)).uri(URI.create(serviceURL));
                    break;
                case PUT:
                    builder.PUT(HttpRequest.BodyPublishers.ofByteArrays(body)).uri(URI.create(serviceURL));
                    break;
                case PATCH:
                    builder.method(WebMethodType.PATCH.getCode(), HttpRequest.BodyPublishers.ofByteArrays(body)).uri(URI.create(serviceURL));
                    break;
                default:
                    throw new Exception("Invalid web method");
            }
            addSecureHeaders();
            for (String key : headers.keySet())
                builder.header(key, headers.get(key));
            if(type != AuthorizationType.NO_AUTHORIZATION_ACCESS){
                String token = credential.getCredential(exchange,type);
                builder.header(AppUtils.AUTHORIZATION, token);
            }

            HttpRequest httpRequest = builder.build();
            HttpClient httpClient = HttpClient.newHttpClient();
            // Send the request asynchronously and handle the response
            CompletableFuture<HttpResponse<byte[]>> responseFuture = httpClient.sendAsync(httpRequest, HttpResponse.BodyHandlers.ofByteArray());
            // Process the response when it arrives
            responseFuture.thenAccept(response -> {
                for(var header : response.headers().map().keySet()){
                    headerResponse.put(header,response.headers().map().get(header));
                }
                responseBinary = response.body();
                statusCode = response.statusCode();
            }).join();
        }catch (CompletionException e ) {
            throw new Exception("Error processing Rest Client " + statusCode + " " + AppUtils.sanitize(responseBody));
        }catch (ConnectException e ) {
            throw new Exception("Error processing Rest Client " + statusCode + " " + AppUtils.sanitize(responseBody));
        } catch (Exception e ) {
            throw new Exception("Error processing Rest Client " + statusCode + " " + AppUtils.sanitize(responseBody));
        }
    }

    @Override
    public void doExecute( String serviceURL, WebMethodType webMethodType, AuthorizationType type) throws Exception {
        doExecute( serviceURL, null, webMethodType, type);
    }

    public void addHeaderParameter(String name, String value) {
        headers.put(name, value);
    }

    @Override
    public Map<String, Object> getHeaderResponse() {
        return headerResponse;
    }

    @Override
    public String getResponseBody() {
        return responseBody;
    }

    @Override
    public byte[] getResponseBinary() {
        return responseBinary;
    }

    public void clearHeaders(){
        headers.clear();
    }
    public int getResponseCode() {
        return statusCode;
    }

    @Override
    public boolean isSuccessExecuted() {
        return getResponseCode() == HttpStatus.SC_OK ||
               getResponseCode() == HttpStatus.SC_CREATED ||
               getResponseCode() == HttpStatus.SC_ACCEPTED ||
               getResponseCode() == HttpStatus.SC_NO_CONTENT ||
               getResponseCode() == HttpStatus.SC_PARTIAL_CONTENT;
    }

    @Override
    public void doExecuteBinary(String serviceURL, WebMethodType webMethodType, AuthorizationType type) throws Exception {
        try {
            builder = HttpRequest.newBuilder();
            switch (webMethodType) {
                case GET:
                    builder.GET().uri(URI.create(serviceURL));
                    break;
                default:
                     throw new Exception("Invalid web method");
            }
            addSecureHeaders();
            for (String key : headers.keySet())
                builder.header(key, headers.get(key));
            if(type != AuthorizationType.NO_AUTHORIZATION_ACCESS){
                String token = credential.getCredential(exchange,type);
                builder.header(AppUtils.AUTHORIZATION, token);
            }
            HttpRequest httpRequest = builder.build();
            HttpClient httpClient = HttpClient.newHttpClient();
            // Send the request asynchronously and handle the response
            CompletableFuture<HttpResponse<byte[]>> responseFuture = httpClient.sendAsync(httpRequest, HttpResponse.BodyHandlers.ofByteArray());
            // Process the response when it arrives
            responseFuture.thenAccept(response -> {
                for(var header : response.headers().map().keySet()){
                    headerResponse.put(header,response.headers().map().get(header));
                }
                responseBinary = response.body();
                statusCode = response.statusCode();
            }).join();
        } catch (CompletionException e ) {
            throw new Exception("Error processing Rest Client " + statusCode + " " + AppUtils.sanitize(responseBody));
        }catch (ConnectException e ) {
            throw new Exception("Error processing Rest Client " + statusCode + " " + AppUtils.sanitize(responseBody));
        } catch (Exception e ) {
            throw new Exception("Error processing Rest Client " + statusCode + " " + AppUtils.sanitize(responseBody));
        }
    }


}
