package acc.hertz.client.service;

import acc.hertz.model.activitypattern.ActivityPost;
import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.claim.ClaimInfo;
import acc.hertz.model.cloudapi.claim.User;
import acc.hertz.model.cloudapi.contact.ClaimContactData;
import acc.hertz.model.cloudapi.contact.ClaimContactPost;
import acc.hertz.model.cloudapi.contact.VendorContactData;
import acc.hertz.model.cloudapi.servicerequest.*;
import acc.hertz.model.cloudapi.typelist.TypeLists;
import org.apache.camel.Exchange;

public interface IClaimClient {

    ServiceRequestInvoice addServiceRequestInvoice(String stickySessionToken,ClaimData claim, ServiceRequestList.ServiceRequest currentService, ServiceRequestInvoice serviceRequestInvoice) throws Exception;

    ServiceRequestPostResponse declineServiceRequest(String stickySessionToken,ClaimData claim, String serviceRequestId, ServiceRequestDecline serviceRequestDecline) throws Exception;

    ServiceRequestPostResponse cancelServiceRequest(ClaimData claim, String serviceRequestId, ServiceRequestCancel serviceRequestCancel) throws Exception;

    ServiceRequestPostResponse workCompletedServiceRequest(String stickySessionToken,ClaimData claim, String serviceRequestId) throws Exception;

    ServiceRequestPostResponse submitServiceRequest(String stickySessionToken,ClaimData claim, String serviceRequestId) throws Exception;

    ServiceRequestPostResponse patchServiceRequest(ClaimData claim, ServiceRequestList.ServiceRequest currentServiceRequest, ServiceRequestPost serviceRequestPost) throws Exception;

    ServiceRequestPostResponse acceptServiceRequest(String stickySessionToken,ClaimData claim, String serviceRequestId, ServiceRequestAccepted serviceRequestPost) throws Exception;

    boolean postActivityWarning(ClaimData claim, ActivityPost body) throws Exception;

    ServiceRequestPostResponse draftServiceRequest(ClaimData claim, ServiceRequestPost serviceRequestPost) throws Exception;

    ServiceRequestList getServiceRequestData(String claimId, String filter) throws Exception;

    boolean addInvoiceServiceRequest(String stickySessionToken,ClaimData claim, ServiceRequestList.ServiceRequest serviceRequest, ServiceRequestPatch serviceRequestPatch) throws Exception;

    User getUserAssigned(String userId) throws Exception;

    ClaimContactData getClaimContact(String claimId, String claimContactId) throws Exception;

    ServiceRequestList getServiceRequestData(String claimId) throws Exception;

    ClaimInfo getClaimData(Exchange exchange, String claimId, String filter) throws Exception;

    ClaimInfo getClaimByClaimNumber(Exchange exchange, String claimNumber) throws Exception;

    ClaimData getClaimData(Exchange exchange, String claimId) throws Exception;

    ClaimContactData createClaimContact(Exchange exchange, String claimId, ClaimContactPost claimContactData) throws Exception;

    ServiceRequestList createServiceRequestData(Exchange exchange, ServiceRequestList serviceRequest, String claimId) throws Exception;

    TypeLists getTypeListByName(Exchange exchange, String typelistName, String filter) throws Exception;
    public VendorContactData createVendorContact(Exchange exchange, String claimId) throws Exception;
}
