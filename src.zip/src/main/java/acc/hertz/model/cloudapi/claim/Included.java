package acc.hertz.model.cloudapi.claim;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Included {
    @JsonProperty("ClaimContact")
    private List<ClaimContact> claimContacts;

    @JsonProperty("Policy")
    private List<Policy> policies;

    @JsonProperty("VehicleIncident")
    private List<VehicleIncident> vehicleIncidents;


    public List<ClaimContact> getClaimContacts() {
        return claimContacts;
    }

    public void setClaimContacts(List<ClaimContact> claimContacts) {
        this.claimContacts = claimContacts;
    }


    public List<VehicleIncident> getVehicleIncidents() {
        return vehicleIncidents;
    }

    public void setVehicleIncidents(List<VehicleIncident> vehicleIncidents) {
        this.vehicleIncidents = vehicleIncidents;
    }

    public List<Policy> getPolicies() {
        return policies;
    }

    public void setPolicies(List<Policy> policies) {
        this.policies = policies;
    }
}

