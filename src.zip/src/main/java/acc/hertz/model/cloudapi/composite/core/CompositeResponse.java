package acc.hertz.model.cloudapi.composite.core;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class CompositeResponse {

    @JsonProperty("commitError")
    private Object commitError;

    @JsonProperty("requestFailed")
    private Boolean requestFailed;

    @JsonProperty("responses")
    private List<Response> responses;

    @JsonProperty("selections")
    private List<Selection> selections;

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Response {

        @JsonProperty("body")
        private Object body;

        @JsonProperty("headers")
        private Map<String, String> headers;

        @JsonProperty("requestError")
        private Object requestError;

        @JsonProperty("responseIncluded")
        private Boolean responseIncluded;

        @JsonProperty("responseSerializationError")
        private Object responseSerializationError;

        @JsonProperty("responseSerializationFailed")
        private Boolean responseSerializationFailed;

        @JsonProperty("skipped")
        private Boolean skipped;

        @JsonProperty("status")
        private Integer status;

        @JsonProperty("varsError")
        private Object varsError;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Selection {

        @JsonProperty("body")
        private Object body;

        @JsonProperty("headers")
        private Map<String, String> headers;

        @JsonProperty("requestError")
        private Object requestError;

        @JsonProperty("responseIncluded")
        private Boolean responseIncluded;

        @JsonProperty("responseSerializationError")
        private Object responseSerializationError;

        @JsonProperty("responseSerializationFailed")
        private Boolean responseSerializationFailed;

        @JsonProperty("skipped")
        private Boolean skipped;

        @JsonProperty("status")
        private Integer status;

        @JsonProperty("varsError")
        private Object varsError;
    }
}