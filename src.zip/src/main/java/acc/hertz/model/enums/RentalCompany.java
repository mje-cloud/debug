package acc.hertz.model.enums;

/**
 * Enum to represent Hertz Rental Companies for integration.
 */
public enum RentalCompany {
    HERTZ("hertz", "Hertz"),
    NO_INTEGRATION("basic", "");

    private final String code;
    private final String description;

    RentalCompany(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }
}


