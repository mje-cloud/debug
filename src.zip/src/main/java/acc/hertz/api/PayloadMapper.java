package acc.hertz.api;


import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestList;
import acc.hertz.model.enums.TransactionGUID;
import acc.hertz.model.enums.TransactionType;
import acc.hertz.model.hertz.inbound.AssignmentRequest;
import acc.hertz.model.hertz.shared.TransactionRequestHeader;
import acc.hertz.util.AppProperty;
import acc.hertz.util.AppUtils;
import acc.hertz.util.Converter;
import org.apache.camel.Exchange;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.Date;
import java.util.UUID;

@Named
public class PayloadMapper {

    @Inject
    private AppProperty properties;
    @Inject
    private ServiceMapper mapper;

    public  AssignmentRequest createNewAssignmentPayload(Exchange exchange,ClaimData claim, ServiceRequestList.ServiceRequest serviceRequest) throws Exception {
      AssignmentRequest assignmentRequest=null;
      try{
        String randomUUID = UUID.randomUUID().toString()+serviceRequest.getAttributes().getServiceRequestNumber();
        TransactionRequestHeader header = new TransactionRequestHeader();
        header.setMsgGuid(TransactionGUID.GW_INBOUND_ASSIGNMENT_POST.getName());
        header.setMsgDate(Converter.parseDateToJSONTimeZone(new Date()));
        header.setTransactionDate(Converter.parseDateToJSONTimeZone(new Date()));
        header.setTransactionGuid(AppUtils.stringSizeRefactoring(randomUUID,40));
        header.setTransactionType(TransactionType.NEW_ASSIGNMENT.getName());
        header.setTransactionPassThroughId("");
        header.setTransactionUserId(mapper.getUserHertz(properties));
        header.setTransactionContractId(serviceRequest.getAttributes().getServiceRequestNumber());
        header.setTransactionTsdId(properties.getMsgSource());
        assignmentRequest = mapper.mapServiceRequesToAssignmentRequest(exchange,header,claim,serviceRequest);
        assignmentRequest.getClaimInfo().setIncrementalDays(0);

        if((serviceRequest.getAttributes().getHertzRateInclusivePrice_Ext().getAmount()!= null || Double.parseDouble(serviceRequest.getAttributes().getHertzRateInclusivePrice_Ext().getAmount()) <= 0) && !serviceRequest.getAttributes().isHertzCustomerSelfPay_Ext())
          assignmentRequest.getClaimInfo().setPayDailyAmount(assignmentRequest.getPolicy().getDailyMaxCoverage());

       /**
        * This needs to be done after all mapping has finished same as gosu class HertzMapperUtil.transformAssignmentRequest method
        */
         if(!header.getTransactionType().equalsIgnoreCase(TransactionType.AUTH_UPDATE.getName()) && !header.getTransactionType().equalsIgnoreCase(TransactionType.RENTAL_CLOSE.getName()) && !header.getTransactionType().equalsIgnoreCase(TransactionType.CANCEL.getName())){
             assignmentRequest.getClaimInfo().setAuthFinalDate("");
         }

        } catch (Exception e) {
            throw new Exception("Error creating payload message: "+ e.getMessage());
        }
        return assignmentRequest;
    }

    public  AssignmentRequest createEditReservationPayload(Exchange exchange,ClaimData claim, ServiceRequestList.ServiceRequest serviceRequest, boolean setFinalDay) throws Exception {
        AssignmentRequest assignmentRequest=null;
        try {
            TransactionRequestHeader header = new TransactionRequestHeader();
            header.setMsgGuid(TransactionGUID.GW_INBOUND_PUT_AUTH_UPDATE_04A.getName());
            header.setMsgDate(Converter.parseDateToJSONTimeZone(new Date()));
            header.setTransactionDate(Converter.parseDateToJSONTimeZone(new Date()));
            header.setTransactionGuid(serviceRequest.getAttributes().getHertzTransactionGUID_Ext());
            header.setTransactionType(TransactionType.AUTH_UPDATE.getName());
            header.setTransactionPassThroughId("");
            header.setTransactionUserId(mapper.getUserHertz(properties));
            header.setTransactionContractId(serviceRequest.getAttributes().getHertzTransactionContractID_Ext());

            assignmentRequest = mapper.mapServiceRequesToAssignmentRequest(exchange,header,claim,serviceRequest);
            if((serviceRequest.getAttributes().getHertzRateInclusivePrice_Ext().getAmount()!= null || Double.parseDouble(serviceRequest.getAttributes().getHertzRateInclusivePrice_Ext().getAmount()) <= 0) && !serviceRequest.getAttributes().isHertzCustomerSelfPay_Ext())
                assignmentRequest.getClaimInfo().setPayDailyAmount(assignmentRequest.getPolicy().getDailyMaxCoverage());

            /**
             * This needs to be done after all mapping has finished same as gosu class HertzMapperUtil.transformAssignmentRequest method
             */
//            //if(!header.getTransactionType().equalsIgnoreCase(TransactionType.AUTH_UPDATE.getName()) && !header.getTransactionType().equalsIgnoreCase(TransactionType.RENTAL_CLOSE.getName()) && !header.getTransactionType().equalsIgnoreCase(TransactionType.CANCEL.getName())){
//            assignmentRequest.getClaimInfo().setAuthFinalDate("");
//           // }
            if(!setFinalDay)
                assignmentRequest.getClaimInfo().setAuthFinalDate(null);

            if(header.getTransactionType().equalsIgnoreCase(TransactionType.NEW_ASSIGNMENT.getName())){
                assignmentRequest.setTransactionTsdId(properties.getMsgSource());
            } else{
                assignmentRequest.setTransactionTsdId(serviceRequest.getAttributes().getHertzTransactionTSDID_Ext()!=null ? serviceRequest.getAttributes().getHertzTransactionTSDID_Ext():serviceRequest.getAttributes().getHertzTransactionContractID_Ext());
            }


        } catch (Exception e) {
            throw new Exception("Error creating payload message");
        }
        return assignmentRequest;
    }

    public  AssignmentRequest createCancelReservationPayload(Exchange exchange,ClaimData claim, ServiceRequestList.ServiceRequest serviceRequest) throws Exception {
        AssignmentRequest assignmentRequest=null;
        try {
            TransactionRequestHeader header = new TransactionRequestHeader();
            header.setMsgGuid(TransactionGUID.GW_INBOUND_PUT_CANCEL_01A.getName());
            header.setMsgDate(Converter.parseDateToJSONTimeZone(new Date()));
            header.setTransactionDate(Converter.parseDateToJSONTimeZone(new Date()));
            header.setTransactionGuid(serviceRequest.getAttributes().getHertzTransactionGUID_Ext());
            header.setTransactionType(TransactionType.CANCEL.getName());
            header.setTransactionPassThroughId("");
            header.setTransactionUserId(mapper.getUserHertz(properties));
            header.setTransactionContractId(serviceRequest.getAttributes().getHertzTransactionContractID_Ext());
            assignmentRequest = mapper.mapServiceRequesToAssignmentRequest(exchange,header,claim,serviceRequest);
            if((serviceRequest.getAttributes().getHertzRateInclusivePrice_Ext().getAmount()!= null || Double.parseDouble(serviceRequest.getAttributes().getHertzRateInclusivePrice_Ext().getAmount()) <= 0) && !serviceRequest.getAttributes().isHertzCustomerSelfPay_Ext())
                assignmentRequest.getClaimInfo().setPayDailyAmount(assignmentRequest.getPolicy().getDailyMaxCoverage());

            /**
             * This needs to be done after all mapping has finished same as gosu class HertzMapperUtil.transformAssignmentRequest method
             */
            if(!header.getTransactionType().equalsIgnoreCase(TransactionType.AUTH_UPDATE.getName()) && !header.getTransactionType().equalsIgnoreCase(TransactionType.RENTAL_CLOSE.getName()) && !header.getTransactionType().equalsIgnoreCase(TransactionType.CANCEL.getName())){
                assignmentRequest.getClaimInfo().setAuthFinalDate("");
            }
            if(header.getTransactionType().equalsIgnoreCase(TransactionType.NEW_ASSIGNMENT.getName())){
                assignmentRequest.setTransactionTsdId(properties.getMsgSource());
            } else{
                assignmentRequest.setTransactionTsdId(serviceRequest.getAttributes().getHertzTransactionTSDID_Ext()!=null ? serviceRequest.getAttributes().getHertzTransactionTSDID_Ext():serviceRequest.getAttributes().getHertzTransactionContractID_Ext());
            }

        } catch (Exception e) {
            throw new Exception("Error creating payload message");
        }
        return assignmentRequest;
    }
}
