package acc.hertz.model.hertz.shared;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Header {
    @JsonProperty("MSGSource")
    private String msgSource;

    @JsonProperty("MSGSourceGroup")
    private String msgSourceGroup;

    @JsonProperty("MSGSourceAuthentication")
    private String msgSourceAuthentication;

    // Getters and setters
    public String getMsgSource() { return msgSource; }

    public void SetMsgSouce(String msgSource) { this.msgSource = msgSource; }

    public String getMsgSourceGroup() { return msgSourceGroup; }

    public void setMsgSourceGroup(String msgSourceGroup) { this.msgSourceGroup = msgSourceGroup; }

    public String getMsgSourceAuthentication() { return msgSourceAuthentication; }

    public void setMsgSourceAuthentication(String msgSourceAuthentication) {
        this.msgSourceAuthentication = msgSourceAuthentication;
    }
}
