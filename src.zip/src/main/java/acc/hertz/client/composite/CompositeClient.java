package acc.hertz.client.composite;


import acc.hertz.client.core.IClient;
import acc.hertz.client.core.WebMethodType;
import acc.hertz.model.cloudapi.composite.core.AbstractCompositeRequest;
import acc.hertz.model.enums.MimeType;
import acc.hertz.security.authorization.AuthorizationType;
import acc.hertz.util.AppProperty;
import acc.hertz.util.AppUtils;
import acc.hertz.util.TransformerFactory;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static acc.hertz.util.AppUtils.API_CONTENT_TYPE;


@Named
public class CompositeClient implements ICompositeClient {
	private static final Logger _log = LoggerFactory.getLogger(CompositeClient.class);
    @Inject
    private IClient client;
    @Inject
    private AppProperty property;

    @Override
    public String executeCompositeRequest(Exchange exchange, String gwreSession, AbstractCompositeRequest request) throws Exception {
        try {
            var transformer = TransformerFactory.getTransformer(AbstractCompositeRequest.class);
            String server = property.getCurrentCloudAPIServer();
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.addHeaderParameter(AppUtils.API_X_GWRE_SESSION, gwreSession);
			_log.info("CompositeClient Request is "+transformer.toJson(request));
            client.doExecute(server + AppUtils.COMPOSITE_CREATE, transformer.toJson(request), WebMethodType.POST, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                return client.getResponseBody();
            } else {
                throw new Exception(client.getResponseBody());
            }
        } catch (Exception e) {
            throw e;
        }
    }

}
