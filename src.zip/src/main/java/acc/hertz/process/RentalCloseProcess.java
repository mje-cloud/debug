package acc.hertz.process;


import acc.hertz.client.composite.ICompositeClient;
import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.history.History;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestList;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestPost;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestPostResponse;
import acc.hertz.model.enums.*;
import acc.hertz.model.hertz.outbound.BaseHertzRequest;
import acc.hertz.model.hertz.outbound.BaseHertzResponse;
import acc.hertz.model.hertz.shared.AdditionalCharges;
import acc.hertz.processors.composite.helper.CompositeRentalCloseHelper;
import acc.hertz.processors.composite.helper.payload.HistoryComposite;
import acc.hertz.processors.composite.helper.payload.ServiceRequestPostComposite;
import acc.hertz.util.AppUtils;
import acc.hertz.util.Converter;
import gw.api.ig.GwUtilities;
import org.apache.camel.Exchange;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.Date;
import java.util.UUID;


@Named
public class RentalCloseProcess {
    @Inject
    private ReservationHelper reservationHelper;
    @Inject
    private CompositeRentalCloseHelper compositeRentalCloseHelper;
    @Inject
    private ICompositeClient compositeClient;

    public BaseHertzResponse processRentalClose(BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception {
        BaseHertzResponse response = null;
        ServiceRequestPostComposite serviceRequestPost = null;
        var errorMessage = "";
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
        try {
            log.info("processRentalClose","Inside the processRentalClose class","ClaimNumber",baseHertzRequest.getClaimInfo().getId(), "TransactionType",   baseHertzRequest.getTransactionType(),"method",new Object() {}.getClass().getEnclosingMethod().getName());
            ClaimData claim = reservationHelper.findClaim(exchange,baseHertzRequest);
            ServiceRequestList.ServiceRequest currentServiceRequest = reservationHelper.findServiceRequestWithReservation(claim,baseHertzRequest, HistoryType.HERTZ_RENTAL_CLOSE_ACC);
            var currentServiceRequestAttributes = currentServiceRequest.getAttributes();
            var hertzContractStatusCode = currentServiceRequestAttributes.getHertzContractStatus_Ext().getCode();
            var serviceRequestProgressCode = currentServiceRequestAttributes.getProgress().getCode();
            var baseServReqClaimInfo = baseHertzRequest.getClaimInfo();
            var baseServReqRentalInfo = baseHertzRequest.getRentalInfo();
            log.info("processRentalClose","Inside the processRentalClose class,ServiceRequest Found ","ClaimNumber",baseHertzRequest.getClaimInfo().getId(),
                    "serviceRequestNumber",   currentServiceRequestAttributes.getServiceRequestNumber(),"hertzContractStatusCode",hertzContractStatusCode,
                    "method",new Object() {}.getClass().getEnclosingMethod().getName());
            if(hertzContractStatusCode.equalsIgnoreCase(ContractStatus.RENTAL_CLOSE.getCode()) || hertzContractStatusCode.equalsIgnoreCase(ContractStatus.RENTAL_CANCEL.getCode())){
                response = new BaseHertzResponse();
                response.setMessage(HistoryType.HERTZ_RENTAL_CLOSE_ACC.getName() + " processed");
                response.setMsgType("success");
                response.setTransactionGuid(baseHertzRequest.getTransactionGUID());
                response.setTransactionContractId(baseHertzRequest.getTransactionContractId());
                response.setTransactionType(baseHertzRequest.getTransactionType());
                response.setMsgGuid(baseHertzRequest.getTransactionGUID());
                response.setTransactionDate(baseHertzRequest.getTransactionDate());
                response.setMsgDate(Converter.parseDateToJSON(new Date()));
                return response;
            }

            if(!hertzContractStatusCode.equalsIgnoreCase(ContractStatus.RENTAL_OPEN.getCode()) &&
                    !hertzContractStatusCode.equalsIgnoreCase(ContractStatus.REACTIVE_EXTENSION.getCode())){
                log.info("Reservation can not be closed using the current Contract Status","ClaimNumber",baseHertzRequest.getClaimInfo().getId(),
                        "serviceRequestNumber",   currentServiceRequestAttributes.getServiceRequestNumber(),"hertzContractStatusCode",hertzContractStatusCode, new Object(){}.getClass().getEnclosingMethod().getName());
                throw new Exception(errorMessage);
            }

            if(!serviceRequestProgressCode.equalsIgnoreCase(ServiceRequestProgress.IN_PROGRESS.getCode())){
                log.info("Reservation can not be closed if service request is not in","ClaimNumber",baseHertzRequest.getClaimInfo().getId(),
                        "serviceRequestNumber",   currentServiceRequestAttributes.getServiceRequestNumber(),"hertzContractStatusCode",hertzContractStatusCode,"ServiceRequestStatus",ServiceRequestProgress.IN_PROGRESS.getCode(), new Object(){}.getClass().getEnclosingMethod().getName());
                throw new Exception(errorMessage);
            }

            serviceRequestPost = new ServiceRequestPostComposite();
            serviceRequestPost.setData(new ServiceRequestPostComposite.Data());
            serviceRequestPost.getData().setAttributes(new ServiceRequestPostComposite.Attributes());
            var postServReqAttributes = serviceRequestPost.getData().getAttributes();
            postServReqAttributes.setHertzContractStatus_Ext(new ServiceRequestPostComposite.CodeName());
            postServReqAttributes.getHertzContractStatus_Ext().setCode(ContractStatus.RENTAL_CLOSE.getCode());
            postServReqAttributes.getHertzContractStatus_Ext().setName(ContractStatus.RENTAL_CLOSE.getName());
            postServReqAttributes.setHertzClassCode_Ext(baseServReqClaimInfo.getRentalRequestedClass());
            postServReqAttributes.setHertzClassName_Ext(baseServReqRentalInfo.getRateClass());
            postServReqAttributes.setHertzCustomerSelfPay_Ext(currentServiceRequest.getAttributes().isHertzCustomerSelfPay_Ext());
            postServReqAttributes.setHertzDateType_Ext(new ServiceRequestPostComposite.CodeName());
            postServReqAttributes.getHertzDateType_Ext().setCode(DateType.CALENDAR_DAY.getCode());
            postServReqAttributes.getHertzDateType_Ext().setName(DateType.CALENDAR_DAY.getName());
            postServReqAttributes.setHertzDayCount_Ext(baseServReqClaimInfo.getTotalDays());
            postServReqAttributes.setHertzIncrementalDays_Ext(baseServReqClaimInfo.getIncrementalDays());
            postServReqAttributes.setHertzMaxAuthAmount_Ext(new ServiceRequestPostComposite.Amount());
            postServReqAttributes.getHertzMaxAuthAmount_Ext().setAmount(String.valueOf(baseHertzRequest.getPolicy().getMaxCoverage()));
            postServReqAttributes.getHertzMaxAuthAmount_Ext().setCurrency(reservationHelper.getDefaultCurrency());
            postServReqAttributes.setHertzRateInclusivePrice_Ext(new ServiceRequestPostComposite.Amount());
            postServReqAttributes.getHertzRateInclusivePrice_Ext().setAmount(AppUtils.getValidCurrencyAmount(String.valueOf(baseServReqClaimInfo.getRentalDailyAmount())));
            postServReqAttributes.getHertzRateInclusivePrice_Ext().setCurrency(reservationHelper.getDefaultCurrency());
            if (baseHertzRequest.getPolicy().getDailyMaxCoverage() > 0) {
                postServReqAttributes.setHertzRentalDailyAmount_Ext(new ServiceRequestPostComposite.Amount());
                postServReqAttributes.getHertzRentalDailyAmount_Ext().setAmount(String.valueOf(baseHertzRequest.getPolicy().getDailyMaxCoverage()));
                postServReqAttributes.getHertzRentalDailyAmount_Ext().setCurrency(reservationHelper.getDefaultCurrency());
            } else {
                postServReqAttributes.setHertzRentalDailyAmount_Ext(new ServiceRequestPostComposite.Amount());
                postServReqAttributes.getHertzRentalDailyAmount_Ext().setAmount(String.valueOf(baseServReqClaimInfo.getRentalDailyAmount()));
                postServReqAttributes.getHertzRentalDailyAmount_Ext().setCurrency(reservationHelper.getDefaultCurrency());
            }

              /* CM-8368,CM-8687 PayAllTaxes is linked to VehicleIncident.TaxExempt_CG, it should not be
                 updated as a part of Hertz request to ClaimCenter
              if(baseServReqClaimInfo.getPayTaxes() != null)
                postServReqAttributes.setHertzPayAllTaxes_Ext(!baseServReqClaimInfo.getPayTaxes().equalsIgnoreCase("N"));
                */

            postServReqAttributes.setHertzPercentagePay_Ext(String.valueOf(baseHertzRequest.getPolicy().getPercentPay()));
            postServReqAttributes.setHertzPickupDate_Ext(baseServReqRentalInfo.getPickupDate());
            postServReqAttributes.setHertzRentalBeginDate_Ext(AppUtils.getDateISO8601(baseServReqRentalInfo.getStartDate()));

            var endDate = baseServReqRentalInfo.getEndDate() != null ? AppUtils.getDateISO8601(baseServReqRentalInfo.getEndDate()) : null;
            if (endDate == null) {
                if(baseServReqClaimInfo.getTotalDays() > 0) {
                    endDate = Converter.parseDateToStringUSFormat(Converter.addDays(Converter.parseStringToDateUSFormat(baseServReqRentalInfo.getStartDate()), baseServReqClaimInfo.getTotalDays() - 1));
                }
            }
            postServReqAttributes.setHertzRentalEndDate_Ext(endDate);

            postServReqAttributes.setHertzRateType_Ext(new ServiceRequestPostComposite.CodeName());
            RateType rate = RateType.fromType(baseServReqRentalInfo.getRateClass());
            postServReqAttributes.getHertzRateType_Ext().setCode(rate.getCode());
            postServReqAttributes.getHertzRateType_Ext().setName(rate.getDescription());
            postServReqAttributes.setHertzRentalCompany_Ext(new ServiceRequestPostComposite.CodeName());
            postServReqAttributes.getHertzRentalCompany_Ext().setCode(RentalCompany.HERTZ.getCode());
            postServReqAttributes.getHertzRentalCompany_Ext().setName(RentalCompany.HERTZ.getDescription());
            postServReqAttributes.setHertzTransactionDate_Ext(AppUtils.getDateISO8601(baseHertzRequest.getTransactionDate()));
            RentalRole rentalRole = RentalRole.fromType(baseServReqClaimInfo.getType());
            postServReqAttributes.setHertzRentalRole_Ext(new ServiceRequestPostComposite.CodeName());
            postServReqAttributes.getHertzRentalRole_Ext().setCode(rentalRole.getCode());
            postServReqAttributes.getHertzRentalRole_Ext().setName(rentalRole.getName());

            postServReqAttributes.setHertzTotalDaysApproved_Ext(baseServReqClaimInfo.getTotalDays());

            postServReqAttributes.setHertzRequestType_Ext(false);
            postServReqAttributes.setHertzIncrementalDays_Ext(baseServReqClaimInfo.getIncrementalDays());
            postServReqAttributes.setHertzTransactionTSDID_Ext(baseServReqRentalInfo.getContractId());
            postServReqAttributes.setHertzTransactionContractID_Ext(baseServReqRentalInfo.getContractId());
            postServReqAttributes.setHertzTransactionGUID_Ext(baseHertzRequest.getTransactionGUID());

            /*Additional Charges*/
            var additionalCharges = baseHertzRequest.getClaimInfo().getAdditionalCharges();
            if( additionalCharges != null && additionalCharges.size() > 0){
                for (AdditionalCharges charge : additionalCharges) {
                    if (AdditionalChargeType.LOST_DAMAGE_WAIVER.getCode().equalsIgnoreCase(charge.getCode())) {
                        postServReqAttributes.setHertzLossDamageWaiver_Ext(true);
                    }
                    else if (AdditionalChargeType.WINTER_TIRES.getCode().equalsIgnoreCase(charge.getCode())) {
                        postServReqAttributes.setHertzWinterTires_Ext(true);
                    }
                }
            }
            else {
                postServReqAttributes.setHertzLossDamageWaiver_Ext(currentServiceRequestAttributes.isHertzLossDamageWaiver_Ext());
                postServReqAttributes.setHertzWinterTires_Ext(currentServiceRequestAttributes.isHertzWinterTires_Ext());
            }

            HistoryComposite history = new HistoryComposite();
            history.setData(new HistoryComposite.Data());
            history.getData().setAttributes(new HistoryComposite.Data.Attributes());
            history.getData().getAttributes().setClaim(new HistoryComposite.Data.Attributes.Claim());
            history.getData().getAttributes().getClaim().setId(claim.getData().getAttributes().getId());
            history.getData().getAttributes().getClaim().setType(EntityEventType.CLAIM.getType());
            history.getData().getAttributes().setServiceRequest(new HistoryComposite.Data.Attributes.ServiceRequest());
            history.getData().getAttributes().setUser(new HistoryComposite.Data.Attributes.User());
            history.getData().getAttributes().getUser().setId(claim.getData().getAttributes().getAssignedUser().getId());
            history.getData().getAttributes().getUser().setType(EntityEventType.USER.getType());
            history.getData().getAttributes().setType(new HistoryComposite.Data.Attributes.Type());
            history.getData().getAttributes().getType().setCode(HistoryType.HERTZ_RENTAL_CLOSE_ACC.getCode());
            history.getData().getAttributes().getType().setName(HistoryType.HERTZ_RENTAL_CLOSE_ACC.getName());
            history.getData().getAttributes().setDescription(HistoryType.HERTZ_RENTAL_OPEN_ACC.getDescription()
                    .replace("$1", (baseServReqClaimInfo.getClaimNoteRentalInstructions() != null ? baseServReqClaimInfo.getClaimNoteRentalInstructions() : ""))
                    .replace("$2", HistoryType.HERTZ_RENTAL_CLOSE_ACC.getName()));
            history.getData().getAttributes().setRequest(reservationHelper.parseRequestAsJSON(baseHertzRequest));

            String stickySessionToken = UUID.randomUUID().toString();
            var abstractRequest = compositeRentalCloseHelper.buildCompositeRequest(claim,
                    currentServiceRequest,
                    serviceRequestPost,
                    history);
            compositeClient.executeCompositeRequest(exchange, stickySessionToken, abstractRequest);
            Thread.sleep(10000);
            reservationHelper.markAsCompleted(stickySessionToken,claim,currentServiceRequest);
            response = new BaseHertzResponse();
            response.setMessage(HistoryType.HERTZ_RENTAL_CLOSE_ACC.getName() + " processed");
            response.setMsgType("success");
            response.setTransactionGuid(baseHertzRequest.getTransactionGUID());
            response.setTransactionContractId(baseHertzRequest.getTransactionContractId());
            response.setTransactionType(baseHertzRequest.getTransactionType());
            response.setMsgGuid(baseHertzRequest.getTransactionGUID());
            response.setTransactionDate(baseHertzRequest.getTransactionDate());
            response.setMsgDate(Converter.parseDateToJSON(new Date()));


        } catch (Exception e) {
            log.error("Error", new Object() {
            }.getClass().getEnclosingMethod().getName(), e);
            throw e;
        }
        return response;

    }
}