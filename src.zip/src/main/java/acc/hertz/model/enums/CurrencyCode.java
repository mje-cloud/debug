package acc.hertz.model.enums;

public enum CurrencyCode {
    USD("usd","USD Dollar"),
    CAD("cad","Canada Dollar");
    private final String code;
    public String getName() {
        return name;
    }

    private final String name;

    CurrencyCode(String code, String name) {
        this.code = code;
        this.name=name;
    }

    public String getCode() {
        return code;
    }

    public static CurrencyCode fromType(String type) {
        for (CurrencyCode charge : values()) {
            if (charge.getCode().equals(type)) {
                return charge;
            }
        }
        throw new IllegalArgumentException("Unknown : " + type);
    }
}
