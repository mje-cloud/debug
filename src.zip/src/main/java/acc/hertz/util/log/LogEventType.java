package acc.hertz.util.log;

public class LogEventType {
    public static final String INFO_EVENT = "LOG_INFO_EVENT";
    public static final String WARN_EVENT = "LOG_WARN_EVENT";
    public static final String ERROR_EVENT = "LOG_ERROR_EVENT";
}
