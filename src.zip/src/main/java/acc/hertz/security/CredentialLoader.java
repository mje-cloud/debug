package acc.hertz.security;

import acc.hertz.security.authorization.AuthorizationType;
import acc.hertz.security.authorization.IAuthorizer;
import org.apache.camel.Exchange;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.inject.Singleton;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

@Singleton
@Named
public class CredentialLoader implements  ICredential{
    private SecureKeyStore hertzSecure;
    private SecureKeyStore ccDetailedSecure;
    @Inject
    private IAuthorizer authToken;

    private CredentialLoader(){
    }

    private void reloadCredentialPlugin(Exchange exchange,AuthorizationType authorizationType) throws Exception {
        var tokens = new StringBuilder();
        switch (authorizationType) {
            case TSD_TOKEN_ACCESS:
                tokens.append(authToken.getTSDAuthToken());
                hertzSecure = new SecureKeyStore(tokens.toString());
                break;
            case CLOUD_DETAILED_ACCESS:
                tokens.append(authToken.getCCDetailedAuthToken(exchange));
                ccDetailedSecure = new SecureKeyStore(tokens.toString());
                break;
            default:
                throw new Exception("Invalid authorization type provided");
            }
    }


    private String getDetailedAuthorization() throws IOException, NoSuchAlgorithmException, InvalidKeyException, ClassNotFoundException {
        if (ccDetailedSecure != null) {
            String value = ccDetailedSecure.getObject();
            return String.valueOf(value);
        }
        return null;
    }

    private String getTSDAuthorization() throws IOException, NoSuchAlgorithmException, InvalidKeyException, ClassNotFoundException {
        if (hertzSecure != null) {
            String value = hertzSecure.getObject();
            return String.valueOf(value);
        }
        return null;
    }

    public String getCredential(Exchange exchange,final AuthorizationType authorizationType) throws Exception {
        reloadCredentialPlugin(exchange,authorizationType);
        switch (authorizationType){
            case TSD_TOKEN_ACCESS:
                return getTSDAuthorization();
            case CLOUD_DETAILED_ACCESS:
                return getDetailedAuthorization();
            default:
                throw new Exception("Invalid authorization type provided");
        }
    }
}
