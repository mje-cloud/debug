package acc.hertz.processors;

import acc.hertz.api.ProcessorConsumer;
import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestList;
import acc.hertz.model.enums.Filter;
import acc.hertz.model.enums.RestRelopType;
import acc.hertz.model.hertz.outbound.GenericQueueMessage;
import acc.hertz.model.hertz.shared.TransactionResponseHeader;
import acc.hertz.process.ReservationHelper;
import acc.hertz.util.AppProperty;
import acc.hertz.util.AppUtils;
import acc.hertz.util.GenericJSONTransformer;
import acc.hertz.util.TransformerFactory;
import gw.api.ig.GwUtilities;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

@Named
public class ReservationQueueProcessor implements Processor {
    @Inject
    private AppProperty appProperty;
    @Inject
    private ProcessorConsumer processorTSDConsumer;
    @Inject
    private ReservationHelper reservationHelper;
    @Override
    public void process(Exchange exchange) throws Exception {
        TransactionResponseHeader responseTSD=null;
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
        try{
            GenericJSONTransformer<GenericQueueMessage> parser = TransformerFactory.getTransformer(GenericQueueMessage.class);
            var body = exchange.getMessage().getBody(String.class);
            GenericQueueMessage queueMessage = parser.fromJson(body);
            ClaimData claim = reservationHelper.findClaimById(exchange, queueMessage.getClaimId());
            if (claim == null)
                throw new Exception("ReservationQueueProcessor - Event Claim Id Not Found");

            String filter = Filter.FILTER_KEYWORD.getCode() + RestRelopType.EQUALS.getCode() + Filter.HERTZ_SERVICE_REQUEST_RENTAL_EXT.getCode() + RestRelopType.EQ_OPERATOR.getCode() + AppUtils.getValidIdentifierToFilter( queueMessage.getServiceRequestId());
            ServiceRequestList.ServiceRequest serviceRequest = reservationHelper.findServiceRequestByFilter( queueMessage.getClaimId(), filter);
            if (serviceRequest == null || serviceRequest.getAttributes() == null)
                throw new Exception("ReservationQueueProcessor - Event ServiceRequest Id Not Found");

            responseTSD = processorTSDConsumer.processTSDTransaction(exchange,queueMessage.getAppEventName(), claim, serviceRequest);
        }catch(Exception e){
            log.error("Error ReservationQueueProcessor " + e.getMessage(), "process", e);
            throw e;
        }finally{
            log.info("Finished processing message queue for Rental TransactionContractId " +responseTSD.getTransactionContractId(), new Object() {
            }.getClass().getEnclosingMethod().getName());
        }
    }
}
