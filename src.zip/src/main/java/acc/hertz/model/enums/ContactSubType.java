package acc.hertz.model.enums;

public enum ContactSubType {
    AUTO_REPAIR_SHOP("AutoRepairShop"),
    COMPANY_VENDOR("CompanyVendor"),
    PERSON("Person");
    private final String type;

    ContactSubType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public static ContactSubType fromType(String type) {
        for (ContactSubType requestType : values()) {
            if (requestType.getType().equals(type)) {
                return requestType;
            }
        }
        throw new IllegalArgumentException("Unknown Type: " + type);
    }
}
