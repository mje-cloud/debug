package acc.hertz.security;

import acc.hertz.util.AppProperty;
import org.springframework.context.annotation.Profile;

import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named
@Profile("prod")
public class CloudServer implements IServerSelector{
    @Inject
    private AppProperty property;
    @Override
    public String getServer() {
        return property.getCurrentCloudAPIServer();
    }
}
