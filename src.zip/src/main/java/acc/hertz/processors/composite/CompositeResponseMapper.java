package acc.hertz.processors.composite;

import acc.hertz.model.cloudapi.composite.core.CompositeResponse;
import acc.hertz.util.TransformerFactory;
import com.fasterxml.jackson.databind.ObjectMapper;

public final class CompositeResponseMapper {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private CompositeResponseMapper() {
    }

    public static <T> T mapFirstResponse(String result, Class<T> targetClass) throws Exception {
        CompositeResponse compositeResponse =
                TransformerFactory.getTransformer(CompositeResponse.class).fromJson(result);

        CompositeResponse.Response firstResponse = compositeResponse.getResponses()
                .stream()
                .findFirst()
                .orElseThrow(() -> new RuntimeException("No Composite responses found"));

        return MAPPER.convertValue(firstResponse.getBody(), targetClass);
    }
}
