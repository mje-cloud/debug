package acc.hertz.api;

import acc.hertz.model.hertz.outbound.BaseHertzRequest;
import acc.hertz.model.hertz.outbound.BaseHertzResponse;
import org.apache.camel.Exchange;

public interface IAssignment {
    public BaseHertzResponse createWalkUpOpenProcess(BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception;
    public  BaseHertzResponse reactiveExtension( BaseHertzRequest baseHertzRequest, Exchange exchange)throws Exception;

    public  BaseHertzResponse rentalOpenStatusChange( BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception;

    public  BaseHertzResponse rentalCloseStatusChange( BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception;

    public  BaseHertzResponse rentalCancellationStatusChange( BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception;

    public  BaseHertzResponse createInvoice( BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception;

    public  BaseHertzResponse rentalStatusChange( BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception;
}
