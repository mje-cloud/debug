package acc.hertz.email;

import acc.hertz.model.cloudapi.claim.ClaimContact;
import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestList;
import acc.hertz.process.ReservationHelper;
import acc.hertz.util.AppProperty;
import acc.hertz.util.Converter;
import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.Properties;

@Named
public class EmailUtil {
	private final Logger log = LoggerFactory.getLogger(EmailUtil.class);
	@Inject
	private AppProperty property;
	@Inject
	private ReservationHelper reservationHelper;
	public void sendMail(ServiceRequestList.ServiceRequest serviceRequest, ClaimData claim, String reservationNum) throws Exception {
		log.info("Sending mail to the renter");
		// SMTP server properties
		Properties properties = new Properties();
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", "true");
		properties.put("mail.smtp.host", property.getSmtp());
		properties.put("mail.smtp.port", property.getSmtpPort());

		// Create session
		Session session = Session.getInstance(properties, new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication( property.getUserName(), property.getSenderPassword());
			}
		});

		try {
			ClaimContact insured = claim.getIncluded().getClaimContacts().stream().filter(e-> e.getAttributes().getId().equalsIgnoreCase(claim.getData().getAttributes().getInsured().getId())).findFirst().orElse(null);
			if(insured != null && insured.getAttributes().getEmailAddress1() != null) {

				final String recipientEmail = insured.getAttributes().getEmailAddress1();
				String rentalBeginDate = serviceRequest.getAttributes().getHertzRentalBeginDate_Ext();
				String rentalEndDate = serviceRequest.getAttributes().getHertzRentalEndDate_Ext();
				String serviceReqAddress = serviceRequest.getAttributes().getInstruction().getServiceAddress().getDisplayName();
				String claimNumber = claim.getData().getAttributes().getClaimNumber();
				String insuredName = claim.getData().getAttributes().getInsured().getDisplayName();

				// Create email message
				Message message = new MimeMessage(session);
				message.addHeader("Content-type", "text/HTML; charset=UTF-8");
				message.addHeader("format", "flowed");
				message.addHeader("Content-Transfer-Encoding", "8bit");
				message.setFrom(new InternetAddress(property.getSenderEmail()));
				message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
				message.setSubject("Reservation Request");
				String htmlText = ("Hello " + insuredName + "<br>" + "<br>" +
						"Claim Center inform you the creation of a Reservation related to your Claim No " + claimNumber + "<br>" +
						"The  Reservation No. " + reservationNum +
						" was generated from  " + Converter.dateFormatter(rentalBeginDate) +
						" to " + "<br>" + Converter.dateFormatter(rentalEndDate) + "<br>" +
						"Please go the to Rental Office located on " + serviceReqAddress + "<br>" + "<br>" + "Best regards");
				Multipart mp = new MimeMultipart();
				MimeBodyPart htmlPart = new MimeBodyPart();
				htmlPart.setContent(htmlText, "text/html");
				mp.addBodyPart(htmlPart);
				message.setContent(mp);

				// Send email
				Transport.send(message);
				log.info("Email sent successfully!");
			}else{
				log.info("Insured does not have eMail ID");
			}
		} catch (MessagingException e) {
			log.info("Exception occurred while sending the email");
	      throw e;
		}
	}
}