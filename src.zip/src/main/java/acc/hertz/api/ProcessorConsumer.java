package acc.hertz.api;

import acc.hertz.email.EmailUtil;
import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.history.History;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestList;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestPatch;
import acc.hertz.model.enums.*;
import acc.hertz.model.hertz.inbound.AssignmentRequest;
import acc.hertz.model.hertz.shared.TransactionResponseHeader;
import acc.hertz.process.ReservationHelper;
import org.apache.camel.Exchange;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.camel.Exchange;

import java.util.UUID;

@Named
public class ProcessorConsumer {
    private static final Logger log = LoggerFactory.getLogger(ProcessorConsumer.class);
    @Inject
    private IRest restWrapper;
    @Inject
    private PayloadMapper payloadMapper;
    @Inject
    private ReservationHelper reservationHelper;
    @Inject
    private EmailUtil hertzEmail;

    public TransactionResponseHeader processTSDTransaction(Exchange exchange, final ServiceRequestEventType eventType, final ClaimData claim, final ServiceRequestList.ServiceRequest serviceRequest) throws Exception {
        TransactionResponseHeader transactionResponseHeader;
        AssignmentRequest request = null;
        try {
            switch (eventType) {
                case HERTZ_SERVICE_REQUEST_FNOL_ADDED:
                case HERTZ_SERVICE_REQUEST_ADDED:
                    request = payloadMapper.createNewAssignmentPayload(exchange, claim, serviceRequest);
                    log.info("Hertz Create Assignment Payload is " + request.toString());
                    transactionResponseHeader = restWrapper.createNewReservation(request);
                    if (transactionResponseHeader != null) {
                        ServiceRequestPatch serviceRequestPatch = new ServiceRequestPatch();
                        serviceRequestPatch.setData(new ServiceRequestPatch.Data());
                        serviceRequestPatch.getData().setAttributes(new ServiceRequestPatch.Data.Attributes());
                        serviceRequestPatch.getData().getAttributes().setHertzRequestType_Ext(false);
                        serviceRequestPatch.getData().getAttributes().setHertzTransactionContractID_Ext(transactionResponseHeader.getTransactionContractId());
                        serviceRequestPatch.getData().getAttributes().setHertzTransactionGUID_Ext(transactionResponseHeader.getTransactionGuid());
                        serviceRequestPatch.getData().getAttributes().setHertzTransactionTSDID_Ext(transactionResponseHeader.getTransactionTsdId());
                        serviceRequestPatch.getData().getAttributes().setHertzFinalDay_Ext(serviceRequest.getAttributes().getHertzRentalEndDate_Ext());
                        serviceRequestPatch.getData().getAttributes().setHertzContractStatus_Ext(new ServiceRequestPatch.CodeName());
                        serviceRequestPatch.getData().getAttributes().getHertzContractStatus_Ext().setCode(ContractStatus.RESERVATION_CONFIRMED.getCode());
                        serviceRequestPatch.getData().getAttributes().getHertzContractStatus_Ext().setName(ContractStatus.RESERVATION_CONFIRMED.getName());
                        serviceRequestPatch.getData().getAttributes().setHertzRentalEndDate_Ext(request.getRentalInfo().getEndDate());
                        serviceRequestPatch.getData().getAttributes().setHertzTotalDaysApproved_Ext(request.getClaimInfo().getTotalDays());
                        var stickySessionToken = UUID.randomUUID().toString();
                        if (reservationHelper.updateRental(stickySessionToken, claim, serviceRequest, serviceRequestPatch)) {
                            if (serviceRequest.getAttributes().getProgress().getCode().equalsIgnoreCase(ServiceRequestProgress.DRAFT.getCode())) {
                                //Move to requested state
                                reservationHelper.markAsSubmitted(stickySessionToken, claim, serviceRequest.getAttributes().getId());
                            }
                            if (serviceRequest.getAttributes().isHertzSendEmail_Ext()) {
                                hertzEmail.sendMail(serviceRequest, claim, transactionResponseHeader.getTransactionContractId());
                            }
                        }
                        createHistoryForSuccessfulSubmission(stickySessionToken, exchange, claim, eventType, serviceRequest);
                    }

                    break;
                case HERTZ_SERVICE_REQUEST_APPROVED_OR_REJECTED:
                    request = payloadMapper.createEditReservationPayload(exchange, claim, serviceRequest, false);
                    transactionResponseHeader = restWrapper.editReservation(request);
                    if (transactionResponseHeader != null) {
                        ServiceRequestPatch serviceRequestPatch = new ServiceRequestPatch();
                        serviceRequestPatch.setData(new ServiceRequestPatch.Data());
                        serviceRequestPatch.getData().setAttributes(new ServiceRequestPatch.Data.Attributes());
                        serviceRequestPatch.getData().getAttributes().setHertzRequestType_Ext(false);
                        serviceRequestPatch.getData().getAttributes().setHertzTransactionTSDID_Ext(serviceRequest.getAttributes().getHertzTransactionTSDID_Ext());
                        serviceRequestPatch.getData().getAttributes().setHertzTransactionContractID_Ext(transactionResponseHeader.getTransactionContractId());
                        serviceRequestPatch.getData().getAttributes().setHertzTransactionGUID_Ext(transactionResponseHeader.getTransactionGuid());
                        serviceRequestPatch.getData().getAttributes().setHertzContractStatus_Ext(new ServiceRequestPatch.CodeName());
                        ContractStatus currentContract = ContractStatus.fromCode(serviceRequest.getAttributes().getHertzContractStatus_Ext().getCode());
                        serviceRequestPatch.getData().getAttributes().getHertzContractStatus_Ext().setCode(currentContract.getCode());
                        serviceRequestPatch.getData().getAttributes().getHertzContractStatus_Ext().setName(currentContract.getName());
                        serviceRequestPatch.getData().getAttributes().setHertzIncrementalDays_Ext(0);
                        serviceRequestPatch.getData().getAttributes().setHertzRentalEndDate_Ext(request.getRentalInfo().getEndDate());
                        serviceRequestPatch.getData().getAttributes().setHertzTotalDaysApproved_Ext(request.getClaimInfo().getTotalDays());
                        var stickySessionToken = UUID.randomUUID().toString();
                        reservationHelper.updateRental(stickySessionToken, claim, serviceRequest, serviceRequestPatch);
                        createHistoryForSuccessfulSubmission(stickySessionToken, exchange, claim, eventType, serviceRequest);
                    }
                    break;
                case HERTZ_SERVICE_REQUEST_FINAL_DATE_CHANGED:
                    request = payloadMapper.createEditReservationPayload(exchange, claim, serviceRequest, true);
                    transactionResponseHeader = restWrapper.editReservation(request);
                    if (transactionResponseHeader != null) {
                        ServiceRequestPatch serviceRequestPatch = new ServiceRequestPatch();
                        serviceRequestPatch.setData(new ServiceRequestPatch.Data());
                        serviceRequestPatch.getData().setAttributes(new ServiceRequestPatch.Data.Attributes());
                        serviceRequestPatch.getData().getAttributes().setHertzRequestType_Ext(false);
                        serviceRequestPatch.getData().getAttributes().setHertzTransactionTSDID_Ext(serviceRequest.getAttributes().getHertzTransactionTSDID_Ext());
                        serviceRequestPatch.getData().getAttributes().setHertzTransactionContractID_Ext(transactionResponseHeader.getTransactionContractId());
                        serviceRequestPatch.getData().getAttributes().setHertzTransactionGUID_Ext(transactionResponseHeader.getTransactionGuid());
                        serviceRequestPatch.getData().getAttributes().setHertzContractStatus_Ext(new ServiceRequestPatch.CodeName());
                        ContractStatus currentContract = ContractStatus.fromCode(serviceRequest.getAttributes().getHertzContractStatus_Ext().getCode());
                        serviceRequestPatch.getData().getAttributes().getHertzContractStatus_Ext().setCode(currentContract.getCode());
                        serviceRequestPatch.getData().getAttributes().getHertzContractStatus_Ext().setName(currentContract.getName());
                        serviceRequestPatch.getData().getAttributes().setHertzRentalEndDate_Ext(request.getRentalInfo().getEndDate());
                        serviceRequestPatch.getData().getAttributes().setHertzTotalDaysApproved_Ext(request.getClaimInfo().getTotalDays());
                        serviceRequestPatch.getData().getAttributes().setHertzFinalDay_Ext(request.getRentalInfo().getEndDate());
                        var stickySessionToken = UUID.randomUUID().toString();
                        reservationHelper.updateRental(stickySessionToken, claim, serviceRequest, serviceRequestPatch);
                        createHistoryForSuccessfulSubmission(stickySessionToken, exchange, claim, eventType, serviceRequest);
                    }
                    break;
                case HERTZ_SERVICE_REQUEST_CHANGED:
                    request = payloadMapper.createEditReservationPayload(exchange, claim, serviceRequest, false);
                    transactionResponseHeader = restWrapper.editReservation(request);
                    if (transactionResponseHeader != null) {
                        ServiceRequestPatch serviceRequestPatch = new ServiceRequestPatch();
                        serviceRequestPatch.setData(new ServiceRequestPatch.Data());
                        serviceRequestPatch.getData().setAttributes(new ServiceRequestPatch.Data.Attributes());
                        serviceRequestPatch.getData().getAttributes().setHertzRequestType_Ext(false);
                        serviceRequestPatch.getData().getAttributes().setHertzTransactionTSDID_Ext(serviceRequest.getAttributes().getHertzTransactionTSDID_Ext());
                        serviceRequestPatch.getData().getAttributes().setHertzTransactionContractID_Ext(transactionResponseHeader.getTransactionContractId());
                        serviceRequestPatch.getData().getAttributes().setHertzTransactionGUID_Ext(transactionResponseHeader.getTransactionGuid());
                        serviceRequestPatch.getData().getAttributes().setHertzContractStatus_Ext(new ServiceRequestPatch.CodeName());
                        serviceRequestPatch.getData().getAttributes().getHertzContractStatus_Ext().setCode(serviceRequest.getAttributes().getHertzContractStatus_Ext().getCode());
                        ContractStatus currentContract = ContractStatus.fromCode(serviceRequest.getAttributes().getHertzContractStatus_Ext().getCode());
                        serviceRequestPatch.getData().getAttributes().getHertzContractStatus_Ext().setCode(currentContract.getCode());
                        serviceRequestPatch.getData().getAttributes().getHertzContractStatus_Ext().setName(currentContract.getName());
                        serviceRequestPatch.getData().getAttributes().setHertzIncrementalDays_Ext(0);
                        serviceRequestPatch.getData().getAttributes().setHertzRentalEndDate_Ext(request.getRentalInfo().getEndDate());
                        serviceRequestPatch.getData().getAttributes().setHertzTotalDaysApproved_Ext(request.getClaimInfo().getTotalDays());
                        var stickySessionToken = UUID.randomUUID().toString();
                        reservationHelper.updateRental(stickySessionToken, claim, serviceRequest, serviceRequestPatch);
                        createHistoryForSuccessfulSubmission(stickySessionToken, exchange, claim, eventType, serviceRequest);
                    }
                    break;
                case HERTZ_SERVICE_REQUEST_CANCELED:
                    request = payloadMapper.createCancelReservationPayload(exchange, claim, serviceRequest);
                    log.info("Inside the HERTZ_SERVICE_REQUEST_CANCELED Block " + request + "~" + request.toString());
                    transactionResponseHeader = restWrapper.editReservation(request);
                    log.info("Inside the HERTZ_SERVICE_REQUEST_CANCELED Block transactionResponseHeader" + transactionResponseHeader);
                    if (transactionResponseHeader != null) {
                        log.info("Inside the if block HERTZ_SERVICE_REQUEST_CANCELED Block transactionResponseHeader" + transactionResponseHeader.getCode());
                        ServiceRequestPatch serviceRequestPatch = new ServiceRequestPatch();
                        serviceRequestPatch.setData(new ServiceRequestPatch.Data());
                        serviceRequestPatch.getData().setAttributes(new ServiceRequestPatch.Data.Attributes());
                        serviceRequestPatch.getData().getAttributes().setHertzRequestType_Ext(false);
                        serviceRequestPatch.getData().getAttributes().setHertzTransactionTSDID_Ext(serviceRequest.getAttributes().getHertzTransactionTSDID_Ext());
                        serviceRequestPatch.getData().getAttributes().setHertzTransactionContractID_Ext(transactionResponseHeader.getTransactionContractId());
                        serviceRequestPatch.getData().getAttributes().setHertzTransactionGUID_Ext(transactionResponseHeader.getTransactionGuid());
                        serviceRequestPatch.getData().getAttributes().setHertzFinalDay_Ext(serviceRequest.getAttributes().getHertzRentalEndDate_Ext());
                        serviceRequestPatch.getData().getAttributes().setHertzContractStatus_Ext(new ServiceRequestPatch.CodeName());
                        serviceRequestPatch.getData().getAttributes().getHertzContractStatus_Ext().setCode(ContractStatus.RENTAL_CANCEL.getCode());
                        serviceRequestPatch.getData().getAttributes().getHertzContractStatus_Ext().setName(ContractStatus.RENTAL_CANCEL.getName());
                        serviceRequestPatch.getData().getAttributes().setHertzTotalDaysApproved_Ext(0);
                        var stickySessionToken = UUID.randomUUID().toString();
                        reservationHelper.updateRental(stickySessionToken, claim, serviceRequest, serviceRequestPatch);
                        createHistoryForSuccessfulSubmission(stickySessionToken, exchange, claim, eventType, serviceRequest);
                    }
                    break;
                default:
                    transactionResponseHeader = null;
            }
        } catch (Exception e) {
            History newHistory = new History();
            newHistory.setData(new History.Data());
            newHistory.getData().setAttributes(new History.Data.Attributes());
            newHistory.getData().getAttributes().setClaim(new History.Data.Attributes.Claim());
            newHistory.getData().getAttributes().getClaim().setId(claim.getData().getAttributes().getId());
            newHistory.getData().getAttributes().getClaim().setType(EntityEventType.CLAIM.getType());
            newHistory.getData().getAttributes().setServiceRequest(new History.Data.Attributes.ServiceRequest());
            newHistory.getData().getAttributes().getServiceRequest().setId(serviceRequest.getAttributes().getId());
            newHistory.getData().getAttributes().getServiceRequest().setType(EntityEventType.SERVICE_REQUEST.getType());
            newHistory.getData().getAttributes().setUser(new History.Data.Attributes.User());
            newHistory.getData().getAttributes().getUser().setId(claim.getData().getAttributes().getAssignedUser().getId());
            newHistory.getData().getAttributes().getUser().setType(EntityEventType.USER.getType());
            newHistory.getData().getAttributes().setType(new History.Data.Attributes.Type());
            newHistory.getData().getAttributes().getType().setCode(HistoryType.HERTZ_RENTAL_ERROR_ACC.getCode());
            newHistory.getData().getAttributes().getType().setName(HistoryType.HERTZ_RENTAL_ERROR_ACC.getName());
            newHistory.getData().getAttributes().setDescription(HistoryType.HERTZ_RENTAL_ERROR_ACC.getDescription().replace("$1", "Operation " + eventType + " Error " + e.getMessage()));
            newHistory.getData().getAttributes().setRequest("x");
            newHistory.getData().getAttributes().setEventName(eventType.getType());
            var stickySessionToken = UUID.randomUUID().toString();
            reservationHelper.createHistoryRecord(exchange, stickySessionToken, newHistory);
            throw new Exception("Error processing " + eventType.getType() + " event " + e.getMessage(), e);
        }
/*
        History newHistory = new History();
        newHistory.setData(new History.Data());
        newHistory.getData().setAttributes(new History.Data.Attributes());
        newHistory.getData().getAttributes().setClaim(new History.Data.Attributes.Claim());
        newHistory.getData().getAttributes().getClaim().setId(claim.getData().getAttributes().getId());
        newHistory.getData().getAttributes().getClaim().setType(EntityEventType.CLAIM.getType());
        newHistory.getData().getAttributes().setServiceRequest(new History.Data.Attributes.ServiceRequest());
        newHistory.getData().getAttributes().getServiceRequest().setId(serviceRequest.getAttributes().getId());
        newHistory.getData().getAttributes().getServiceRequest().setType(EntityEventType.SERVICE_REQUEST.getType());
        newHistory.getData().getAttributes().setUser(new History.Data.Attributes.User());
        newHistory.getData().getAttributes().getUser().setId(claim.getData().getAttributes().getAssignedUser().getId());
        newHistory.getData().getAttributes().getUser().setType(EntityEventType.USER.getType());
        newHistory.getData().getAttributes().setType(new History.Data.Attributes.Type());
        newHistory.getData().getAttributes().getType().setCode(HistoryType.HERTZ_RENTAL_SUCCESS_EXT.getCode());
        newHistory.getData().getAttributes().getType().setName(HistoryType.HERTZ_RENTAL_SUCCESS_EXT.getName());
        newHistory.getData().getAttributes().setDescription(HistoryType.HERTZ_RENTAL_SUCCESS_EXT.getDescription().replace("$1","Operation " + eventType + " Success "));
        newHistory.getData().getAttributes().setRequest("x");
        newHistory.getData().getAttributes().setEventName(eventType.getType());
        reservationHelper.createHistoryRecord(exchange, newHistory);
        //throw new Exception("Error processing " + eventType.getType() + " event " + e.getMessage(), e);*/
        return transactionResponseHeader;
    }

    private void createHistoryForSuccessfulSubmission(final String stickySessionToken, Exchange exchange, ClaimData claim, final ServiceRequestEventType eventType, final ServiceRequestList.ServiceRequest serviceRequest) throws Exception {
        try {
            log.info("Inside the createHistoryForSuccessfulSubmission");
            History newHistory = new History();
            newHistory.setData(new History.Data());
            newHistory.getData().setAttributes(new History.Data.Attributes());
            newHistory.getData().getAttributes().setClaim(new History.Data.Attributes.Claim());
            newHistory.getData().getAttributes().getClaim().setId(claim.getData().getAttributes().getId());
            newHistory.getData().getAttributes().getClaim().setType(EntityEventType.CLAIM.getType());
            newHistory.getData().getAttributes().setServiceRequest(new History.Data.Attributes.ServiceRequest());
            newHistory.getData().getAttributes().getServiceRequest().setId(serviceRequest.getAttributes().getId());
            newHistory.getData().getAttributes().getServiceRequest().setType(EntityEventType.SERVICE_REQUEST.getType());
            newHistory.getData().getAttributes().setUser(new History.Data.Attributes.User());
            newHistory.getData().getAttributes().getUser().setId(claim.getData().getAttributes().getAssignedUser().getId());
            newHistory.getData().getAttributes().getUser().setType(EntityEventType.USER.getType());
            newHistory.getData().getAttributes().setType(new History.Data.Attributes.Type());
            newHistory.getData().getAttributes().getType().setCode(HistoryType.HERTZ_RENTAL_SUCCESS_EXT.getCode());
            newHistory.getData().getAttributes().getType().setName(HistoryType.HERTZ_RENTAL_SUCCESS_EXT.getName());
            newHistory.getData().getAttributes().setDescription(HistoryType.HERTZ_RENTAL_SUCCESS_EXT.getDescription().replace("$1", "Operation " + eventType + " Success "));
            newHistory.getData().getAttributes().setRequest("x");
            newHistory.getData().getAttributes().setEventName(eventType.getType());
            reservationHelper.createHistoryRecord(exchange, stickySessionToken, newHistory);

        } catch (Exception exception) {
            throw new Exception("Error while creating entry for createHistoryForSuccessfulSubmission " + eventType.getType() + " event " + exception.getMessage(), exception);
        }

    }

}