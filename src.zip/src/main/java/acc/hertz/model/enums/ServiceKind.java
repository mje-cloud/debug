package acc.hertz.model.enums;

public enum ServiceKind {
    SERVICE_ONLY("serviceonly","Perform Service");

    private final String code;

    public String getName() {
        return name;
    }

    private final String name;

    ServiceKind(String code, String name) {
        this.code = code;
        this.name=name;
    }

    public String getCode() {
        return code;
    }

    public static ServiceKind fromType(String type) {
        for (ServiceKind kind : values()) {
            if (kind.getCode().equals(type)) {
                return kind;
            }
        }
        throw new IllegalArgumentException("Unknown Type: " + type);
    }
}
