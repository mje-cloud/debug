package acc.hertz.model.enums;

public enum InvoiceStatement {
    SERVICE_REQUEST_INVOICE("ServiceRequestInvoice","ServiceRequestInvoice"),
    SERVICE_REQUEST_QUOTE("ServiceRequestQuote","ServiceRequestQuote"),
    SERVICE_REQUEST_STATEMENT("ServiceRequestStatement","ServiceRequestStatement");
    private final String code;

    public String getName() {
        return name;
    }

    private final String name;

    InvoiceStatement(String code, String name) {
        this.code = code;
        this.name=name;
    }

    public String getCode() {
        return code;
    }

    public static InvoiceStatement fromType(String type) {
        for (InvoiceStatement charge : values()) {
            if (charge.getCode().equals(type)) {
                return charge;
            }
        }
        throw new IllegalArgumentException("Unknown : " + type);
    }
}
