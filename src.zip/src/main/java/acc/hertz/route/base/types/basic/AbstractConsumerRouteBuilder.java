package acc.hertz.route.base.types.basic;


import acc.hertz.route.base.AbstractRouteBuilder;

import jakarta.inject.Named;

@Named
public abstract class AbstractConsumerRouteBuilder extends AbstractRouteBuilder {

    public AbstractConsumerRouteBuilder(){
       super();
    }

    protected abstract void setupRoute();

    public void configure() {
        setupRoute();
    }

}
