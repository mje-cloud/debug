package acc.hertz.processors.composite.helper.payload;

import acc.hertz.model.cloudapi.composite.core.BaseBody;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class ServiceRequestInvoiceComposite extends BaseBody {
    @JsonProperty("data")
    public Data data;

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Data {
        @JsonProperty("attributes")
        public Attributes attributes;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Attributes {

        @JsonProperty("approvedBy")
        public ApprovedBy approvedBy;

        @JsonProperty("description")
        public String description;

        @JsonProperty("lineItems")
        public List<LineItem> lineItems;

        @JsonProperty("paymentDate")
        public String paymentDate;

        @JsonProperty("paymentDateTime")
        public String paymentDateTime;

        @JsonProperty("referenceNumber")
        public String referenceNumber;

        @JsonProperty("source")
        public CodeName source;

        @JsonProperty("status")
        public CodeName status;

        @JsonProperty("subtype")
        public CodeName subtype;

        @JsonProperty("total")
        public Amount total;

        @JsonProperty("id")
        public String id;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class ApprovedBy {
        @JsonProperty("id")
        public String id;

        @JsonProperty("type")
        public String type;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class LineItem {
        @JsonProperty("amount")
        public Amount amount;

        @JsonProperty("category")
        public CodeName category;

        @JsonProperty("description")
        public String description;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Amount {
        @JsonProperty("amount")
        public String amount;

        @JsonProperty("currency")
        public String currency;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class CodeName {
        @JsonProperty("code")
        public String code;

        @JsonProperty("name")
        public String name;
    }
}
