package acc.hertz.model.response;


import acc.hertz.model.enums.MimeType;
import acc.hertz.model.error.ErrorResponse;
import acc.hertz.util.AppUtils;
import acc.hertz.util.Converter;
import acc.hertz.util.GenericJSONTransformer;
import acc.hertz.util.TransformerFactory;
import jakarta.inject.Named;
import org.apache.camel.Exchange;

@Named
public class ResponseHandler implements IResponseHandler {
    private final GenericJSONTransformer<ErrorResponse> response = TransformerFactory.getTransformer(ErrorResponse.class);

    @Override
    public ErrorResponse handleResponse(Exchange exchange, final String displayKey, final int httpCode) throws Exception {
        ErrorResponse errorResponse = handleResponse(exchange, displayKey, null, httpCode);
        return errorResponse;
    }

    @Override
    public ErrorResponse handleResponse(Exchange exchange, final String displayKey, String[] values, final int httpCode) throws Exception {
        ErrorResponse errorResponse = new ErrorResponse();
        try {
            errorResponse.setStatus(String.valueOf(httpCode));
            if (values != null) {
                String message = Converter.replaceValues(exchange.getContext().resolvePropertyPlaceholders(displayKey), values);
                errorResponse.setMessage(message);
            } else
                errorResponse.setMessage(exchange.getContext().resolvePropertyPlaceholders(displayKey));

            exchange.getMessage().setHeader(AppUtils.API_CONTENT_TYPE, MimeType.JSON.getCode());
            exchange.getMessage().setHeader(Exchange.HTTP_RESPONSE_CODE, errorResponse.getStatus());
            exchange.getMessage().setBody(AppUtils.sanitize(response.toJson(errorResponse)));
        } catch (Exception e) {
            throw e;
        }
        return errorResponse;
    }
}
