package acc.hertz.model.cloudapi.composite.core;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class BaseRequest {
    @JsonProperty("body")
    private BaseBody body;
    @JsonProperty("includeResponse")
    private boolean includeResponse;
    @JsonProperty("method")
    private String method;
    @JsonProperty("uri")
    private String uri;
    @JsonProperty("vars")
    private List<RequestVars> vars;
}