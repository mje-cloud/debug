package acc.hertz.model.enums;

public enum TypeListType {
    COUNTRY("Country"),
    State("State");

    private final String type;

    TypeListType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public static TypeListType fromType(String type) {
        for (TypeListType requestType : values()) {
            if (requestType.getType().equals(type)) {
                return requestType;
            }
        }
        throw new IllegalArgumentException("Unknown Type: " + type);
    }
}
