package acc.hertz.model.cloudapi.composite.core;

public enum RequestVarType {
    SERVICE_REQUEST_ID("$.data.attributes.id", "serviceRequestId");

    private final String path;
    private final String name;

    RequestVarType(String path, String name) {
        this.path = path;
        this.name = name;
    }

    public String getPath() {
        return path;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return String.valueOf(path);
    }

    public String getBuildVarTypeParameter() {
        return "${" + this.name + "}";
    }
}
