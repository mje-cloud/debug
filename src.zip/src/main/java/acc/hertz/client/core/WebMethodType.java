package acc.hertz.client.core;

public enum WebMethodType {

    POST("POST"),
    GET("GET"),
    PATCH("PATCH"),
    PUT("PUT"),
    DELETE("DELETE");
    private final String code;

    WebMethodType(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
    @Override
    public String toString() {
        return String.valueOf(code);
    }


}
