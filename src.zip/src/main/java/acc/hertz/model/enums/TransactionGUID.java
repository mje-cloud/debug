package acc.hertz.model.enums;

public enum TransactionGUID {
    GW_INBOUND_LOCATION_SEARCH_POST("gwinboundlocationsearchpost", "Get Location Data: LocationSearch", "GWInboundLocationSearchPOST"),
    GW_INBOUND_ASSIGNMENT_POST("gwinboundassignmentpost", "Assignment: NewAssignment", "GWInboundAssignment POST"),
    GW_INBOUND_PUT_AUTH_UPDATE_04A("gwinboundputauthupdate04a", "Proactive Extension-Edit Authorization", "GWInboundPUTAuthUpdate04A"),
    GW_INBOUND_PUT_CANCEL_01A("gwinboundputcancel01a", "Cancel Reservation", "GWInboundPUTCancel01A");

    private final String code;
    private final String description;
    private final String name;

    TransactionGUID(String code, String description, String name) {
        this.code = code;
        this.description = description;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public String getName() {
        return name;
    }

    public static TransactionGUID fromCode(String code) {
        for (TransactionGUID type : values()) {
            if (type.code.equalsIgnoreCase(code)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown code: " + code);
    }
}
