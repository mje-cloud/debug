package acc.hertz.model.cloudapi.claim;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClaimData {
    @JsonProperty("count")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private int count;
    @JsonProperty("data")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Data data;

    @JsonProperty("included")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Included included;

    public int getCount() {
        return count;
    }

    public void setCount(int  data) {
        this.count = data;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data  data) {
        this.data = data;
    }

    public Included getIncluded() {
        return included;
    }

    public void setIncluded(Included included) {
        this.included = included;
    }
}


