package acc.hertz.client.composite;


import acc.hertz.model.cloudapi.composite.core.AbstractCompositeRequest;
import org.apache.camel.Exchange;

public interface ICompositeClient {
    String executeCompositeRequest(Exchange exchange, String gwreSession, AbstractCompositeRequest request) throws Exception;
}
