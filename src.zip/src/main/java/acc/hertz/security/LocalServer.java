package acc.hertz.security;

import org.springframework.context.annotation.Profile;

import jakarta.inject.Named;

@Named
@Profile("dev")
public class LocalServer implements IServerSelector{
    @Override
    public String getServer() {
        return "http://localhost:8080/cc";
    }
}
