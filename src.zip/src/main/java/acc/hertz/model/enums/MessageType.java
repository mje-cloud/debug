package acc.hertz.model.enums;

public enum MessageType {

        SUCCESS("success", "Marks the success of the request"),
        CANCELLED("cancelled", "Marks the cancellation of the request"),
        CONFIRMED("confirmed", "Confirms the request"),
        UPDATED("updated", "Confirms that the item has been updated"),
        REJECTED("rejected", "Marks the rejection of the request");

        private final String code;
        private final String description;

    MessageType(String code, String description) {
            this.code = code;
            this.description = description;
        }

        public String getCode() {
            return code;
        }

        public String getDescription() {
            return description;
        }
}
