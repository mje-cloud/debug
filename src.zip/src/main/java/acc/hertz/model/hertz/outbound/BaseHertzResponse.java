package acc.hertz.model.hertz.outbound;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BaseHertzResponse {

    @JsonProperty("MSGGUID")
    private String msgGuid;

    @JsonProperty("MSGDate")
    private String msgDate;

    @JsonProperty("TransactionDate ")
    private String transactionDate;

    @JsonProperty("TransactionType")
    private String transactionType;

    @JsonProperty("MSGType")
    private String msgType;

    @JsonProperty("TransactionGUID")
    private String transactionGuid;

    @JsonProperty("TransactionContractID")
    private String transactionContractId;

    @JsonProperty("TransactionTSDId")
    private String transactionTsdId;

    @JsonProperty("Code")
    private Integer code;

    @JsonProperty("MessageCode")
    private String messageCode;

    @JsonProperty("Message")
    private String message;

    // Getters and setters
    public String getMsgGuid() {
        return msgGuid;
    }

    public void setMsgGuid(String msgGuid) {
        this.msgGuid = msgGuid;
    }

    public String getMsgDate() {
        return msgDate;
    }

    public void setMsgDate(String msgDate) {
        this.msgDate = msgDate;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getMsgType() {
        return msgType;
    }

    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    public String getTransactionGuid() {
        return transactionGuid;
    }

    public void setTransactionGuid(String transactionGuid) {
        this.transactionGuid = transactionGuid;
    }

    public String getTransactionContractId() {
        return transactionContractId;
    }

    public void setTransactionContractId(String transactionContractId) {
        this.transactionContractId = transactionContractId;
    }

    public String getTransactionTsdId() {
        return transactionTsdId;
    }

    public void setTransactionTsdId(String transactionTsdId) {
        this.transactionTsdId = transactionTsdId;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessageCode() {
        return messageCode;
    }

    public void setMessageCode(String messageCode) {
        this.messageCode = messageCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
