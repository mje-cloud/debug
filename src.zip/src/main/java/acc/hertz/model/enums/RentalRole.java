package acc.hertz.model.enums;



/**
 * Enum to represent Hertz Rental Roles for integration.
 */
public enum RentalRole {
    INSURED("insured", "Insured","I"),
    CLAIMANT("claimant", "Claimant","C");

    private final String code;

    private final String name;
    private final String tsdCode;

    RentalRole(String code,String name, String tsdCode) {
        this.code = code;
        this.name=name;
        this.tsdCode = tsdCode;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getTSDCode() {
        return tsdCode;
    }

    public static RentalRole fromType(String type) {
        for (RentalRole rentalRole : values()) {
            if (rentalRole.getTSDCode().equals(type)) {
                return rentalRole;
            }
        }
        throw new IllegalArgumentException("Unknown rentalRole: " + type);
    }
}

