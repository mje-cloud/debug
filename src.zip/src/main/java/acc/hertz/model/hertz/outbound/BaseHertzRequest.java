package acc.hertz.model.hertz.outbound;

import acc.hertz.model.hertz.shared.*;
import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BaseHertzRequest {

    @JsonProperty("MSGGUID")
    private String msgGuid;

    @JsonProperty("MSGDate")
    private String msgDate;

    @JsonProperty("TransactionDate")
    private String transactionDate;

    @JsonProperty("TransactionGUID")
    private String transactionGUID;

    @JsonProperty("TransactionType")
    private String transactionType;

    @JsonProperty("ResultCount")
    private int resultCount;

    @JsonProperty("TransactionPassThroughId")
    private String transactionPassThroughId;

    @JsonProperty("TransactionContractId")
    private String transactionContractId;

    @JsonProperty("TransactionUserId")
    private String transactionUserId;

    @JsonProperty("AdditionalCharges")
    private AdditionalCharges additionalCharges;

    @JsonProperty("Policy")
    private PolicyDetails policy;

    @JsonProperty("claimInfo")
    @JsonAlias({"ClaimInfo"})
    private ClaimInfoDetails claimInfo;

    @JsonProperty("claimOffice")
    private ClaimOfficeDetails claimOffice;

    @JsonProperty("claimAdjuster")
    private ClaimAdjusterDetails claimAdjuster;

    @JsonProperty("rentalInfo")
    @JsonAlias({"RentalInfo"})
    private RentalInfoDetails rentalInfo;

    @JsonProperty("RentalInvoice")
    private RentalInvoiceDetails rentalInvoice;

    @JsonProperty("repairFacility")
    private RepairFacility repairFacility;

    @JsonProperty("TransactionHeader")
    private TransactionHeaderDetails transactionHeaderDetails;

    // Getters and setters

    public String getMsgGuid() { return msgGuid; }

    public void setMsgGuid(String msgGuid) { this.msgGuid = msgGuid; }

    public String getMsgDate() { return msgDate; }

    public void setMsgDate(String msgDate) { this.msgDate = msgDate; }

    public String getTransactionDate() { return transactionDate; }

    public void setTransactionDate(String transactionDate) { this.transactionDate = transactionDate; }

    public String getTransactionGUID() { return transactionGUID; }

    public void setTransactionGUID(String transactionGUID) { this.transactionGUID = transactionGUID; }

    public String getTransactionType() { return transactionType; }

    public void setTransactionType(String transactionType) { this.transactionType = transactionType; }

    public int getResultCount() { return resultCount; }

    public void setResultCount(int resultCount) { this.resultCount = resultCount; }

    public String getTransactionPassThroughId() { return transactionPassThroughId; }

    public void setTransactionPassThroughId(String transactionPassThroughId) {
        this.transactionPassThroughId = transactionPassThroughId;
    }

    public String getTransactionContractId() { return transactionContractId; }

    public void setTransactionContractId(String transactionContractId) {
        this.transactionContractId = transactionContractId;
    }

    public String getTransactionUserId() { return transactionUserId; }

    public void setTransactionUserId(String transactionUserId) { this.transactionUserId = transactionUserId; }

    public AdditionalCharges getAdditionalCharges() { return additionalCharges; }

    public void setAdditionalCharges(AdditionalCharges additionalCharges) { this.additionalCharges = additionalCharges;}

    public PolicyDetails getPolicy() { return policy; }

    public void setPolicy(PolicyDetails policy) { this.policy = policy; }

    public ClaimInfoDetails getClaimInfo() { return claimInfo; }

    public void setClaimInfo(ClaimInfoDetails claimInfo) { this.claimInfo = claimInfo; }

    public ClaimOfficeDetails getClaimOffice() { return claimOffice; }

    public void setClaimOffice(ClaimOfficeDetails claimOffice) { this.claimOffice = claimOffice; }

    public ClaimAdjusterDetails getClaimAdjuster() { return claimAdjuster; }

    public void setClaimAdjuster(ClaimAdjusterDetails claimAdjuster) { this.claimAdjuster = claimAdjuster; }

    public RentalInfoDetails getRentalInfo() { return rentalInfo; }

    public void setRentalInfo(RentalInfoDetails rentalInfo) { this.rentalInfo = rentalInfo; }

    public RentalInvoiceDetails getRentalInvoice() { return rentalInvoice; }

    public void setRentalInvoice(RentalInvoiceDetails rentalInvoice) { this.rentalInvoice = rentalInvoice; }

    public RepairFacility getRepairFacility() { return repairFacility; }

    public void setRepairFacility(RepairFacility repairFacility) { this.repairFacility = repairFacility; }

    public TransactionHeaderDetails getTransactionHeaderDetails() { return transactionHeaderDetails; }

    public void setTransactionHeaderDetails(TransactionHeaderDetails transactionHeaderDetails) {
        this.transactionHeaderDetails = transactionHeaderDetails;
    }
}
