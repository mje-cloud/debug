package acc.hertz.route.base.types.rest;


import acc.hertz.client.core.WebMethodType;
import acc.hertz.route.base.AbstractRouteBuilder;
import acc.hertz.util.AppProperty;
import acc.hertz.util.AppUtils;
import org.apache.camel.component.bean.MethodNotFoundException;
import org.apache.camel.http.base.HttpOperationFailedException;
import org.apache.camel.language.bean.RuntimeBeanExpressionException;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.model.rest.RestConfigurationDefinition;
import org.apache.camel.model.rest.RestDefinition;
import org.apache.hc.core5.http.HttpStatus;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.net.HttpURLConnection;

@Named
public abstract class AbstractRestRouteBuilder extends AbstractRouteBuilder {

    private RestDefinition restDefinition;
    private RestConfigurationDefinition restConfigurationDefinition;
    @Inject
    private AppProperty property;
    public AbstractRestRouteBuilder() {
        super();
    }


    protected abstract void setupEndpoints();

    @Override
    public void configure() {
        onException(RuntimeBeanExpressionException.class)
            .handled(true)
            .process(exchange -> {
                IResponseHandler.handleResponse(exchange,property.getNoDataFoundMessage(), HttpStatus.SC_NOT_FOUND);
            });
        onException(Exception.class)
            .handled(true)
            .process(exchange -> {
                IResponseHandler.handleResponse(exchange,property.getNoDataFoundMessage(), HttpStatus.SC_NOT_FOUND);
            });
        onException(MethodNotFoundException.class)
            .handled(true)
            .process(exchange -> {
                    IResponseHandler.handleResponse(exchange,property.getNoDataFoundMessage(), HttpStatus.SC_NOT_FOUND);
                });
        onException(HttpOperationFailedException.class)
                .handled(true)
                .process(exchange -> {
                    IResponseHandler.handleResponse(exchange,property.getNoDataFoundMessage(), HttpStatus.SC_NOT_FOUND);
                });
        setupEndpoints();
    }

    public RestDefinition generateRestEndpoint(final String restPath, final WebMethodType method, final String title, final String consume, final String produces, final String initialRouteID, RestBindingMode bindingMode) {
        restConfigurationDefinition = restConfiguration()
                .apiProperty("api.title", "Integration Gateway API Service")
                .apiProperty("api.version", "1.0");

        restDefinition = rest(AppUtils.ROUTE_ROOT_PATH);
        try {
            switch (method) {
                case GET:
                    restDefinition = restPath != null ? restDefinition.get(restPath) : restDefinition.get();
                    break;
                case POST:
                    restDefinition = restPath != null ? restDefinition.post(restPath) : restDefinition.post();
                    break;
                case PATCH:
                    restDefinition = restPath != null ? restDefinition.patch(restPath) : restDefinition.patch();
                    break;
                case PUT:
                    restDefinition = restPath != null ? restDefinition.put(restPath) : restDefinition.put();
                    break;
                case DELETE:
                    restDefinition = restPath != null ? restDefinition.delete(restPath) : restDefinition.delete();
                    break;
                default:
                    String message = AppUtils.sanitize("Invalid web method provided");
                    log.error(message);
            }
        } catch (Exception e) {
            throw e;
        } finally {
            if (restConfiguration() != null) {
                restDefinition.tag(title)
                        .consumes(consume)
                        .produces(produces)
                        .bindingMode(bindingMode)
                        .responseMessage()
                        .code(HttpURLConnection.HTTP_OK)
                        .endResponseMessage()
                        .to(initialRouteID);
            }
        }
        return restDefinition;
    }
}
