package acc.hertz.model.hertz.shared;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransactionHeaderDetails {

    @JsonProperty("MSGGUID")
    private String msgGuid;

    @JsonProperty("MSGDate")
    private String msgDate;

    @JsonProperty("TransactionDate")
    private String transactionDate;

    @JsonProperty("TransactionGUID")
    private String transactionGuid;

    @JsonProperty("TransactionType")
    private String transactionType;

    @JsonProperty("TransactionPassthroughId")
    private String transactionPassThroughId;

    @JsonProperty("TransactionUserId")
    private String transactionUserId;

    // Getters and setters

    public String getMsgGuid() { return msgGuid; }

    public void setMsgGuid(String msgGuid) { this.msgGuid = msgGuid; }

    public String getMsgDate() { return msgDate; }

    public void setMsgDate(String msgDate) { this.msgDate = msgDate; }

    public String getTransactionDate() { return transactionDate; }

    public void setTransactionDate(String transactionDate) { this.transactionDate = transactionDate; }

    public String getTransactionGuid() { return transactionGuid; }

    public void setTransactionGuid(String transactionGuid) { this.transactionGuid = transactionGuid; }

    public String getTransactionType() { return transactionType; }

    public void setTransactionType(String transactionType) { this.transactionType = transactionType; }

    public String getTransactionPassThroughId() { return transactionPassThroughId; }

    public void setTransactionPassThroughId(String transactionPassThroughId) {
        this.transactionPassThroughId = transactionPassThroughId;
    }

    public String getTransactionUserId() { return transactionUserId; }

    public void setTransactionUserId(String transactionUserId) { this.transactionUserId = transactionUserId; }
}
