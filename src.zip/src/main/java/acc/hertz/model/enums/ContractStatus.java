package acc.hertz.model.enums;

public enum ContractStatus {
    REACTIVE_EXTENSION("open_ext", "Open – Reactive Extension Request", "This would be the status when you receive an Extension Request from Hertz. Once the extension is responded to by the GFT side then the status on Guidewire should go back to Open"),
    RESERVATION_OPEN_WALKUP("open_walkup", "Walk-Up Authorization Reservation Request", "This would be the status when you receive a walkup request for authorization from TSD (when acc.hertz.api.handler opens a Walkup Rental)"),
    RENTAL_OPEN("open", "Rental Opened", "This would be the status when the rental opens on the Hertz side (rental is opened) and you receive the Open Message from TSD"),
    RENTAL_CLOSE("closed", "Rental Closed", "Used during Rental Close"),
    RENTAL_CANCEL("cancel", "Reservation Cancelled", "Used during Rental Cancelled"),
    RENTAL_INVOICE("invoiced", "Rental Invoiced", "Used during Invoicing"),
    RESERVATION_PENDING("pending", "Reservation Requested", "This would be the status when you send a reservation from us until you receive the confirmation (should be very quick that it moves from Requested to Confirmed)"),
    RESERVATION_CONFIRMED("confirmed", "Reservation Confirmed", "This would be the status when you receive the confirmation back from TSD (after you send the assignment to TSD)");

    private final String code;
    private final String name;
    private final String description;

    ContractStatus(String code, String name, String description) {
        this.code = code;
        this.name = name;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public static ContractStatus fromCode(String code) {
        for (ContractStatus status : values()) {
            if (status.getCode().equals(code)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Unknown code: " + code);
    }
}
