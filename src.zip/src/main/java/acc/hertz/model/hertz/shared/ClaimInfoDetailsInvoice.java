package acc.hertz.model.hertz.shared;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClaimInfoDetailsInvoice {

    @JsonProperty("Id")
    private String id;

    @JsonProperty("Type")
    private String type;

    @JsonProperty("DriverFirstName")
    private String driverFirstName;

    @JsonProperty("DriverLastName")
    private String driverLastName;

    @JsonProperty("LossDate")
    private String lossDate;

    @JsonProperty("ClaimVehicleCondition")
    private String claimVehicleCondition;

    @JsonProperty("ClaimVehicleColor")
    private String claimVehicleColor;

    @JsonProperty("ClaimVehicleID")
    private String claimVehicleId;

    @JsonProperty("ClaimVehicleMake")
    private String claimVehicleMake;

    @JsonProperty("ClaimVehicleModel")
    private String claimVehicleModel;

    @JsonProperty("ClaimVehicleYear")
    private String claimVehicleYear;

    @JsonProperty("DriverPhone")
    private String driverPhone;

    @JsonProperty("DriverPhoneExt")
    private String driverPhoneExt;

    @JsonProperty("DriverZIP")
    private String driverZip;

    @JsonProperty("DriverStreet1")
    private String driverStreet1;

    @JsonProperty("DriverStreet2")
    private String driverStreet2;

    @JsonProperty("DriverCity")
    private String driverCity;

    @JsonProperty("DriverState")
    private String driverState;

    @JsonProperty("DriverCountry")
    private String driverCountry;

    @JsonProperty("PayDailyAmount")
    private double payDailyAmount;

    @JsonProperty("PayTaxes")
    private boolean payTaxes;

    @JsonProperty("PayTotalBill")
    private boolean payTotalBill;

    @JsonProperty("RentalDailyAmount")
    private double rentalDailyAmount;

    @JsonProperty("TotalDays")
    private int totalDays;

    @JsonProperty("RentalRequestedClass")
    private int rentalRequestedClass;

    @JsonIgnoreProperties("ClaimNoteRentalInstructions")
    private String claimNoteRentalInstructions;

    @JsonProperty("IncrementalDays")
    private int incrementalDays;

    @JsonProperty("FRPflag")
    private boolean frpFlag;

    @JsonProperty("AuthFinalDate")
    private String authFinalDate;

    @JsonProperty("AdditionalCharges")
    private List<AdditionalCharges> additionalCharges;

    // Getters and setters
    public String getId() { return id; }

    public void setId(String id) {this.id = id; }

    public String getType() { return type; }

    public void setType(String type){ this.type = type; }

    public String getDriverFirstName() { return driverFirstName; }

    public void setDriverFirstName(String driverFirstName) { this.driverFirstName = driverFirstName; }

    public String getDriverLastName() { return driverLastName; }

    public void setDriverLastName(String driverLastName) { this.driverLastName = driverLastName; }

    public String getLossDate() { return lossDate; }

    public void setLossDate(String lossDate) { this.lossDate = lossDate; }

    public String getClaimVehicleCondition() { return claimVehicleCondition; }

    public void setClaimVehicleCondition(String claimVehicleCondition) {
        this.claimVehicleCondition = claimVehicleCondition;
    }

    public String getClaimVehicleColor() { return claimVehicleColor; }

    public void setClaimVehicleColor(String claimVehicleColor) { this.claimVehicleColor = claimVehicleColor; }

    public String getClaimVehicleId() { return claimVehicleId; }

    public void setClaimVehicleId(String claimVehicleId) { this.claimVehicleId = claimVehicleId; }

    public String getClaimVehicleMake() { return claimVehicleMake; }

    public void setClaimVehicleMake(String claimVehicleMake) { this.claimVehicleMake = claimVehicleMake; }

    public String getClaimVehicleModel() { return claimVehicleModel; }

    public void setClaimVehicleModel(String claimVehicleModel) { this.claimVehicleModel = claimVehicleModel; }

    public String getClaimVehicleYear() { return claimVehicleYear; }

    public void setClaimVehicleYear(String claimVehicleYear) { this.claimVehicleYear = claimVehicleYear; }

    public String getDriverPhone() { return driverPhone; }

    public void setDriverPhone(String driverPhone) { this.driverPhone = driverPhone; }

    public String getDriverPhoneExt() { return driverPhoneExt; }

    public void setDriverPhoneExt(String driverPhoneExt) { this.driverPhoneExt = driverPhoneExt; }

    public String getDriverZip() { return driverZip; }

    public void setDriverZip(String driverZip) { this.driverZip = driverZip; }

    public String getDriverStreet1() { return driverStreet1; }

    public void setDriverStreet1(String driverStreet1) { this.driverStreet1 = driverStreet1; }

    public String getDriverStreet2() { return driverStreet2; }

    public void setDriverStreet2(String driverStreet2) { this.driverStreet2 = driverStreet2; }

    public String getDriverCity() { return driverCity; }

    public void setDriverCity(String driverCity) { this.driverCity = driverCity; }

    public String getDriverState() { return driverState; }

    public void setDriverState(String driverState) { this.driverState = driverState; }

    public String getDriverCountry() { return driverCountry; }

    public void setDriverCountry(String driverCountry) { this.driverCountry = driverCountry; }

    public double getPayDailyAmount() { return payDailyAmount; }

    public void setPayDailyAmount(double payDailyAmount) { this.payDailyAmount = payDailyAmount; }

    public boolean isPayTaxes() { return payTaxes; }

    public void setPayTaxes(boolean payTaxes) { this.payTaxes = payTaxes; }

    public boolean isPayTotalBill() { return payTotalBill; }

    public void setPayTotalBill(boolean payTotalBill) { this.payTotalBill = payTotalBill; }

    public double getRentalDailyAmount() { return rentalDailyAmount; }

    public void setRentalDailyAmount(double rentalDailyAmount) { this.rentalDailyAmount = rentalDailyAmount; }

    public int getTotalDays() { return totalDays; }

    public void setTotalDays(int totalDays) { this.totalDays = totalDays; }

    public int getRentalRequestedClass() { return rentalRequestedClass; }

    public void setRentalRequestedClass(int rentalRequestedClass) { this.rentalRequestedClass = rentalRequestedClass; }

    public String getClaimNoteRentalInstructions() { return claimNoteRentalInstructions; }

    public void setClaimNoteRentalInstructions(String claimNoteRentalInstructions) {
        this.claimNoteRentalInstructions = claimNoteRentalInstructions;
    }

    public int getIncrementalDays() { return incrementalDays; }

    public void setIncrementalDays(int incrementalDays) { this.incrementalDays = incrementalDays; }

    public boolean isFrpFlag() { return frpFlag; }

    public void setFrpFlag(boolean frpFlag) { this.frpFlag = frpFlag; }

    public String getAuthFinalDate() { return authFinalDate; }

    public void setAuthFinalDate(String authFinalDate) { this.authFinalDate = authFinalDate; }

    public List<AdditionalCharges> getAdditionalCharges() { return additionalCharges; }

    public void setAdditionalCharges(List<AdditionalCharges> additionalCharges) {
        this.additionalCharges = additionalCharges;
    }
}
