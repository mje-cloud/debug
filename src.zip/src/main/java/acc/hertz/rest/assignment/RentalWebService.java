package acc.hertz.rest.assignment;

import acc.hertz.client.core.WebMethodType;
import acc.hertz.model.enums.MimeType;
import acc.hertz.model.hertz.outbound.BaseHertzRequest;
import acc.hertz.model.hertz.outbound.BaseHertzResponse;
import acc.hertz.processors.RentalRequestProcessor;
import acc.hertz.route.base.types.rest.AbstractRestRouteBuilder;
import acc.hertz.util.AppProperty;
import acc.hertz.util.AppUtils;
import acc.hertz.util.log.LoggerBean;
import gw.api.ig.failure.FailureConfiguration;
import gw.impl.ig.failure.DefaultFailureConfiguration;
import org.apache.camel.Exchange;
import org.apache.camel.model.rest.RestBindingMode;

import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named
public class RentalWebService extends AbstractRestRouteBuilder {
   @Inject
   private AppProperty properties;
   @Inject
   private RentalRequestProcessor rentalRequestProcessor;
    @Override
    public void setupEndpoints()  {
        var restService = super.generateRestEndpoint(AppUtils.ASSIGNMENT_SERVICE, WebMethodType.POST, AppUtils.ASSIGNMENT_SERVICE_TITLE, MimeType.JSON.getCode(), MimeType.JSON.getCode(), AppUtils.ROUTE_ID_RENTAL_WEB_SERVICE,RestBindingMode.json);
        restService.type(BaseHertzRequest.class);
        restService.id(AppUtils.ASSIGNMENT_SERVICE_TITLE);
        restService.outType(BaseHertzResponse.class);
        from(AppUtils.ROUTE_ID_RENTAL_WEB_SERVICE)
                .routeId(this.getClass().getSimpleName())
                .doTry()
                  .process(rentalRequestProcessor)
                .endDoTry()
                .doCatch(Exception.class)
                   .process(exchange -> {
                      Throwable caughtException = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);
                      log.error(getClass().getSimpleName() + " Failed to process assignment. Reason: " + AppUtils.sanitize(caughtException.getMessage()));
                   })
                .marshal().json()
                .bean(LoggerBean.class, "operationalLogging(*, 2, ${routeId})")
                .end();
    }

    @Override
    public FailureConfiguration<?> createFailureConfiguration() {
        return new DefaultFailureConfiguration();
    }
}