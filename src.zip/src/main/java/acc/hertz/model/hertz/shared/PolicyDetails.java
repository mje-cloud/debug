package acc.hertz.model.hertz.shared;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PolicyDetails {

    @JsonProperty("InsuranceCompany")
    private String insuranceCompany;

    @JsonProperty("PolicyNumber")
    private String policyNumber;

    @JsonProperty("PercentPay")
    private double percentPay;

    @JsonProperty("DailyMaxCoverage")
    private double dailyMaxCoverage;

    @JsonProperty("MaxCoverage")
    private double maxCoverage;

    @JsonProperty("InsuredFirstName")
    private String insuredFirstName;

    @JsonProperty("InsuredLastName")
    private String insuredLastName;

    // Getters and setters
    public String getInsuranceCompany() { return insuranceCompany; }

    public void setInsuranceCompany(String insuranceCompany) { this.insuranceCompany = insuranceCompany; }

    public String getPolicyNumber() { return policyNumber; }

    public void setPolicyNumber(String policyNumber) { this.policyNumber = policyNumber; }

    public double getPercentPay() { return percentPay; }

    public void setPercentPay(double percentPay) { this.percentPay = percentPay; }

    public double getDailyMaxCoverage() { return dailyMaxCoverage; }

    public void setDailyMaxCoverage(double dailyMaxCoverage) { this.dailyMaxCoverage = dailyMaxCoverage; }

    public double getMaxCoverage() { return maxCoverage; }

    public void setMaxCoverage(double maxCoverage) { this.maxCoverage = maxCoverage; }

    public String getInsuredFirstName() { return insuredFirstName; }

    public void setInsuredFirstName(String insuredFirstName) { this.insuredFirstName = insuredFirstName; }

    public String getInsuredLastName() { return insuredLastName; }

    public void setInsuredLastName(String insuredLastName) { this.insuredLastName = insuredLastName; }
}
