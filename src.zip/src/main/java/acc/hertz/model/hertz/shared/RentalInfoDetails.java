package acc.hertz.model.hertz.shared;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class RentalInfoDetails {

    @JsonProperty("PartnerCode")
    private String partnerCode;

    @JsonProperty("VendorName")
    private String vendorName;

    @JsonProperty("VendorOfficeId")
    private String vendorOfficeId;

    @JsonProperty("VendorOfficeName")
    private String vendorOfficeName;

    @JsonProperty("VendorOfficeStreet1")
    private String vendorOfficeStreet1;

    @JsonProperty("VendorOfficeStreet2")
    private String vendorOfficeStreet2;

    @JsonProperty("VendorOfficeCity")
    private String vendorOfficeCity;
    @JsonProperty("VendorOfficeStateId")
    private String vendorOfficeStateId;
    @JsonProperty("VendorOfficeState")
    private String VendorOfficeState;

    @JsonProperty("VendorOfficeZip")
    private String vendorOfficeZip;

    @JsonProperty("VendorOfficePhone")
    private String vendorOfficePhone;

    @JsonProperty("ContractID")
    @JsonAlias({"ContractId"})
    private String contractId;

    @JsonProperty("ContractStatus")
    private String contractStatus;

    @JsonProperty("NoteSend")
    private String noteSend;

    @JsonProperty("PickupDate")
    private String pickupDate;

    @JsonProperty("RatePerDayAmount")
    private BigDecimal ratePerDayAmount;

    @JsonProperty("StartDate")
    private String startDate;

    @JsonProperty("ExpReturnDate")
    private String expReturnDate;

    @JsonProperty("EndDate")
    private String endDate;

    @JsonProperty("RateClass")
    private String rateClass;

    @JsonProperty("VehicleClass")
    private String vehicleClass;

    @JsonProperty("ProgramType")
    private String programType;

    @JsonProperty("VehicleColor")
    private String vehicleColor;

    @JsonProperty("VehicleID")
    private String vehicleId;

    @JsonProperty("VehicleMake")
    private String vehicleMake;

    @JsonProperty("VehicleModel")
    private String vehicleModel;

    @JsonProperty("VehicleYear")
    private String vehicleYear;

    @JsonProperty("DriverFirstName")
    private String driverFirstName;

    @JsonProperty("DriverLastName")
    private String driverLastName;

    @JsonProperty("DriverAddress1")
    private String driverAddress1;

    @JsonProperty("DriverAddress2")
    private String driverAddress2;

    @JsonProperty("DriverCity")
    private String driverCity;

    @JsonProperty("DriverState")
    private String driverState;

    @JsonProperty("DriverZip")
    private String driverZip;

    @JsonProperty("DriverBestPhone")
    private String driverBestPhone;

    @JsonProperty("DriverBestPhoneExt")
    private String driverBestPhoneExt;

    @JsonProperty("DriverEmail")
    private String driverEmail;

    @JsonProperty("DriverHomePhone")
    private String driverHomePhone;

    @JsonProperty("DriverHomePhoneExt")
    private String driverHomePhoneExt;

    @JsonProperty("DriverWorkPhone")
    private String driverWorkPhone;

    @JsonProperty("DriverWorkPhoneExt")
    private String driverWorkPhoneExt;


}

