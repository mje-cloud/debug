package acc.hertz.model.enums;

public enum ServiceRequestProgress {
    DRAFT("draft", "The service is still being edited and has not yet been sent to the vendor", 1),
    REQUESTED("requested", "Service request has been sent to the selected vendor, and has been acknowledged", 2),
    SPECIALIST_WAITING("specialistwaiting", "Vendor is blocked", 3),
    IN_PROGRESS("inprogress", "The vendor is authorized to perform the work", 4),
    WORK_COMPLETE("workcomplete", "The work has been completed", 5),
    DECLINED("declined", "The vendor has declined to accept the service request", 6),
    CANCELED("canceled", "The service request has been canceled", 7),
    EXPIRED("expired", "The service has expired", 8);

    private final String code;
    private final String description;
    private final int priority;

    ServiceRequestProgress(String code, String description, int priority) {
        this.code = code;
        this.description = description;
        this.priority = priority;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public int getPriority() {
        return priority;
    }

    public static ServiceRequestProgress fromCode(String code) {
        for (ServiceRequestProgress status : values()) {
            if (status.code.equalsIgnoreCase(code)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Unknown code: " + code);
    }
}
