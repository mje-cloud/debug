package acc.hertz.processors.composite.helper;

import acc.hertz.client.core.WebMethodType;
import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.composite.core.AbstractCompositeRequest;
import acc.hertz.model.cloudapi.composite.core.BaseRequest;
import acc.hertz.model.cloudapi.composite.core.RequestVarType;
import acc.hertz.model.cloudapi.composite.core.RequestVars;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestList;
import acc.hertz.model.enums.EntityEventType;
import acc.hertz.model.enums.ServiceRequestProgress;
import acc.hertz.processors.composite.CompositeBuilder;
import acc.hertz.processors.composite.helper.payload.HistoryComposite;
import acc.hertz.processors.composite.helper.payload.ServiceRequestPostComposite;
import acc.hertz.util.AppUtils;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import static acc.hertz.util.AppUtils.CLOUD_API_SERVICE_REQUEST_WORK_COMPLETED;

@Named
public class CompositeRentalCloseHelper {
    @Inject
    private CompositeBuilder compositeBuilder;

    public AbstractCompositeRequest buildCompositeRequest(ClaimData claim,
                                                                 ServiceRequestList.ServiceRequest currentService,
                                                                 ServiceRequestPostComposite serviceRequest,
                                                                 HistoryComposite history) throws ParseException {

        AbstractCompositeRequest request = new AbstractCompositeRequest();
        request.getRequests().add(createServiceRequestPatch(claim, currentService, serviceRequest));
        request.getRequests().add(createHistoryEntry(history));
        return request;
    }

    private BaseRequest createServiceRequestPatch(ClaimData claim, ServiceRequestList.ServiceRequest currentService, ServiceRequestPostComposite serviceRequest) {
        String url = AppUtils.CLOUD_API_SERVICE_REQUEST_PATCH.replace("$1", claim.getData().getAttributes().getId()).replace("$2", currentService.getAttributes().getId()).replace(AppUtils.COMPOSITE_API_REST_PATH, "/");
        List<RequestVars> vars = new ArrayList<>();
        RequestVars requestVars = compositeBuilder.createVar(RequestVarType.SERVICE_REQUEST_ID.getPath(), RequestVarType.SERVICE_REQUEST_ID.getName());
        vars.add(requestVars);
        var baseRequest = compositeBuilder.getBaseRequest(serviceRequest, url, WebMethodType.PATCH);
        baseRequest.setVars(vars);
        return baseRequest;
    }

    private BaseRequest createHistoryEntry(HistoryComposite history) {
        String url = AppUtils.CLOUD_API_CREATE_HISTORY_ENTRY.replace(AppUtils.COMPOSITE_API_REST_PATH, "/");
        history.getData().getAttributes().getServiceRequest().setId(RequestVarType.SERVICE_REQUEST_ID.getBuildVarTypeParameter());
        history.getData().getAttributes().getServiceRequest().setType(EntityEventType.SERVICE_REQUEST.getType());
        return compositeBuilder.getBaseRequest(history, url, WebMethodType.POST);
    }

}
