package acc.hertz.appevent;

import acc.hertz.processors.ReservationAppEventProcessor;
import acc.hertz.route.base.types.appevent.AbstractAppEventRouteBuilder;
import acc.hertz.util.AppProperty;
import acc.hertz.util.log.LoggerBean;

import gw.api.ig.failure.FailureConfiguration;
import gw.impl.ig.failure.DefaultFailureConfiguration;
import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named
public class ReservationAppEvent  extends AbstractAppEventRouteBuilder {
    @Inject
    private AppProperty properties;

    @Inject
    private ReservationAppEventProcessor reservationAppEventProcessor;

    @Override
    public void setupAppEvent() {
        from("appevents:cc?id=cc-reservation&events=" + properties.getEvents())
                .routeId(getClass().getSimpleName())
                .log("New Event from ClaimCenter arrived")
                .doTry()
                .process(reservationAppEventProcessor)
                .bean(LoggerBean.class, "operationalLogging(*, 2, ${routeId})")
                .doCatch(Exception.class)
                .log("Exception caught in route ${routeId}: ${exception.message}")
                .bean(LoggerBean.class, "operationalLogging(*, 2, ${routeId})")
                .end();
    }

    @Override
    public FailureConfiguration<?> createFailureConfiguration() {
        return new DefaultFailureConfiguration();
    }
}



