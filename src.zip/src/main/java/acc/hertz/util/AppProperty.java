package acc.hertz.util;

import jakarta.inject.Named;
import jakarta.inject.Singleton;
import lombok.Getter;
import org.apache.camel.PropertyInject;

import jakarta.inject.Named;
import jakarta.inject.Singleton;

@Singleton
@Named
@Getter
public class AppProperty {

    @PropertyInject("cc.hertz.app.events")
    private String events;
    @PropertyInject("cc.guidewire.server")
    private String currentCloudAPIServer;
    @PropertyInject("cc.hertz.ig.server.api.basic.user")
    private String userNameTSD;
    @PropertyInject("cc.hertz.ig.server.api.basic.password")
    private String passwordTSD;
    @PropertyInject("cc.hertz.ig.server.api")
    private String apiTSDServer;
    @PropertyInject("cc.hertz.ig.server.api.msg.source")
    private String msgSource;
    @PropertyInject("cc.hertz.ig.scope.scp.cc.app")
    private String igAppNameScope;
    @PropertyInject("cc.hertz.ig.scope.cc.service")
    private String igAppServiceScope;
    @PropertyInject("cc.hertz.ig.scope.planet.class.lower")
    private String igAppLowerPlanet;
    @PropertyInject("cc.hertz.ig.scope.project.gw.cp")
    private String igAppGWCP;
    @PropertyInject("cc.hertz.ig.scope.tenant")
    private String igAppTenant;
    @PropertyInject("cc.hertz.ig.server.api.method.location.search.count")
    private String searchLocationCount;
    @PropertyInject("cc.hertz.ig.module.canada.active")
    private boolean isCanadaModuleEnabled;
    @PropertyInject("cc.hertz.ig.email.smtp")
    private String smtp;
    @PropertyInject("cc.hertz.ig.email.smtp.port")
    private String smtpPort;
    @PropertyInject("cc.hertz.ig.email.from")
    private String senderEmail;
    @PropertyInject("cc.hertz.ig.email.password")
    private String senderPassword;
    @PropertyInject("cc.hertz.ig.vendor.default.tax.id")
    private String defaultTaxId;
    @PropertyInject("cc.hertz.ig.email.user")
    private String userName;
    @PropertyInject("cc.hertz.api.ws.claims.not.data.found")
    private String noDataFoundMessage;
    @PropertyInject("cc.hertz.retry")
    private String retries;
    @PropertyInject("cc.hertz.delay")
    private String delay;
    @PropertyInject("cc.hertz.delay.multiplier")
    private String multiplier;
    @PropertyInject("cc.hertz.ig.service.call.sleeptime")
    private int serviceCallSleepTime;

    public AppProperty() {
    }
}
