package acc.hertz.model.enums;

public enum ServiceVendorType {
    SPECIALIST_SERVICE_VENDOR("servicerequestspecialist","Service Vendor"),
    SPECIALIST_VENDOR("vendor","Vendor");

    private final String code;

    public String getName() {
        return name;
    }

    private final String name;

    ServiceVendorType(String code, String name) {
        this.code = code;
        this.name=name;
    }

    public String getCode() {
        return code;
    }

    public static ServiceVendorType fromType(String type) {
        for (ServiceVendorType kind : values()) {
            if (kind.getCode().equals(type)) {
                return kind;
            }
        }
        throw new IllegalArgumentException("Unknown Type: " + type);
    }
}
