package acc.hertz.model.cloudapi.claim;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClaimOutcome {

    @JsonProperty("data")
    private Data data;

    // Getters and Setters
    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Data {

        @JsonProperty("attributes")
        private Attributes attributes;

        // Getters and Setters
        public Attributes getAttributes() {
            return attributes;
        }

        public void setAttributes(Attributes attributes) {
            this.attributes = attributes;
        }
        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Attributes {

            @JsonProperty("closedOutcome")
            private ClosedOutcome closedOutcome;

            @JsonProperty("reason")
            private String reason;

            // Getters and Setters
            public ClosedOutcome getClosedOutcome() {
                return closedOutcome;
            }

            public void setClosedOutcome(ClosedOutcome closedOutcome) {
                this.closedOutcome = closedOutcome;
            }

            public String getReason() {
                return reason;
            }

            public void setReason(String reason) {
                this.reason = reason;
            }
            @JsonIgnoreProperties(ignoreUnknown = true)
            @JsonInclude(JsonInclude.Include.NON_NULL)
            public static class ClosedOutcome {

                @JsonProperty("code")
                private String code;


                // Getters and Setters
                public String getCode() {
                    return code;
                }

                public void setCode(String code) {
                    this.code = code;
                }

            }
        }
    }
}
