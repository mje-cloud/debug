package acc.hertz.processors.composite;

import acc.hertz.client.core.WebMethodType;
import acc.hertz.model.cloudapi.composite.core.BaseBody;
import acc.hertz.model.cloudapi.composite.core.BaseRequest;
import acc.hertz.model.cloudapi.composite.core.RequestVars;
import jakarta.inject.Named;

@Named
public class CompositeBuilder {

    public BaseRequest getBaseRequest(BaseBody assignBody, String uri, WebMethodType httpMethod) {
        BaseRequest baseRequest = new BaseRequest();
        baseRequest.setBody(assignBody);
        baseRequest.setMethod(httpMethod.getCode());
        baseRequest.setUri(uri);
        baseRequest.setIncludeResponse(true);
        return baseRequest;
    }

    public BaseRequest getBaseRequest(String uri, WebMethodType httpMethod) {
        BaseRequest baseRequest = new BaseRequest();
        baseRequest.setBody(null);
        baseRequest.setMethod(httpMethod.getCode());
        baseRequest.setUri(uri);
        baseRequest.setIncludeResponse(true);
        return baseRequest;
    }

    public RequestVars createVar(String path, String name) {
        RequestVars requestVars = new RequestVars();
        requestVars.setPath(path);
        requestVars.setName(name);
        return requestVars;
    }
}
