package acc.hertz.model.hertz.outbound;

import acc.hertz.model.hertz.shared.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InvoiceHertzRequest {

    @JsonProperty("MSGGUID")
    private String msgGUID;

    @JsonProperty("MSGDate")
    private String msgDate;

    @JsonProperty("TransactionDate")
    private String transactionDate;

    @JsonProperty("TransactionGUID")
    private String transactionGUID;

    @JsonProperty("TransactionType")
    private String transactionType;

    @JsonProperty("ResultCount")
    private int resultCount;

    @JsonProperty("TransactionPassThroughId")
    private String transactionPassThroughId;

    @JsonProperty("TransactionContractId")
    private String transactionContractId;

    @JsonProperty("TransactionUserId")
    private String transactionUserId;

    @JsonProperty("AdditionalCharges")
    private AdditionalCharges additionalCharges;

    @JsonProperty("Policy")
    private PolicyDetails policyDetails;

    @JsonProperty("ClaimInfo")
    private ClaimInfoDetailsInvoice claimInfo;

    @JsonProperty("ClaimOffice")
    private ClaimOfficeDetails claimOffice;

    @JsonProperty("ClaimAdjuster")
    private ClaimAdjusterDetails claimAdjuster;

    @JsonProperty("RentalInfo")
    private RentalInvoiceInfoDetails rentalInfo;

    @JsonProperty("RentalInvoice")
    private RentalInvoiceDetails rentalInvoice;

    @JsonProperty("RepairFacility")
    private RepairFacilityInvoice repairFacility;

    @JsonProperty("TransactionHeader")
    private TransactionHeaderDetails transactionHeader;

    @JsonProperty("RepairOrder")
    private List<RepairOrder> repairOrder;

    // Getters and setters

    public String getMsgGUID() { return msgGUID; }

    public void setMsgGUID(String msgGUID) { this.msgGUID = msgGUID; }

    public String getMsgDate() { return msgDate; }

    public void setMsgDate(String msgDate) { this.msgDate = msgDate; }

    public String getTransactionDate() { return transactionDate; }

    public void setTransactionDate(String transactionDate) { this.transactionDate = transactionDate; }

    public String getTransactionGUID() { return transactionGUID; }

    public void setTransactionGUID(String transactionGUID) { this.transactionGUID = transactionGUID; }

    public String getTransactionType() { return transactionType; }

    public void setTransactionType(String transactionType) { this.transactionType = transactionType; }

    public int getResultCount() { return resultCount; }

    public void setResultCount(int resultCount) { this.resultCount = resultCount; }

    public String getTransactionPassThroughId() { return transactionPassThroughId; }

    public void setTransactionPassThroughId(String transactionPassThroughId) {
        this.transactionPassThroughId = transactionPassThroughId;
    }

    public String getTransactionContractId() { return transactionContractId; }

    public void setTransactionContractId(String transactionContractId) {
        this.transactionContractId = transactionContractId;
    }

    public String getTransactionUserId() { return transactionUserId; }

    public void setTransactionUserId(String transactionUserId) { this.transactionUserId = transactionUserId; }

    public AdditionalCharges getAdditionalCharges() { return additionalCharges; }

    public void setAdditionalCharges(AdditionalCharges additionalCharges) { this.additionalCharges = additionalCharges;}

    public PolicyDetails getPolicyDetails() { return policyDetails; }

    public void setPolicyDetails(PolicyDetails policyDetails) { this.policyDetails = policyDetails; }

    public ClaimInfoDetailsInvoice getClaimInfo() { return claimInfo; }

    public void setClaimInfo(ClaimInfoDetailsInvoice claimInfo) { this.claimInfo = claimInfo; }

    public ClaimOfficeDetails getClaimOffice() { return claimOffice; }

    public void setClaimOffice(ClaimOfficeDetails claimOffice) { this.claimOffice = claimOffice; }

    public ClaimAdjusterDetails getClaimAdjuster() { return claimAdjuster; }

    public void setClaimAdjuster(ClaimAdjusterDetails claimAdjuster) { this.claimAdjuster = claimAdjuster; }

    public RentalInvoiceInfoDetails getRentalInfo() { return rentalInfo; }

    public void setRentalInfo(RentalInvoiceInfoDetails rentalInfo) { this.rentalInfo = rentalInfo; }

    public RentalInvoiceDetails getRentalInvoice() { return rentalInvoice; }

    public void setRentalInvoice(RentalInvoiceDetails rentalInvoice) { this.rentalInvoice = rentalInvoice; }

    public RepairFacilityInvoice getRepairFacility() { return repairFacility; }

    public void setRepairFacility(RepairFacilityInvoice repairFacility) { this.repairFacility = repairFacility; }

    public TransactionHeaderDetails getTransactionHeader() { return transactionHeader; }

    public void setTransactionHeader(TransactionHeaderDetails transactionHeader) {
        this.transactionHeader = transactionHeader;
    }

    public List<RepairOrder> getRepairOrder() { return repairOrder; }

    public void setRepairOrder(List<RepairOrder> repairOrder) { this.repairOrder = repairOrder; }
}
