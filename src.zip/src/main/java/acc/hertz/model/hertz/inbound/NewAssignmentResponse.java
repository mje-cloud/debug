package acc.hertz.model.hertz.inbound;

import acc.hertz.model.hertz.shared.TransactionResponseHeader;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NewAssignmentResponse {

    @JsonProperty("TransactionResponseHeader")
    private TransactionResponseHeader transactionResponseHeader;

    // Getters and setters

    public TransactionResponseHeader getTransactionResponseHeader() { return transactionResponseHeader; }

    public void setTransactionResponseHeader(TransactionResponseHeader transactionResponseHeader) {
        this.transactionResponseHeader = transactionResponseHeader;
    }
}