package acc.hertz.processors.composite.helper.payload;

import acc.hertz.model.cloudapi.composite.core.BaseBody;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestPost;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class ServiceRequestPostComposite extends BaseBody {
    @JsonProperty("data")
    private Data data;

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Data {
        @JsonProperty("attributes")
        private Attributes attributes;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Attributes {
        @JsonProperty("hertzLicensePlate_Ext")
        private String hertzLicensePlate_Ext;
        @JsonProperty("hertzModel_Ext")
        private String hertzModel_Ext;
        @JsonProperty("hertzMake_Ext")
        private String hertzMake_Ext;
        @JsonProperty("hertzColor_Ext")
        private String hertzColor_Ext;
        @JsonProperty("hertzYear_Ext")
        private String hertzYear_Ext;
        @JsonProperty("hertzRequestType_Ext")
        private boolean hertzRequestType_Ext;
        @JsonProperty("hertzClassName_Ext")
        private String hertzClassName_Ext;
        @JsonProperty("hertzClassCode_Ext")
        private String hertzClassCode_Ext;

        @JsonProperty("hertzTransactionGUID_Ext")
        private String hertzTransactionGUID_Ext;

        @JsonProperty("hertzCustomerSelfPay_Ext")
        private boolean hertzCustomerSelfPay_Ext;
        @JsonProperty("hertzContractStatus_Ext")
        private CodeName hertzContractStatus_Ext;
        @JsonProperty("hertzTransactionContractID_Ext")
        private String hertzTransactionContractID_Ext;

        @JsonProperty("hertzDateType_Ext")
        private CodeName hertzDateType_Ext;

        @JsonProperty("hertzDayCount_Ext")
        private int hertzDayCount_Ext;

        @JsonProperty("hertzIncrementalDays_Ext")
        private int hertzIncrementalDays_Ext;

        @JsonProperty("hertzLossDamageWaiver_Ext")
        private boolean hertzLossDamageWaiver_Ext;

        @JsonProperty("hertzMaxAuthAmount_Ext")
        private Amount hertzMaxAuthAmount_Ext;

        @JsonProperty("hertzPayAllTaxes_Ext")
        private boolean hertzPayAllTaxes_Ext;

        @JsonProperty("hertzPercentagePay_Ext")
        private String hertzPercentagePay_Ext;

        @JsonProperty("hertzPickupDate_Ext")
        private String hertzPickupDate_Ext;
        @JsonProperty("hertzFinalDay_Ext")
        private String hertzFinalDay_Ext;
        @JsonProperty("hertzRateInclusivePrice_Ext")
        private Amount hertzRateInclusivePrice_Ext;

        @JsonProperty("hertzRateType_Ext")
        private CodeName hertzRateType_Ext;

        @JsonProperty("hertzRentalBeginDate_Ext")
        private String hertzRentalBeginDate_Ext;

        @JsonProperty("hertzRentalCompany_Ext")
        private CodeName hertzRentalCompany_Ext;

        @JsonProperty("hertzRentalDailyAmount_Ext")
        private Amount hertzRentalDailyAmount_Ext;

        @JsonProperty("hertzRentalEndDate_Ext")
        private String hertzRentalEndDate_Ext;

        @JsonProperty("hertzTransactionDate_Ext")
        private String hertzTransactionDate_Ext;

        @JsonProperty("hertzRentalRole_Ext")
        private CodeName hertzRentalRole_Ext;

        @JsonProperty("hertzRepairFacility_Ext")
        private IDObject hertzRepairFacility_Ext;

        @JsonProperty("hertzTotalDaysApproved_Ext")
        private int hertzTotalDaysApproved_Ext;

        @JsonProperty("hertzVehicleCondition_Ext")
        private String hertzVehicleCondition_Ext;
        @JsonProperty("hertzTransactionTSDID_Ext")
        private String hertzTransactionTSDID_Ext;
        @JsonProperty("hertzWinterTires_Ext")
        private boolean hertzWinterTires_Ext;

        @JsonProperty("incident")
        private IDObject incident;

        @JsonProperty("instruction")
        private Instruction instruction;

        @JsonProperty("kind")
        private CodeName kind;

        @JsonProperty("requestedServiceCompletionDate")
        private String requestedServiceCompletionDate;

        @JsonProperty("specialist")
        private IDObject specialist;

        @JsonProperty("specialistCommMethod")
        private CodeName specialistCommMethod;

        @JsonProperty("tier")
        private CodeName tier;

        @JsonProperty("hertzRentalLocation_Ext")
        private ServiceRequestPostComposite.IDObject hertzRentalLocation_Ext;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class CodeName {
        @JsonProperty("code")
        private String code;

        @JsonProperty("name")
        private String name;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Amount {
        @JsonProperty("amount")
        private String amount;

        @JsonProperty("currency")
        private String currency;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class IDObject {
        @JsonProperty("id")
        private String id;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Instruction {
        @JsonProperty("customer")
        private IDObject customer;

        @JsonProperty("serviceAddress")
        private ServiceAddress serviceAddress;

        @JsonProperty("services")
        private List<Service> services;

        public void addService(String code){
            if(services==null)
                services = new ArrayList<>();

            Service newService=new Service();
            newService.setCode(code);
            services.add(newService);
        }
        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Setter
        @Getter
        public static class Service {
            @JsonProperty("code")
            private String code;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class ServiceAddress {
        @JsonProperty("addressLine1")
        private String addressLine1;

        @JsonProperty("city")
        private String city;

        @JsonProperty("country")
        private String country;

        @JsonProperty("policyLabel")
        private String policyLabel;

        @JsonProperty("postalCode")
        private String postalCode;

        @JsonProperty("state")
        private CodeName state;

        @JsonProperty("province")
        private CodeName province;
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Service {
        @JsonProperty("code")
        private String code;
    }

}
