package acc.hertz.model.cloudapi.claim;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VehicleIncident  {
    @JsonProperty("attributes")
    private Attributes attributes;

    public Attributes getAttributes() {
        return attributes;
    }

    public void setAttributes(Attributes attributes) {
        this.attributes = attributes;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Attributes {

        @JsonProperty("driver")
        private Driver driver;

        @JsonProperty("custodian_Ext")
        private Driver custodian_Ext;


        @JsonProperty("totalLoss")
        private boolean totalLoss;
        @JsonProperty("id")
        private String id;

        @JsonProperty("lossParty")
        private LossParty lossParty;

        @JsonProperty("vehicle")
        private Vehicle vehicle;

        // Getters and setters

        public Driver getDriver() {
            return driver;
        }

        public void setDriver(Driver driver) {
            this.driver = driver;
        }

        public Driver getCustodian_Ext() {
            return custodian_Ext;
        }

        public void setCustodian_Ext(Driver custodian_Ext) {
            this.custodian_Ext = custodian_Ext;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public LossParty getLossParty() {
            return lossParty;
        }

        public void setLossParty(LossParty lossParty) {
            this.lossParty = lossParty;
        }

        public Vehicle getVehicle() {
            return vehicle;
        }

        public void setVehicle(Vehicle vehicle) {
            this.vehicle = vehicle;
        }

        public boolean isTotalLoss() {
            return totalLoss;
        }

        public void setTotalLoss(boolean totalLoss) {
            this.totalLoss = totalLoss;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class LossParty {
            @JsonProperty("code")
            private String code;

            // Getters and setters

            public String getCode() {
                return code;
            }

            public void setCode(String code) {
                this.code = code;
            }
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Setter
        @Getter
        public static class Vehicle {
            @JsonProperty("displayName")
            private String displayName;

            @JsonProperty("id")
            private String id;

            @JsonProperty("licensePlate")
            private String licensePlate;

            @JsonProperty("make")
            private String make;

            @JsonProperty("model")
            private String model;

            @JsonProperty("color")
            private String color;

            @JsonProperty("policyLabel")
            private String policyLabel;

            @JsonProperty("policyVehicle")
            private boolean policyVehicle;

            @JsonProperty("state")
            private State state;

            @JsonProperty("vin")
            private String vin;

            @JsonProperty("year")
            private int year;

            // Getters and setters

            public String getDisplayName() {
                return displayName;
            }

            public void setDisplayName(String displayName) {
                this.displayName = displayName;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getLicensePlate() {
                return licensePlate;
            }

            public void setLicensePlate(String licensePlate) {
                this.licensePlate = licensePlate;
            }

            public String getMake() {
                return make;
            }

            public void setMake(String make) {
                this.make = make;
            }

            public String getModel() {
                return model;
            }

            public void setModel(String model) {
                this.model = model;
            }

            public String getPolicyLabel() {
                return policyLabel;
            }

            public void setPolicyLabel(String policyLabel) {
                this.policyLabel = policyLabel;
            }

            public boolean isPolicyVehicle() {
                return policyVehicle;
            }

            public void setPolicyVehicle(boolean policyVehicle) {
                this.policyVehicle = policyVehicle;
            }

            public State getState() {
                return state;
            }

            public void setState(State state) {
                this.state = state;
            }

            public String getVin() {
                return vin;
            }

            public void setVin(String vin) {
                this.vin = vin;
            }

            public int getYear() {
                return year;
            }

            public void setYear(int year) {
                this.year = year;
            }
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Driver {
            @JsonProperty("displayName")
            private String displayName;

            @JsonProperty("id")
            private String id;

            @JsonProperty("type")
            private String type;

            @JsonProperty("uri")
            private String uri;

            // Getters and setters

            public String getDisplayName() {
                return displayName;
            }

            public void setDisplayName(String displayName) {
                this.displayName = displayName;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getUri() {
                return uri;
            }

            public void setUri(String uri) {
                this.uri = uri;
            }
        }

    }

}
