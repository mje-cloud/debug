package acc.hertz.util.log;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;

import jakarta.inject.Named;
import java.util.Arrays;
import java.util.Collection;

@Slf4j
@Named
public class AppContextEventListener {

    @EventListener
    public void handleContextRefreshed(ContextRefreshedEvent event) {
        printProcessInfo();
        printActiveProperties((ConfigurableEnvironment) event.getApplicationContext().getEnvironment());
    }

    private void printActiveProperties(ConfigurableEnvironment env) {

        log.info("************************* ACTIVE APP PROPERTIES ******************************");

        env.getPropertySources()
                .stream()
                .filter(ps -> ps instanceof MapPropertySource)
                .map(ps -> ((MapPropertySource) ps).getSource().keySet())
                .flatMap(Collection::stream)
                .distinct()
                .sorted()
                .forEach(key -> log.info("{}={}", key, env.getProperty(key)));

        log.info("******************************************************************************");
    }

    private void printProcessInfo() {

        var self = ProcessHandle.current();
        log.info(">>> IG pid: " + self.pid() + " <<<");

        var procInfo = self.info();

        var argsOpt = procInfo.arguments();
        argsOpt.ifPresent(args -> {
            if (args.length > 0) {
                log.info("************************* ARGUMENTS ******************************************");
                Arrays.stream(args).forEach(arg -> log.info("{}", (arg == null ? null : arg.indent(3))));
                log.info("******************************************************************************");
            }
        });

        procInfo.commandLine().ifPresent(cmdLine -> log.info(">>> Command line: " + cmdLine + " <<<"));

        procInfo.startInstant().ifPresent(startInstant -> log.info(">>> IG start: " + startInstant + " <<<"));
    }
}
