package acc.hertz.model.cloudapi.documents;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreateDocument {

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    @JsonProperty("data")
    private Data data;
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Data {
        public Attributes getAttributes() {
            return attributes;
        }

        public void setAttributes(Attributes attributes) {
            this.attributes = attributes;
        }

        @JsonProperty("attributes")
        private Attributes attributes;
        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Setter
        @Getter
        public static class Attributes {

            public String getAuthor() {
                return author;
            }

            public void setAuthor(String author) {
                this.author = author;
            }

            @JsonProperty("author")
            private String author;

            public String getDescription() {
                return description;
            }

            public void setDescription(String description) {
                this.description = description;
            }

            @JsonProperty("description")
            private String description;

                 public boolean isInbound() {
                return inbound;
            }

            public void setInbound(boolean inbound) {
                this.inbound = inbound;
            }

            @JsonProperty("inbound")
            private boolean inbound;

            public Language getLanguage() {
                return language;
            }

            public void setLanguage(Language language) {
                this.language = language;
            }

            @JsonProperty("language")
            private Language language;

            public String getMimeType() {
                return mimeType;
            }

            public void setMimeType(String mimeType) {
                this.mimeType = mimeType;
            }

            @JsonProperty("mimeType")
            private String mimeType;

            @JsonProperty("relatedTo")
            private RelatedTo relatedTo;

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            @JsonProperty("name")
            private String name;

            public Section getSection() {
                return section;
            }

            public void setSection(Section section) {
                this.section = section;
            }

            @JsonProperty("section")
            private Section section;

            public SecurityType getSecurityType() {
                return securityType;
            }

            public void setSecurityType(SecurityType securityType) {
                this.securityType = securityType;
            }

            @JsonProperty("securityType")
            private SecurityType securityType;

            public Status getStatus() {
                return status;
            }

            public void setStatus(Status status) {
                this.status = status;
            }

            @JsonProperty("status")
            private Status status;

            public Type getType() {
                return type;
            }

            public void setType(Type type) {
                this.type = type;
            }

            @JsonProperty("type")
            private Type type;
            @JsonIgnoreProperties(ignoreUnknown = true)
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @Setter
            @Getter
            public static class RelatedTo {
                @JsonProperty("id")
                private String id;

                @JsonProperty("type")
                private String type;
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            @JsonInclude(JsonInclude.Include.NON_NULL)
            public static class Language {
                public String getCode() {
                    return code;
                }

                public void setCode(String code) {
                    this.code = code;
                }

                @JsonProperty("code")
                private String code;

            }
            @JsonIgnoreProperties(ignoreUnknown = true)
            @JsonInclude(JsonInclude.Include.NON_NULL)
            public static class Section {
                public String getCode() {
                    return code;
                }

                public void setCode(String code) {
                    this.code = code;
                }

                @JsonProperty("code")
                private String code;

            }
            @JsonIgnoreProperties(ignoreUnknown = true)
            @JsonInclude(JsonInclude.Include.NON_NULL)
            public static class SecurityType {
                public String getCode() {
                    return code;
                }

                public void setCode(String code) {
                    this.code = code;
                }

                @JsonProperty("code")
                private String code;

            }
            @JsonIgnoreProperties(ignoreUnknown = true)
            @JsonInclude(JsonInclude.Include.NON_NULL)
            public static class Status {
                public String getCode() {
                    return code;
                }

                public void setCode(String code) {
                    this.code = code;
                }

                @JsonProperty("code")
                private String code;

            }
            @JsonIgnoreProperties(ignoreUnknown = true)
            @JsonInclude(JsonInclude.Include.NON_NULL)
            public static class Type {
                public String getCode() {
                    return code;
                }

                public void setCode(String code) {
                    this.code = code;
                }

                @JsonProperty("code")
                private String code;

            }
        }
    }




}