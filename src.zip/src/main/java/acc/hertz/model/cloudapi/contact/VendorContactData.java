package acc.hertz.model.cloudapi.contact;


import acc.hertz.model.cloudapi.claim.ClaimInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VendorContactData {
    @JsonProperty("data")
    private VendorContactData.Data data;

    public VendorContactData.Data getData() {
        return data;
    }

    public void setData(VendorContactData.Data data) {
        this.data = data;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Data {
        @JsonProperty("attributes")
        private VendorContactData.Data.Attributes attributes;

        public VendorContactData.Data.Attributes getAttributes() {
            return attributes;
        }

        public void setAttributes(VendorContactData.Data.Attributes attributes) {
            this.attributes = attributes;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Attributes {
            @JsonProperty("vendorId")
            private String vendorId;

            public String getVendorId() {
                return vendorId;
            }

            public void setVendorId(String vendorId) {
                this.vendorId = vendorId;
            }


        }
    }


}

