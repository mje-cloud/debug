package acc.hertz.client.document;

import acc.hertz.client.core.IClient;
import acc.hertz.client.core.WebMethodType;
import acc.hertz.client.service.IDocumentClient;
import acc.hertz.model.cloudapi.documents.CreateDocument;
import acc.hertz.model.cloudapi.documents.DocumentResponse;
import acc.hertz.model.enums.MimeType;
import acc.hertz.security.IServerSelector;
import acc.hertz.security.authorization.AuthorizationType;
import acc.hertz.util.AppUtils;
import acc.hertz.util.GenericJSONTransformer;
import acc.hertz.util.TransformerFactory;
import gw.api.ig.GwUtilities;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.commons.codec.binary.Base64;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static acc.hertz.util.AppUtils.*;

@Named
public class DocumentClient implements IDocumentClient {
    @Inject
    private IClient client;
    @Inject
    private IServerSelector serverSelector;
    private final GenericJSONTransformer<CreateDocument> createPackage = TransformerFactory.getTransformer(CreateDocument.class);
    private final GenericJSONTransformer<DocumentResponse> documentResponse = TransformerFactory.getTransformer(DocumentResponse.class);
    public DocumentClient() {
    }

    @Override
    public DocumentResponse getDocument(Exchange exchange, String stickySessionToken, String claimPublicId, String type, String name) throws Exception {
        try {
            StringBuilder filter = new StringBuilder();
            filter.append("?filter=type:eq:");
            filter.append(type);
            filter.append("&filter=name:eq:");
            filter.append(URLEncoder.encode(name, StandardCharsets.UTF_8));
            String server = serverSelector.getServer();
            String url = CLOUD_API_DOCUMENT_GET.replace("$1", claimPublicId);
            client.clearHeaders();
            client.addHeaderParameter(API_CONTENT_TYPE, MimeType.JSON.getCode());

            client.doExecute(server + url + filter.toString(),  WebMethodType.GET, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                return documentResponse.fromJson(AppUtils.sanitize(client.getResponseBody()));
            } else {
                throw new Exception(client.getResponseBody());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    public boolean createDocument(Exchange exchange, String stickySessionToken, String claimPublicId, String invoiceNumber, byte[] byteArrayDocument, CreateDocument createDocument) throws Exception {
        final String boundary = "----WebKitFormBoundary7h3Grcab62jGEiC4";
        try {
            String contentType = "multipart/form-data; boundary=" + boundary;
            List<byte[]> byteArrays = new ArrayList<>();
            createMultiPartForm(boundary, byteArrays, "application/pdf", byteArrayDocument, createDocument);
            String server = serverSelector.getServer();
            String url = AppUtils.CLOUD_API_DOCUMENT_CREATION.replace("$1", claimPublicId);
            client.setExchange(exchange);
            client.clearHeaders();
            client.addHeaderParameter(AppUtils.API_X_GWRE_SESSION, stickySessionToken);
            client.addHeaderParameter(AppUtils.API_CONTENT_TYPE, contentType);
            client.doExecuteBinary(server + url, byteArrays, WebMethodType.POST, AuthorizationType.CLOUD_DETAILED_ACCESS);
            return client.isSuccessExecuted();
        } catch (Exception e) {
            throw e;
        }
    }

    private void createMultiPartForm(final String boundary, List<byte[]> byteArrays, String contentType, byte[] byteArrayDocument, CreateDocument createDocument) throws Exception {
        String metadataContentType = "form-data; name=\"metadata\"";
        String binaryContentType = "form-data; name=\"content\";  filename=\"" + createDocument.getData().getAttributes().getName() + "\"";
        String NEW_LINE_STRING = "\r\n";
        String metadataBodySection = createPackage.toJson(createDocument);
        //METADATA SECTION
        byteArrays.add(getValueAsBytes("--" + boundary));
        byteArrays.add(getValueAsBytes(NEW_LINE_STRING));
        byteArrays.add(getValueAsBytes(AppUtils.API_CONTENT_DISPOSITION + ":" + metadataContentType));
        byteArrays.add(getValueAsBytes(NEW_LINE_STRING));
        byteArrays.add(getValueAsBytes(AppUtils.API_CONTENT_TYPE + ":" + MimeType.JSON.getCode()));
        byteArrays.add(getValueAsBytes(NEW_LINE_STRING));
        byteArrays.add(getValueAsBytes(NEW_LINE_STRING));
        byteArrays.add(getValueAsBytes(metadataBodySection));
        byteArrays.add(getValueAsBytes(NEW_LINE_STRING));
        byteArrays.add(getValueAsBytes("--" + boundary));
        byteArrays.add(getValueAsBytes(NEW_LINE_STRING));
        //CONTENT SECTION
        byteArrays.add(getValueAsBytes(AppUtils.API_CONTENT_DISPOSITION + ":" + binaryContentType));
        byteArrays.add(getValueAsBytes(NEW_LINE_STRING));
        byteArrays.add(getValueAsBytes(AppUtils.API_CONTENT_TYPE + ":" + contentType));
        byteArrays.add(getValueAsBytes(NEW_LINE_STRING));
        byteArrays.add(getValueAsBytes(NEW_LINE_STRING));
        byteArrays.add(byteArrayDocument);
        byteArrays.add(getValueAsBytes(NEW_LINE_STRING));
        byteArrays.add(getValueAsBytes("--" + boundary + "--"));
    }

    private byte[] getValueAsBytes(String value) {
        return value.getBytes(StandardCharsets.UTF_8);
    }
}
