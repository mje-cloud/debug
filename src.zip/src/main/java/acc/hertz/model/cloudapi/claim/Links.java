package acc.hertz.model.cloudapi.claim;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Links {
    @JsonProperty("activities")
    private Activities activities;

    @JsonProperty("activity-assignees")
    private ActivityAssignees activityAssignees;

    @JsonProperty("contacts")
    private Contacts contacts;

    @JsonProperty("documents")
    private Documents documents;


    @JsonProperty("vehicle-incidents")
    private VehicleIncidents vehicleIncidents;

    public VehicleIncidents getVehicleIncidents() {
        return vehicleIncidents;
    }

    public void setVehicleIncidents(VehicleIncidents vehicleIncidents) {
        this.vehicleIncidents = vehicleIncidents;
    }


    public Documents getDocuments() {
        return documents;
    }

    public void setDocuments(Documents documents) {
        this.documents = documents;
    }

    public Contacts getContacts() {
        return contacts;
    }

    public void setContacts(Contacts contacts) {
        this.contacts = contacts;
    }

    public Activities getActivities() {
        return activities;
    }

    public void setActivities(Activities activities) {
        this.activities = activities;
    }

    public ActivityAssignees getActivityAssignees() {
        return activityAssignees;
    }

    public void setActivityAssignees(ActivityAssignees activityAssignees) {
        this.activityAssignees = activityAssignees;
    }

}

