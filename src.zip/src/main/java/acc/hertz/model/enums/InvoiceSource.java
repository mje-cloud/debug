package acc.hertz.model.enums;

public enum InvoiceSource {
    PORTAL_API("gwportal","Guidewire Portal");
    private final String code;

    public String getName() {
        return name;
    }

    private final String name;

    InvoiceSource(String code, String name) {
        this.code = code;
        this.name=name;
    }

    public String getCode() {
        return code;
    }

    public static InvoiceSource fromType(String type) {
        for (InvoiceSource charge : values()) {
            if (charge.getCode().equals(type)) {
                return charge;
            }
        }
        throw new IllegalArgumentException("Unknown : " + type);
    }
}
