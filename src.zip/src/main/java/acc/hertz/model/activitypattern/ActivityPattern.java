package acc.hertz.model.activitypattern;

public enum ActivityPattern {
    HERTZ_WALK_UP_AUTHORIZATION_ACC("HertzWalkupAuthorization_Acc","Walk-up Authorization request", "Review Hertz Walk-up request"),
    HERTZ_REACTIVE_EXTENSION_ACC("HertzReactiveExtension_Acc","Reactive Extension Request","Review Hertz extension request"),
    HERTZ_RENTAL_INVOICE_ACC("HertzRentalInvoice_Acc","Hertz Rental Invoice ","Review Hertz rental invoice"),
    HERTZ_RENTAL_CANCEL_ACC("RENTAL_CANCEL", "Rental reservation cancelled", "Vendor has cancelled the rental reservation");


    private String code, subject, description;

    public String getSubject() {
        return subject;
    }

    public String getDescription() {
        return description;
    }

    ActivityPattern(String code, String subject, String description ) {
        this.code = code;
        this.subject =subject;
        this.description=description;
    }

    public String getCode() {
        return code;
    }

    @Override
    public String toString() {
        return String.valueOf(code);
    }

    public static ActivityPattern fromCode(String code) {
        for ( ActivityPattern b : ActivityPattern.values()) {
            if (b.code.equals(code)) {
                return b;
            }
        }
        return null;
    }
}
