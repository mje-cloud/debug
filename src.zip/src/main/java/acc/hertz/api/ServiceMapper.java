package acc.hertz.api;


import acc.hertz.model.cloudapi.claim.*;
import acc.hertz.model.cloudapi.contact.ClaimContactData;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestList;
import acc.hertz.model.enums.AdditionalChargeType;
import acc.hertz.model.enums.CountryCode;
import acc.hertz.model.enums.TransactionType;
import acc.hertz.model.hertz.inbound.AssignmentRequest;
import acc.hertz.model.hertz.shared.*;
import acc.hertz.process.ReservationHelper;
import acc.hertz.util.AppProperty;
import acc.hertz.util.AppUtils;
import acc.hertz.util.Converter;
import gw.api.ig.GwUtilities;
import org.apache.camel.Exchange;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

@Named
public class ServiceMapper {

    @Inject
    private ReservationHelper reservationHelper;

    public AssignmentRequest mapServiceRequesToAssignmentRequest(Exchange exchange,TransactionRequestHeader header, ClaimData claim, ServiceRequestList.ServiceRequest serviceRequest)throws Exception {
        AssignmentRequest assignmentRequest=null;
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
        try {
            assignmentRequest = new AssignmentRequest();
            assignmentRequest.setMsgGuid(header.getMsgGuid());
            assignmentRequest.setMsgDate(header.getMsgDate());
            assignmentRequest.setTransactionDate(header.getTransactionDate());
            assignmentRequest.setTransactionGuid(header.getTransactionGuid());
            assignmentRequest.setTransactionType(header.getTransactionType());
            assignmentRequest.setTransactionPassThoughId(header.getTransactionPassThroughId());
            assignmentRequest.setTransactionContractId(header.getTransactionContractId());
            assignmentRequest.setTransactionUserId(header.getTransactionUserId());
            assignmentRequest.setTransactionTsdId(header.getTransactionTsdId());
            log.info("ServiceMapper extract policy from CloudApi " + claim.getData().getAttributes().getPolicyNumber(),new Object(){}.getClass().getEnclosingMethod().getName());
            PolicyDetails policyDetails = new PolicyDetails();
            Policy policy = claim.getIncluded().getPolicies().stream().filter(e-> e.getAttributes().getPolicyNumber().equalsIgnoreCase(claim.getData().getAttributes().getPolicyNumber())).findFirst().orElse(null);
            // Mapping Incurance company to Policy Company
            policyDetails.setInsuranceCompany(AppUtils.stringSizeRefactoring(claim.getData().getAttributes().getCompanyName_Ext().getName(), 35));
            policyDetails.setPolicyNumber(AppUtils.stringSizeRefactoring(policy.getAttributes().getPolicyNumber(), 25) );
            policyDetails.setDailyMaxCoverage(Double.parseDouble(serviceRequest.getAttributes().getHertzRentalDailyAmount_Ext().getAmount()));
            policyDetails.setMaxCoverage(Double.parseDouble(serviceRequest.getAttributes().getHertzMaxAuthAmount_Ext().getAmount()));// CM-8713
            log.info("ServiceMapper extract insured from CloudApi " + claim.getData().getAttributes().getInsured().getDisplayName() + " " + claim.getData().getAttributes().getInsured().getId(),new Object(){}.getClass().getEnclosingMethod().getName());
            ClaimContact insured = claim.getIncluded().getClaimContacts().stream().filter(e-> e.getAttributes().getId().equalsIgnoreCase(claim.getData().getAttributes().getInsured().getId())).findFirst().orElse(null);
            if (insured != null) {
                if (insured.getAttributes().getLastName() != null) {
                    policyDetails.setInsuredFirstName(AppUtils.stringSizeRefactoring(insured.getAttributes().getFirstName(), 25));
                    policyDetails.setInsuredLastName(AppUtils.stringSizeRefactoring(insured.getAttributes().getLastName(), 35));

                }
                //If insured is company then sending its name in first name
                else if (insured.getAttributes().getCompanyName() != null) {
                    policyDetails.setInsuredFirstName(AppUtils.stringSizeRefactoring(insured.getAttributes().getCompanyName(), 25));
                }
            }
            policyDetails.setPercentPay(Double.parseDouble(serviceRequest.getAttributes().getHertzPercentagePay_Ext()));
            if(serviceRequest.getAttributes().isHertzCustomerSelfPay_Ext()){
                policyDetails.setPercentPay(0);
                policyDetails.setDailyMaxCoverage(0);
                policyDetails.setMaxCoverage(0);

            }
            assignmentRequest.setPolicy(policyDetails);

            ClaimInfoDetails claimInfoDetails =new ClaimInfoDetails();
            claimInfoDetails.setId(AppUtils.stringSizeRefactoring(claim.getData().getAttributes().getClaimNumber(), 50) );
            claimInfoDetails.setFrpFlag(true);
            claimInfoDetails.setType(ReservationHelper.getClaimType(serviceRequest));
            ServiceRequestList.Entity vehicleRentalIncident = serviceRequest.getAttributes().getIncident();
            log.info("ServiceMapper extract vehicleIncident  from CloudApi " + vehicleRentalIncident.getDisplayName() + " " + vehicleRentalIncident.getId(),new Object(){}.getClass().getEnclosingMethod().getName());
            VehicleIncident vehicleIncident = claim.getIncluded().getVehicleIncidents().stream().filter(e-> e.getAttributes().getId().equalsIgnoreCase(vehicleRentalIncident.getId())).findFirst().orElse(null);
            if(vehicleIncident!=null){
                claimInfoDetails.setClaimVehicleColor(AppUtils.stringSizeRefactoring(vehicleIncident.getAttributes().getVehicle().getColor(),20) );
                claimInfoDetails.setClaimVehicleId(AppUtils.stringSizeRefactoring(vehicleIncident.getAttributes().getVehicle().getLicensePlate(),30) );
                claimInfoDetails.setClaimVehicleMake(AppUtils.stringSizeRefactoring(vehicleIncident.getAttributes().getVehicle().getMake(),50));
                claimInfoDetails.setClaimVehicleModel(AppUtils.stringSizeRefactoring(vehicleIncident.getAttributes().getVehicle().getModel(),50));
                claimInfoDetails.setClaimVehicleYear(AppUtils.stringSizeRefactoring(String.valueOf(vehicleIncident.getAttributes().getVehicle().getYear()),4) );
                //If driver is not present then custodian details should be mapped
                if ((vehicleIncident.getAttributes().getDriver() != null && vehicleIncident.getAttributes().getDriver().getId() != null) ||
                        (vehicleIncident.getAttributes().getCustodian_Ext() != null && vehicleIncident.getAttributes().getCustodian_Ext().getId() != null)) {

                    ClaimContact claimContactDriver = null;
                    if (vehicleIncident.getAttributes().getDriver() != null) {
                        log.info("ServiceMapper extract claim Contact Driver  from CloudApi " + vehicleIncident.getAttributes().getDriver().getDisplayName() + " " + vehicleIncident.getAttributes().getDriver().getId(), new Object() {
                        }.getClass().getEnclosingMethod().getName());
                        claimContactDriver = claim.getIncluded().getClaimContacts().stream().filter(e -> e.getAttributes().getId().equalsIgnoreCase(vehicleIncident.getAttributes().getDriver().getId())).findFirst().orElse(null);
                    } else if (vehicleIncident.getAttributes().getCustodian_Ext() != null) {
                        log.info("ServiceMapper extract claim Contact Custodian  from CloudApi " + vehicleIncident.getAttributes().getCustodian_Ext().getDisplayName() + " " + vehicleIncident.getAttributes().getCustodian_Ext().getId(), new Object() {
                        }.getClass().getEnclosingMethod().getName());
                        claimContactDriver = claim.getIncluded().getClaimContacts().stream().filter(e -> e.getAttributes().getId().equalsIgnoreCase(vehicleIncident.getAttributes().getCustodian_Ext().getId())).findFirst().orElse(null);
                    }

                    if(claimContactDriver!=null){
                        claimInfoDetails.setDriverFirstName(AppUtils.stringSizeRefactoring(claimContactDriver.getAttributes().getFirstName(),25) );
                        claimInfoDetails.setDriverLastName(AppUtils.stringSizeRefactoring(claimContactDriver.getAttributes().getLastName(),35));
                        if(claimContactDriver.getAttributes().getPrimaryPhone()!=null && claimContactDriver.getAttributes().getPrimaryPhone().lastIndexOf("x")!=-1){
                            String[] phone = claimContactDriver.getAttributes().getPrimaryPhone().split("x");//Check if phone has extension on json field "primaryPhone": "619-275-2346 x1234"
                            claimInfoDetails.setDriverPhone(AppUtils.stringSizeRefactoring(phone[0].trim(),12) );
                            claimInfoDetails.setDriverPhoneExt(AppUtils.stringSizeRefactoring(phone[1].trim(),5) );
                        }else{
                            claimInfoDetails.setDriverPhone(AppUtils.stringSizeRefactoring(claimContactDriver.getAttributes().getPrimaryPhone(),12)  );
                            claimInfoDetails.setDriverPhoneExt("");
                        }
                        log.info("ServiceMapper extract claim Contact Driver or custodian details from CloudApi " + claim.getData().getAttributes().getId() + "  / " + claimContactDriver.getAttributes().getId(),new Object(){}.getClass().getEnclosingMethod().getName());

                        ClaimContactData claimContactDriverDetails = reservationHelper.findContact(claim.getData().getAttributes().getId(),claimContactDriver.getAttributes().getId());
                        if(claimContactDriverDetails!=null){
                            if(claimContactDriverDetails.getData().getAttributes().getPrimaryAddress()!=null){
                                claimInfoDetails.setDriverStreet1(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getPrimaryAddress().getAddressLine1(),35));
                                claimInfoDetails.setDriverStreet2(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getPrimaryAddress().getAddressLine2(),35));
                                claimInfoDetails.setDriverCity(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getPrimaryAddress().getCity(),30));
                                if (claimContactDriverDetails.getData().getAttributes().getPrimaryAddress().getCountry().equals(CountryCode.CA.getCode())) {
                                    claimInfoDetails.setDriverState( AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getPrimaryAddress().getProvince().getCode(),5));
                                }else
                                    claimInfoDetails.setDriverState( AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getPrimaryAddress().getState().getCode(),5));

                                claimInfoDetails.setDriverCountry(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getPrimaryAddress().getCountry(),5) );
                                claimInfoDetails.setDriverZip(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getPrimaryAddress().getPostalCode(),15) );
                            }
                        }
                    }
                }
            }
            claimInfoDetails.setLossDate( AppUtils.stringSizeRefactoring(claim.getData().getAttributes().getLossDate(),30));
            claimInfoDetails.setClaimVehicleCondition(serviceRequest.getAttributes().getHertzVehicleCondition_Ext());
            claimInfoDetails.setPayDailyAmount(Double.parseDouble(serviceRequest.getAttributes().getHertzRentalDailyAmount_Ext().getAmount()));
            claimInfoDetails.setPayTaxes(ReservationHelper.getDefaultPayTaxes(serviceRequest));
            claimInfoDetails.setPayTotalBill(serviceRequest.getAttributes().isHertzCustomerSelfPay_Ext() ? "1" : "0");
            claimInfoDetails.setRentalDailyAmount(Double.parseDouble(serviceRequest.getAttributes().getHertzRentalDailyAmount_Ext().getAmount()));
            claimInfoDetails.setTotalDays(serviceRequest.getAttributes().getHertzTotalDaysApproved_Ext());
            claimInfoDetails.setRentalRequestedClass(serviceRequest.getAttributes().getHertzClassCode_Ext());
            claimInfoDetails.setClaimNoteRentalInstructions(AppUtils.stringSizeRefactoring(serviceRequest.getAttributes().getInstruction().getInstructionText(),500));
            claimInfoDetails.setIncrementalDays(serviceRequest.getAttributes().getHertzIncrementalDays_Ext());
            claimInfoDetails.setAuthFinalDate(serviceRequest.getAttributes().getHertzFinalDay_Ext()!=null ? serviceRequest.getAttributes().getHertzFinalDay_Ext() : Converter.parseDateToJSONTimeZone(new Date()));
            claimInfoDetails.setAdditionalCharges(new ArrayList<AdditionalCharges>());
            if(serviceRequest.getAttributes().isHertzCustomerSelfPay_Ext()){
                claimInfoDetails.setTotalDays(0);
                claimInfoDetails.setPayDailyAmount(claimInfoDetails.getRentalDailyAmount());
                claimInfoDetails.setPayTotalBill("0");
            }

            ArrayList additionalCharges = new ArrayList<AdditionalCharges>();
            if(serviceRequest.getAttributes().isHertzLossDamageWaiver_Ext()){
                AdditionalCharges ldw = new AdditionalCharges();
                ldw.setCode(AdditionalChargeType.LOST_DAMAGE_WAIVER.getCode());
                ldw.setDescription(AdditionalChargeType.LOST_DAMAGE_WAIVER.getName());
                ldw.setIndicator(true);
                additionalCharges.add(ldw);
            }
            //CM-8714-Enable winter tires logic as per discussion with Hertz Team
              if(serviceRequest.getAttributes().isHertzWinterTires_Ext()){
                //if(claimInfoDetails.getAdditionalCharges()==null){
                   // claimInfoDetails.setAdditionalCharges(new ArrayList<>());
                   AdditionalCharges ldw = new AdditionalCharges();
                   ldw.setCode(AdditionalChargeType.WINTER_TIRES.getCode());
                   ldw.setDescription(AdditionalChargeType.WINTER_TIRES.getName());
                   ldw.setIndicator(true);
				    additionalCharges.add(ldw);
                  // claimInfoDetails.getAdditionalCharges().add(ldw);
              //  }
             }
            claimInfoDetails.setAdditionalCharges(additionalCharges);
            assignmentRequest.setClaimInfo(claimInfoDetails);
            ClaimAdjusterDetails claimAdjusterDetails = new ClaimAdjusterDetails();
            log.info("ServiceMapper extract user Assigned  details from CloudApi " + serviceRequest.getAttributes().getHertzAdjuster_Ext().getDisplayName() + "  / " + serviceRequest.getAttributes().getHertzAdjuster_Ext().getId(),new Object(){}.getClass().getEnclosingMethod().getName());

            User userAssigned = reservationHelper.findUserAssigned(serviceRequest);
            if(userAssigned!=null){
                if(userAssigned.getData().getAttributes().getHertzExternalID_Ext()!=null && !userAssigned.getData().getAttributes().getHertzExternalID_Ext().isEmpty())
                    claimAdjusterDetails.setId(AppUtils.stringSizeRefactoring(userAssigned.getData().getAttributes().getHertzExternalID_Ext(),15));
                   else
                    claimAdjusterDetails.setId(AppUtils.stringSizeRefactoring(userAssigned.getData().getAttributes().getUsername(),15));

                claimAdjusterDetails.setFirstName(AppUtils.stringSizeRefactoring(userAssigned.getData().getAttributes().getFirstName(),25));
                claimAdjusterDetails.setLastName(AppUtils.stringSizeRefactoring(userAssigned.getData().getAttributes().getLastName(),35));
                claimAdjusterDetails.setEmail(AppUtils.stringSizeRefactoring(userAssigned.getData().getAttributes().getHertzUserEmail_Ext(),40));
                if(userAssigned.getData().getAttributes().getHertzUserPrimaryPhone_Ext()!=null && userAssigned.getData().getAttributes().getHertzUserPrimaryPhone_Ext().lastIndexOf("x")!=-1){
                    String[] phone = userAssigned.getData().getAttributes().getHertzUserPrimaryPhone_Ext().split("x");//Check if phone has extension on json field "primaryPhone": "619-275-2346 x1234"
                    claimAdjusterDetails.setPhone(AppUtils.stringSizeRefactoring(phone[0].trim(),12));
                    claimAdjusterDetails.setPhoneExt(AppUtils.stringSizeRefactoring(phone[1].trim(),5));
                }else{
                    claimAdjusterDetails.setPhone(AppUtils.stringSizeRefactoring(userAssigned.getData().getAttributes().getHertzUserPrimaryPhone_Ext(),12));
                    claimAdjusterDetails.setPhoneExt("");
                }
            }

            assignmentRequest.setClaimAdjuster(claimAdjusterDetails);

            log.info("ServiceMapper extract claim Office Details Policy Agent from CloudApi ",new Object(){}.getClass().getEnclosingMethod().getName());
            ClaimOfficeDetails claimOfficeDetails = new ClaimOfficeDetails();
            claimOfficeDetails.setId((AppUtils.stringSizeRefactoring(claim.getData().getAttributes().getCompanyName_Ext().getCode(), 20)));
            claimOfficeDetails.setName(AppUtils.stringSizeRefactoring(claim.getData().getAttributes().getCompanyName_Ext().getName(), 50));
            claimOfficeDetails.setHertzCDP("");

            if (serviceRequest.getAttributes().getHertzAdjuster_Ext()!= null) {
                log.info("ServiceMapper extract adjuster from CloudApi " +  serviceRequest.getAttributes().getHertzAdjuster_Ext().getDisplayName()+ "  / " +  serviceRequest.getAttributes().getHertzAdjuster_Ext().getId(),new Object(){}.getClass().getEnclosingMethod().getName());

                if(userAssigned!=null && userAssigned.getData().getAttributes()!=null &&  userAssigned.getData().getAttributes().getHertzUserPrimaryPhone_Ext()!=null &&  userAssigned.getData().getAttributes().getHertzUserPrimaryPhone_Ext().lastIndexOf("x")!=-1){
                    String[] phone =  userAssigned.getData().getAttributes().getHertzUserPrimaryPhone_Ext().split("x");//Check if phone has extension on json field "primaryPhone": "619-275-2346 x1234"
                    claimOfficeDetails.setPhone(AppUtils.stringSizeRefactoring(phone[0].trim(),12));
                    claimOfficeDetails.setPhoneExt(AppUtils.stringSizeRefactoring(phone[1].trim(),5));
                }else{
                    claimOfficeDetails.setPhone(AppUtils.stringSizeRefactoring(userAssigned.getData().getAttributes().getHertzUserPrimaryPhone_Ext(),12));
                    claimOfficeDetails.setPhoneExt("");
                }

                Address adjusterAddress = userAssigned.getData().getAttributes().getPrimaryAddress();
                log.info("ServiceMapper extract adjuster address Data from CloudApi " +adjusterAddress.getDisplayName() + "  / " + adjusterAddress.getId(),new Object(){}.getClass().getEnclosingMethod().getName());
                if(adjusterAddress!=null){
                    claimOfficeDetails.setStreet1(AppUtils.stringSizeRefactoring(adjusterAddress.getAddressLine1(),35));
                    claimOfficeDetails.setStreet2(AppUtils.stringSizeRefactoring(adjusterAddress.getAddressLine2(),35));
                    claimOfficeDetails.setCity(AppUtils.stringSizeRefactoring(adjusterAddress.getCity(),30));
                    if (adjusterAddress.getCountry().equals(CountryCode.CA.getCode())) {
                        claimOfficeDetails.setState(AppUtils.stringSizeRefactoring(adjusterAddress.getProvince().getCode(),5));
                    }
                    else
                        claimOfficeDetails.setState(AppUtils.stringSizeRefactoring(adjusterAddress.getState().getCode(),5));

                    claimOfficeDetails.setZip(AppUtils.stringSizeRefactoring(adjusterAddress.getPostalCode(),15));
                }
            }
            claimOfficeDetails.setEmail(AppUtils.stringSizeRefactoring(userAssigned.getData().getAttributes().getHertzUserEmail_Ext(),40));
            claimOfficeDetails.setDefaultContactName(AppUtils.stringSizeRefactoring(serviceRequest.getAttributes().getHertzAdjuster_Ext().getDisplayName(), 40) );
            assignmentRequest.setClaimOffice(claimOfficeDetails);

            RentalInfoDetails rentalInfoDetails = new RentalInfoDetails();
            rentalInfoDetails.setPartnerCode(assignmentRequest.getTransactionTsdId()!=null ? AppUtils.stringSizeRefactoring(assignmentRequest.getTransactionTsdId(),20) : reservationHelper.getDefaultSource());
            rentalInfoDetails.setVendorName(AppUtils.stringSizeRefactoring(serviceRequest.getAttributes().getHertzRentalLocation_Ext().getDisplayName(),30));
            log.info("ServiceMapper extract Rental Location Contact from CloudApi " + serviceRequest.getAttributes().getHertzRentalLocation_Ext().getDisplayName() + "  / " + serviceRequest.getAttributes().getHertzRentalLocation_Ext().getId(),new Object(){}.getClass().getEnclosingMethod().getName());

            ClaimContactData specialistContact =reservationHelper.findContact(claim.getData().getAttributes().getId(), serviceRequest.getAttributes().getHertzRentalLocation_Ext().getId());
            if(specialistContact!=null){
                rentalInfoDetails.setVendorOfficeId(AppUtils.stringSizeRefactoring(specialistContact.getData().getAttributes().getHertzIDStoreOffice_Ext(),15));
                if(specialistContact.getData().getAttributes().getPrimaryAddress()!=null){
                    rentalInfoDetails.setVendorOfficeStreet1(AppUtils.stringSizeRefactoring(specialistContact.getData().getAttributes().getPrimaryAddress().getAddressLine1(),35));
                    rentalInfoDetails.setVendorOfficeStreet2(AppUtils.stringSizeRefactoring(specialistContact.getData().getAttributes().getPrimaryAddress().getAddressLine2(),35));
                    rentalInfoDetails.setVendorOfficeCity(AppUtils.stringSizeRefactoring(specialistContact.getData().getAttributes().getPrimaryAddress().getCity(),30));
                    if (specialistContact.getData().getAttributes().getPrimaryAddress().getCountry().equals(CountryCode.CA.getCode())) {
                        rentalInfoDetails.setVendorOfficeStateId(AppUtils.stringSizeRefactoring(specialistContact.getData().getAttributes().getPrimaryAddress().getProvince().getCode(),30));
                    }
                    else
                        rentalInfoDetails.setVendorOfficeStateId(AppUtils.stringSizeRefactoring(specialistContact.getData().getAttributes().getPrimaryAddress().getState().getCode(),30));

                    rentalInfoDetails.setVendorOfficeZip(AppUtils.stringSizeRefactoring(specialistContact.getData().getAttributes().getPrimaryAddress().getPostalCode(),30));
                    if(specialistContact.getData().getAttributes().getPrimaryPhone()!=null && specialistContact.getData().getAttributes().getPrimaryPhone().lastIndexOf("x")!=-1){
                        String[] phone = specialistContact.getData().getAttributes().getPrimaryPhone().split("x");//Check if phone has extension on json field "primaryPhone": "619-275-2346 x1234"
                        rentalInfoDetails.setVendorOfficePhone(AppUtils.stringSizeRefactoring(phone[0],12));
                    }else{
                        rentalInfoDetails.setVendorOfficePhone("");
                    }
                }
            }
            if(serviceRequest.getAttributes().getHertzTransactionContractID_Ext() != null)
                rentalInfoDetails.setContractId(AppUtils.stringSizeRefactoring(serviceRequest.getAttributes().getHertzTransactionContractID_Ext(),20));
            if(serviceRequest.getAttributes().getHertzContractStatus_Ext() != null)
                rentalInfoDetails.setContractStatus(AppUtils.stringSizeRefactoring(serviceRequest.getAttributes().getHertzContractStatus_Ext().getName(),30));
            rentalInfoDetails.setNoteSend(AppUtils.stringSizeRefactoring(serviceRequest.getAttributes().getInstruction().getInstructionText(),500));
            rentalInfoDetails.setPickupDate(serviceRequest.getAttributes().getHertzPickupDate_Ext());
            rentalInfoDetails.setRatePerDayAmount(new BigDecimal(serviceRequest.getAttributes().getHertzRentalDailyAmount_Ext().getAmount()));
            rentalInfoDetails.setStartDate(serviceRequest.getAttributes().getHertzRentalBeginDate_Ext());
            rentalInfoDetails.setEndDate(serviceRequest.getAttributes().getHertzRentalEndDate_Ext());
            rentalInfoDetails.setRateClass(AppUtils.stringSizeRefactoring(serviceRequest.getAttributes().getHertzRateClass_Ext(),5));
            rentalInfoDetails.setVehicleClass(AppUtils.stringSizeRefactoring(serviceRequest.getAttributes().getHertzClassCode_Ext(),5));
            //Empty values for assignment
            rentalInfoDetails.setVehicleColor("");
            rentalInfoDetails.setVehicleId("");
            rentalInfoDetails.setVehicleMake("");
            rentalInfoDetails.setVehicleModel("");
            rentalInfoDetails.setVehicleYear("");

            if (vehicleIncident != null) {
                if ((vehicleIncident.getAttributes().getDriver() != null && vehicleIncident.getAttributes().getDriver().getId() != null) ||
                        (vehicleIncident.getAttributes().getCustodian_Ext() != null && vehicleIncident.getAttributes().getCustodian_Ext().getId() != null)) {

                    ClaimContact claimContactDriver = null;
                    if (vehicleIncident.getAttributes().getDriver() != null) {
                        log.info("ServiceMapper extract claim ContactDriver from CloudApi " + vehicleIncident.getAttributes().getDriver().getDisplayName() + "  / " + vehicleIncident.getAttributes().getDriver().getId(), new Object() {
                        }.getClass().getEnclosingMethod().getName());
                        claimContactDriver = claim.getIncluded().getClaimContacts().stream().filter(e -> e.getAttributes().getId().equalsIgnoreCase(vehicleIncident.getAttributes().getDriver().getId())).findFirst().orElse(null);
                    } else if (vehicleIncident.getAttributes().getCustodian_Ext() != null) {
                        log.info("ServiceMapper extract claim Contact Custodian  from CloudApi " + vehicleIncident.getAttributes().getCustodian_Ext().getDisplayName() + " " + vehicleIncident.getAttributes().getCustodian_Ext().getId(), new Object() {
                        }.getClass().getEnclosingMethod().getName());
                        claimContactDriver = claim.getIncluded().getClaimContacts().stream().filter(e -> e.getAttributes().getId().equalsIgnoreCase(vehicleIncident.getAttributes().getCustodian_Ext().getId())).findFirst().orElse(null);
                    }
                    if (claimContactDriver != null) {
                        rentalInfoDetails.setDriverFirstName(AppUtils.stringSizeRefactoring(claimContactDriver.getAttributes().getFirstName(), 25));
                        rentalInfoDetails.setDriverLastName(AppUtils.stringSizeRefactoring(claimContactDriver.getAttributes().getLastName(), 35));
                        if (claimContactDriver.getAttributes().getPrimaryPhone() != null && claimContactDriver.getAttributes().getPrimaryPhone().lastIndexOf("x") != -1) {
                            String[] phone = claimContactDriver.getAttributes().getPrimaryPhone().split("x");//Check if phone has extension on json field "primaryPhone": "619-275-2346 x1234"
                            rentalInfoDetails.setDriverBestPhone(AppUtils.stringSizeRefactoring(phone[0].trim(), 20));
                            rentalInfoDetails.setDriverBestPhone(AppUtils.stringSizeRefactoring(phone[1].trim(), 5));
                        } else {
                            rentalInfoDetails.setDriverBestPhoneExt("");
                        }
                        log.info("ServiceMapper extract claim Contact Driver Details from CloudApi " + claimContactDriver.getAttributes().getDisplayName() + "  / " + claimContactDriver.getAttributes().getId(), new Object() {
                        }.getClass().getEnclosingMethod().getName());

                        ClaimContactData claimContactDriverDetails = reservationHelper.findContact(claim.getData().getAttributes().getId(), claimContactDriver.getAttributes().getId());
                        if (claimContactDriverDetails != null) {
                            if (claimContactDriverDetails.getData().getAttributes().getPrimaryAddress() != null) {
                                rentalInfoDetails.setDriverAddress1(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getPrimaryAddress().getAddressLine1(), 35));
                                rentalInfoDetails.setDriverAddress2(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getPrimaryAddress().getAddressLine2(), 35));
                                rentalInfoDetails.setDriverCity(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getPrimaryAddress().getCity(), 30));
                                if (claimContactDriverDetails.getData().getAttributes().getPrimaryAddress().getCountry().equals(CountryCode.CA.getCode())) {
                                    rentalInfoDetails.setDriverState(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getPrimaryAddress().getProvince().getCode(), 5));
                                } else
                                    rentalInfoDetails.setDriverState(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getPrimaryAddress().getState().getCode(), 5));

                                rentalInfoDetails.setDriverZip(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getPrimaryAddress().getPostalCode(), 15));
                                rentalInfoDetails.setDriverEmail(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getEmailAddress1(), 40));

                                if (claimContactDriverDetails.getData().getAttributes().getHomePhone() != null) {
                                    rentalInfoDetails.setDriverHomePhone(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getHomePhone().getNumber(), 20));
                                    rentalInfoDetails.setDriverHomePhoneExt(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getHomePhone().getExtension(), 5));
                                }
                                if (claimContactDriverDetails.getData().getAttributes().getWorkPhone() != null) {
                                    rentalInfoDetails.setDriverHomePhone(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getWorkPhone().getNumber(), 20));
                                    rentalInfoDetails.setDriverHomePhoneExt(AppUtils.stringSizeRefactoring(claimContactDriverDetails.getData().getAttributes().getWorkPhone().getExtension(), 5));
                                }
                            }
                        }
                    }
                }
            }
            assignmentRequest.setRentalInfo(rentalInfoDetails);

            if(serviceRequest.getAttributes().getHertzRepairFacility_Ext() != null){
                RepairFacility repairFacility = new RepairFacility();
                log.info("ServiceMapper extract claim Contact Driver Details from CloudApi " +  serviceRequest.getAttributes().getHertzRepairFacility_Ext().getId(),new Object(){}.getClass().getEnclosingMethod().getName());

                ClaimContactData claimContactRepairFacility = reservationHelper.findContact(claim.getData().getAttributes().getId(),serviceRequest.getAttributes().getHertzRepairFacility_Ext().getId());
                if(claimContactRepairFacility!=null){
                    repairFacility.setId(AppUtils.stringSizeRefactoring(claimContactRepairFacility.getData().getAttributes().getId(),40));
                    repairFacility.setOrderId("");
                    repairFacility.setPurchaseOrder("");
                    repairFacility.setName(AppUtils.stringSizeRefactoring(claimContactRepairFacility.getData().getAttributes().getDisplayName(),40));
                    repairFacility.setEmail(AppUtils.stringSizeRefactoring(claimContactRepairFacility.getData().getAttributes().getEmailAddress1(),40));
                    repairFacility.setStreet1(AppUtils.stringSizeRefactoring(claimContactRepairFacility.getData().getAttributes().getPrimaryAddress().getAddressLine1(),35));
                    repairFacility.setStreet2(AppUtils.stringSizeRefactoring(claimContactRepairFacility.getData().getAttributes().getPrimaryAddress().getAddressLine2(),35));
                    repairFacility.setCity(AppUtils.stringSizeRefactoring(claimContactRepairFacility.getData().getAttributes().getPrimaryAddress().getCity(),30));
                    if (claimContactRepairFacility.getData().getAttributes().getPrimaryAddress().getCountry().equals(CountryCode.CA.getCode())) {
                        repairFacility.setState(AppUtils.stringSizeRefactoring(claimContactRepairFacility.getData().getAttributes().getPrimaryAddress().getProvince().getCode(),5));
                    }
                    else
                        repairFacility.setState(AppUtils.stringSizeRefactoring(claimContactRepairFacility.getData().getAttributes().getPrimaryAddress().getState().getCode(),5));
                    repairFacility.setCountry(AppUtils.stringSizeRefactoring(claimContactRepairFacility.getData().getAttributes().getPrimaryAddress().getCountry(),30));
                    repairFacility.setZip(AppUtils.stringSizeRefactoring(claimContactRepairFacility.getData().getAttributes().getPrimaryAddress().getPostalCode(),15));
                    repairFacility.setAppointmentDate(null);
                    repairFacility.setContactLastName(AppUtils.stringSizeRefactoring(claimContactRepairFacility.getData().getAttributes().getDisplayName(),35));
                    repairFacility.setContactPhone(AppUtils.stringSizeRefactoring(claimContactRepairFacility.getData().getAttributes().getWorkPhone().getDisplayName(),20));
                    repairFacility.setPhone(AppUtils.stringSizeRefactoring(claimContactRepairFacility.getData().getAttributes().getWorkPhone().getDisplayName(),20));
                    repairFacility.setTotalLaborHours(0);
                    repairFacility.setRepairOrder(null);
                }
                assignmentRequest.setRepairFacility(repairFacility);
            }
        }catch (Exception e) {
            log.error("Error ServiceMapper - " + e.getMessage(), "process", e);
            throw e;
        }
        finally{
            if(header.getTransactionType().toLowerCase().equals(TransactionType.CANCEL.getCode().toLowerCase())
                    ||header.getTransactionType().toLowerCase().equals(TransactionType.NEW_ASSIGNMENT.getCode().toLowerCase())){
                assignmentRequest.getClaimInfo().setAuthFinalDate(null);
            }
        }
        return assignmentRequest;
    }

    public String getUserHertz(AppProperty properties){
        return  reservationHelper.getUser(properties.getUserNameTSD());
    }

}
