package acc.hertz.model.cloudapi.claim;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public  class User {

    @JsonProperty("data")
    private Data data;
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Data {
        @JsonProperty("attributes")
        private Attributes attributes;
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Attributes {
        @JsonProperty("hertzUserEmail_Ext")
        private String hertzUserEmail_Ext;

        @JsonProperty("hertzUserPrimaryPhone_Ext")
        private String hertzUserPrimaryPhone_Ext;

        @JsonProperty("hertzExternalID_Ext")
        private String hertzExternalID_Ext;


        @JsonProperty("displayName")
        private String displayName;

        @JsonProperty("firstName")
        private String firstName;

        @JsonProperty("id")
        private String id;

        @JsonProperty("lastName")
        private String lastName;

        @JsonProperty("username")
        private String username;

        @JsonProperty("primaryAddress")
        private Address primaryAddress;
    }
}
