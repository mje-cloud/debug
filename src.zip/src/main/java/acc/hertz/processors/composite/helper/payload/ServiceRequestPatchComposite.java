package acc.hertz.processors.composite.helper.payload;

import acc.hertz.model.cloudapi.composite.core.BaseBody;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ServiceRequestPatchComposite extends BaseBody {
    @JsonProperty("data")
    private Data data;

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Setter
    @Getter
    public static class Data {
        @JsonProperty("attributes")
        private Attributes attributes;

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Setter
        @Getter
        public static class Attributes {

            @JsonProperty("hertzRequestType_Ext")
            private boolean hertzRequestType_Ext;
            @JsonProperty("hertzTransactionGUID_Ext")
            private String hertzTransactionGUID_Ext;
            @JsonProperty("hertzTransactionTSDID_Ext")
            private String hertzTransactionTSDID_Ext;
            @JsonProperty("hertzTransactionContractID_Ext")
            private String hertzTransactionContractID_Ext;
            @JsonProperty("hertzFinalDay_Ext")
            private String hertzFinalDay_Ext;
            @JsonProperty("hertzContractStatus_Ext")
            private CodeName hertzContractStatus_Ext;
            @JsonProperty("hertzTotalDaysApproved_Ext")
            private int hertzTotalDaysApproved_Ext;
            @JsonProperty("hertzIncrementalDays_Ext")
            private int hertzIncrementalDays_Ext;
            @JsonProperty("hertzRentalEndDate_Ext")
            private String hertzRentalEndDate_Ext;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class CodeName {
        @JsonProperty("code")
        private String code;
        @JsonProperty("name")
        private String name;
    }
}
