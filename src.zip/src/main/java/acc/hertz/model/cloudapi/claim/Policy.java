package acc.hertz.model.cloudapi.claim;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Policy {

    @JsonProperty("attributes")
    private Attributes attributes;


    public Attributes getAttributes() {
        return attributes;
    }

    public void setAttributes(Attributes attributes) {
        this.attributes = attributes;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Attributes {
        public String getAccountNumber() {
            return accountNumber;
        }

        public void setAccountNumber(String accountNumber) {
            this.accountNumber = accountNumber;
        }

        public String getCancellationDate() {
            return cancellationDate;
        }

        public void setCancellationDate(String cancellationDate) {
            this.cancellationDate = cancellationDate;
        }

        public String getEffectiveDate() {
            return effectiveDate;
        }

        public void setEffectiveDate(String effectiveDate) {
            this.effectiveDate = effectiveDate;
        }

        public String getExpirationDate() {
            return expirationDate;
        }

        public void setExpirationDate(String expirationDate) {
            this.expirationDate = expirationDate;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public Insured getInsured() {
            return insured;
        }

        public void setInsured(Insured insured) {
            this.insured = insured;
        }

        public String getOriginalEffectiveDate() {
            return originalEffectiveDate;
        }

        public void setOriginalEffectiveDate(String originalEffectiveDate) {
            this.originalEffectiveDate = originalEffectiveDate;
        }

        public String getPolicyNumber() {
            return policyNumber;
        }

        public void setPolicyNumber(String policyNumber) {
            this.policyNumber = policyNumber;
        }

        public PolicyType getPolicyType() {
            return policyType;
        }

        public void setPolicyType(PolicyType policyType) {
            this.policyType = policyType;
        }

        public UnderwritingCo getUnderwritingCo() {
            return underwritingCo;
        }

        public void setUnderwritingCo(UnderwritingCo underwritingCo) {
            this.underwritingCo = underwritingCo;
        }

        public UnderwritingGroup getUnderwritingGroup() {
            return underwritingGroup;
        }

        public void setUnderwritingGroup(UnderwritingGroup underwritingGroup) {
            this.underwritingGroup = underwritingGroup;
        }

        public boolean isVerifiedPolicy() {
            return verifiedPolicy;
        }

        public void setVerifiedPolicy(boolean verifiedPolicy) {
            this.verifiedPolicy = verifiedPolicy;
        }

        private void writeObject(ObjectOutputStream oos) throws IOException {
            throw new NotSerializableException("Serialization is not supported on this object!");
        }

        private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
            throw new NotSerializableException("Serialization is not supported on this object!");
        }

        @JsonProperty("accountNumber")
        private String accountNumber;

        @JsonProperty("cancellationDate")
        private String cancellationDate;

        @JsonProperty("effectiveDate")
        private String effectiveDate;

        @JsonProperty("expirationDate")
        private String expirationDate;

        @JsonProperty("id")
        private String id;

        @JsonProperty("insured")
        private Insured insured;

        @JsonProperty("agent")
        private Agent agent;

        @JsonProperty("originalEffectiveDate")
        private String originalEffectiveDate;

        @JsonProperty("policyNumber")
        private String policyNumber;

        @JsonProperty("policyType")
        private PolicyType policyType;

        @JsonProperty("underwritingCo")
        private UnderwritingCo underwritingCo;

        @JsonProperty("underwritingGroup")
        private UnderwritingGroup underwritingGroup;

        @JsonProperty("verifiedPolicy")
        private boolean verifiedPolicy;

    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Agent {

        @JsonProperty("displayName")
        private String displayName;

        @JsonProperty("id")
        private String id;

        @JsonProperty("type")
        private String type;

        @JsonProperty("uri")
        private String uri;

        // No setters or getters included, assuming Lombok will be used
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Insured {
        public String getDisplayName() {
            return displayName;
        }

        public void setDisplayName(String displayName) {
            this.displayName = displayName;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        @JsonProperty("displayName")
        private String displayName;

        @JsonProperty("id")
        private String id;

        @JsonProperty("type")
        private String type;

        // Constructor, getters, and setters
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class PolicyType {
        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        @JsonProperty("code")
        private String code;

        // Constructor, getters, and setters
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class  UnderwritingCo {
        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        @JsonProperty("code")
        private String code;

        @JsonProperty("name")
        private String name;

        // Constructor, getters, and setters
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class UnderwritingGroup {
        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        @JsonProperty("code")
        private String code;

        @JsonProperty("name")
        private String name;

        // Constructor, getters, and setters
    }

}










