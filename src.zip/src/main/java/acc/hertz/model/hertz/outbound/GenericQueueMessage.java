package acc.hertz.model.hertz.outbound;

import acc.hertz.model.enums.ServiceRequestEventType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class GenericQueueMessage {

    @JsonProperty("id")
    private String id;

    @JsonProperty("claimId")
    private String claimId;

    @JsonProperty("serviceRequestId")
    private String serviceRequestId;

    @JsonProperty("appEventName")
    private ServiceRequestEventType appEventName;
}
