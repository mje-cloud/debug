package acc.hertz.processors.composite.helper.payload;

import acc.hertz.model.cloudapi.composite.core.BaseBody;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class ActivityPostComposite extends BaseBody {
    @JsonProperty("data")
    private Data data;


    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Data {
        @JsonProperty("attributes")
        private Attributes attributes;

    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Attributes {
        @JsonProperty("activityPattern")
        private String activityPattern;

        @JsonProperty("description")
        private String description;

        @JsonProperty("relatedTo")
        private RelatedTo relatedTo;

        @JsonProperty("subject")
        private String subject;

    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class AssignedUser {
        @JsonProperty("id")
        private String id;

    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class RelatedTo {
        @JsonProperty("id")
        private String id;

        @JsonProperty("type")
        private String type;
    }
}
