package acc.hertz.process;


import acc.hertz.client.composite.ICompositeClient;
import acc.hertz.model.activitypattern.ActivityPattern;
import acc.hertz.model.activitypattern.ActivityPost;
import acc.hertz.model.cloudapi.claim.ClaimContact;
import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.claim.Policy;
import acc.hertz.model.cloudapi.claim.VehicleIncident;
import acc.hertz.model.cloudapi.composite.core.CompositeResponse;
import acc.hertz.model.cloudapi.contact.ClaimContactData;
import acc.hertz.model.cloudapi.contact.ClaimContactPost;
import acc.hertz.model.cloudapi.contact.VendorContactData;
import acc.hertz.model.cloudapi.history.History;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestPost;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestPostResponse;
import acc.hertz.model.cloudapi.typelist.TypeLists;
import acc.hertz.model.enums.*;
import acc.hertz.model.hertz.outbound.BaseHertzRequest;
import acc.hertz.model.hertz.outbound.BaseHertzResponse;
import acc.hertz.processors.composite.CompositeResponseMapper;
import acc.hertz.processors.composite.helper.CompositeRentalWalkUpHelper;
import acc.hertz.processors.composite.helper.payload.ActivityPostComposite;
import acc.hertz.processors.composite.helper.payload.HistoryComposite;
import acc.hertz.processors.composite.helper.payload.ServiceRequestPostComposite;
import acc.hertz.util.AppUtils;
import acc.hertz.util.Converter;
import acc.hertz.util.TransformerFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import gw.api.ig.GwUtilities;
import org.apache.camel.Exchange;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

@Named
public class WalkUpOpenProcess {
    @Inject
    private ReservationHelper reservationHelper;
    @Inject
    private CompositeRentalWalkUpHelper compositeRentalWalkUpHelper;
    @Inject
    private ICompositeClient compositeClient;

    public BaseHertzResponse processNewReservation(BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception {
        BaseHertzResponse response = null;
        VehicleIncident vehicleIncident = new VehicleIncident();
        ClaimContact claimContactDriver = new ClaimContact();
        VendorContactData vendorCreated = new VendorContactData();
        ClaimContact repairFacility = new ClaimContact();
        ClaimContactData repairFacilityResponse = new ClaimContactData();
        ServiceRequestPostComposite serviceRequestPost = new ServiceRequestPostComposite();
        var _log = GwUtilities.get(exchange.getContext()).getLogUtils();
        try {
            /**
             * 1.2If Claim exist and is open state then continue with step 2
             *
             *     1.2.1 If claim condition are not match return a message error on log and trow an exception
             *               1.2.1.1 if claim do not exist  = Claim {id} not found
             *               if claim is not in open state =  Claim {id} is not in Open state
             */
            _log.info("Entering Class WalkUpOpenProcess,Entering Method processNewReservation "," ClaimNumber={baseHertzRequest.getClaimInfo().getId()},TransactionType={baseHertzRequest.getTransactionType()}");
            ClaimData claim = reservationHelper.findClaim(exchange, baseHertzRequest);
            //reservationHelper.findServiceRequestWithReservation(claim, baseHertzRequest, HistoryType.HERTZ_WALK_UP_AUTHORIZATION_ACC);

            /**
             * 2.Continue looking in cloud api using the claim id all vehicles incidents existing then extract each driver information to compare with the driver data
             * on TSD payload received and compare TSD claimInfo.driverFirstName and  claimInfo.driverLastName with all drivers on claims and return the first vehicle incident match.
             * 2.1 If no driver matches throw  exception with next message = Invalid driver information not matches with Claim Incident
             * 2.2 Continue step 3
             */
            //serviceRequestPost = new ServiceRequestPostComposite();
            serviceRequestPost.setData(new ServiceRequestPostComposite.Data());
            serviceRequestPost.getData().setAttributes(new ServiceRequestPostComposite.Attributes());


            /*  Below Code findDriverClaimContact is commented out,This is not required because VehicleIncident will be not filtered using Driver information
             * First VehicleIncident will be picked up and attached to Service Request
             */
           /*
             claimContactDriver = reservationHelper.findDriverClaimContact(claim, baseHertzRequest);
            if (claimContactDriver == null) {
                _log.info("Invalid or not found Incident with ClaimInfo section provided driver", new Object() {
                }.getClass().getEnclosingMethod().getName());
                throw new Exception("Invalid or not found Incident with ClaimInfo section provided driver");
            }*/

            vehicleIncident = reservationHelper.findVehicleIncident(claim);
            if (vehicleIncident != null) {
                _log.info("VehicleIncident is not null","vehicleIncident");

                serviceRequestPost.getData().getAttributes().setIncident(new ServiceRequestPostComposite.IDObject());
                serviceRequestPost.getData().getAttributes().getIncident().setId(vehicleIncident.getAttributes().getId());

                /**
                 * 3.Find on ClaimContact on cloudApi the contact field value on
                 * hertzIDStoreOffice_Ext  matches with tsd payload on rentalInfo.VendorOfficeId then compare the compare rentalInfo.VendorName
                 * with the company vendor name found on previous comparison.
                 *
                 */
                ClaimContact rentalLocationClaimContact = reservationHelper.findVendorOfficeClaimContact(claim, baseHertzRequest);

                if (rentalLocationClaimContact != null) {
                    /**
                     * 3.1 If condition matches retrieve the complete contact information for step 4.
                     */
                    serviceRequestPost.getData().getAttributes().setHertzRentalLocation_Ext(new ServiceRequestPostComposite.IDObject());
                    serviceRequestPost.getData().getAttributes().getHertzRentalLocation_Ext().setId(rentalLocationClaimContact.getAttributes().getInternalId_Ext());

                    // serviceRequestPost.getData().getAttributes().setSpecialist(new ServiceRequestPost.IDObject());
                    //   serviceRequestPost.getData().getAttributes().getSpecialist().setId(contactVendor.getAttributes().getId());
                    // serviceRequestPost.getData().getAttributes().setInstruction(new ServiceRequestPost.Instruction());
                    //  serviceRequestPost.getData().getAttributes().getInstruction().setCustomer(new ServiceRequestPost.IDObject());
                    //  serviceRequestPost.getData().getAttributes().getInstruction().getCustomer().setId(contactVendor.getAttributes().getId());
                } else {
                    /**         Create New Rental Location
                     *  *  3.2 If company vendor is not found then it must be created
                     *  *     3.2.1 Create new claim contact using cloud api web service
                     */
                    ClaimContactPost newCompanyVendor = new ClaimContactPost();
                    newCompanyVendor.setData(new ClaimContactPost.Data());
                    newCompanyVendor.getData().setAttributes(new ClaimContactPost.Attributes());
                    newCompanyVendor.getData().getAttributes().setContactSubtype(ContactSubType.COMPANY_VENDOR.getType());
                    newCompanyVendor.getData().getAttributes().setHertzIDStoreOffice_Ext(baseHertzRequest.getRentalInfo().getVendorOfficeId());
                    newCompanyVendor.getData().getAttributes().setEditableRoles(new ArrayList<>());
                    ClaimContactPost.EditableRole editableRole = new ClaimContactPost.EditableRole();
                    editableRole.setActive(true);
                    ClaimContactPost.CodeName role = new ClaimContactPost.CodeName();
                    role.setCode(ServiceVendorType.SPECIALIST_VENDOR.getCode());
                    role.setName(ServiceVendorType.SPECIALIST_VENDOR.getName());
                    editableRole.setRole(role);
                    editableRole.setRelatedTo(new ClaimContactPost.RelatedTo());
                    editableRole.getRelatedTo().setId(claim.getData().getAttributes().getId());
                    editableRole.getRelatedTo().setType(EntityEventType.CLAIM.getType());
                    newCompanyVendor.getData().getAttributes().getEditableRoles().add(editableRole);
                    newCompanyVendor.getData().getAttributes().setPrimaryAddress(new ClaimContactPost.PrimaryAddress());
                    newCompanyVendor.getData().getAttributes().getPrimaryAddress().setAddressLine1(baseHertzRequest.getRentalInfo().getVendorOfficeStreet1());
                    if (baseHertzRequest.getRentalInfo().getVendorOfficeStreet2() != null && baseHertzRequest.getRentalInfo().getVendorOfficeStreet2() != "")
                        newCompanyVendor.getData().getAttributes().getPrimaryAddress().setAddressLine2(baseHertzRequest.getRentalInfo().getVendorOfficeStreet2());
                    else
                        newCompanyVendor.getData().getAttributes().getPrimaryAddress().setAddressLine2("N/A");
                    newCompanyVendor.getData().getAttributes().getPrimaryAddress().setCity(baseHertzRequest.getRentalInfo().getVendorOfficeCity());
                    newCompanyVendor.getData().getAttributes().getPrimaryAddress().setPostalCode(baseHertzRequest.getRentalInfo().getVendorOfficeZip());
                    newCompanyVendor.getData().getAttributes().getPrimaryAddress().setCountry(reservationHelper.getDefaultCountry());//todo
                    TypeLists.Data.Attributes.TypeKey typeKeyState = reservationHelper.getTypeKey(exchange, TypeListType.State, baseHertzRequest.getRentalInfo().getVendorOfficeStateId());
                    if (!reservationHelper.isCanadaModuleActive()) {
                        newCompanyVendor.getData().getAttributes().getPrimaryAddress().setState(new ClaimContactPost.CodeName());
                        newCompanyVendor.getData().getAttributes().getPrimaryAddress().getState().setCode(typeKeyState.getCode());
                        newCompanyVendor.getData().getAttributes().getPrimaryAddress().getState().setName(typeKeyState.getName());
                    } else {
                        newCompanyVendor.getData().getAttributes().getPrimaryAddress().setProvince(new ClaimContactPost.CodeName());
                        newCompanyVendor.getData().getAttributes().getPrimaryAddress().getProvince().setCode(typeKeyState.getCode());
                        newCompanyVendor.getData().getAttributes().getPrimaryAddress().getProvince().setName(typeKeyState.getName());
                    }
                    newCompanyVendor.getData().getAttributes().getPrimaryAddress().setAddressType(new ClaimContactPost.CodeName());
                    newCompanyVendor.getData().getAttributes().getPrimaryAddress().getAddressType().setCode(AddressType.BUSINESS.getCode());
                    newCompanyVendor.getData().getAttributes().getPrimaryAddress().getAddressType().setName(AddressType.BUSINESS.getName());
                    newCompanyVendor.getData().getAttributes().setCompanyName(baseHertzRequest.getRentalInfo().getVendorName());
                    newCompanyVendor.getData().getAttributes().setTaxId(reservationHelper.getDefaultTaxId());
                    newCompanyVendor.getData().getAttributes().setWorkPhone(new ClaimContactPost.WorkPhone());
                    newCompanyVendor.getData().getAttributes().getWorkPhone().setCountryCode(new ClaimContactPost.CodeName());
                    TypeLists.Data.Attributes.TypeKey typeCountry = reservationHelper.getTypeKey(exchange, TypeListType.COUNTRY, reservationHelper.getDefaultCountry());
                    newCompanyVendor.getData().getAttributes().getWorkPhone().getCountryCode().setCode(typeCountry.getCode());
                    newCompanyVendor.getData().getAttributes().getWorkPhone().getCountryCode().setName(reservationHelper.getDefaultCountryArea());
                    newCompanyVendor.getData().getAttributes().getWorkPhone().setNumber(baseHertzRequest.getRentalInfo().getVendorOfficePhone());
                    ClaimContactData rentalLocationContact= reservationHelper.addRentalLocationVendor( exchange,  claim,  newCompanyVendor);
                    //serviceRequestPost.getData().getAttributes().setInstruction(new ServiceRequestPost.Instruction());
                    //serviceRequestPost.getData().getAttributes().getInstruction().setCustomer(new ServiceRequestPost.IDObject());
                    // serviceRequestPost.getData().getAttributes().getInstruction().getCustomer().setId(vendorCreated.getData().getAttributes().getVendorId());

                    serviceRequestPost.getData().getAttributes().setHertzRentalLocation_Ext(new ServiceRequestPostComposite.IDObject());
                    serviceRequestPost.getData().getAttributes().getHertzRentalLocation_Ext().setId(rentalLocationContact.getData().getAttributes().getInternalId_Ext());

                }

              /*
              Step3 - Add Specialist Vendor, This APi Call will call to Claimcenter Custom Cloud API
              /rest/claim/v1/claims/$1/create-rentalvendor-ext, which will further call oracle and create Hertz specifiv Vendor under ClaimContacts.
               */
                vendorCreated = reservationHelper.addSpecialistVendor(exchange, claim);
                if(vendorCreated!=null) {
                    serviceRequestPost.getData().getAttributes().setSpecialist(new ServiceRequestPostComposite.IDObject());
                    serviceRequestPost.getData().getAttributes().getSpecialist().setId(vendorCreated.getData().getAttributes().getVendorId());
                }
                else {

                    _log.info("WalkUpOpenProcess","Error Creating Specialist Vendor :  ","ClaimNumber",baseHertzRequest.getClaimInfo().getId(), "TransactionType",   baseHertzRequest.getTransactionType(),"method",new Object() {}.getClass().getEnclosingMethod().getName());


                }

                /**
                 * Step 4. At this step all condition are matches to be able to create a new service request for car rental reservation.
                 * Post
                 * Check if payload contain repair facility if yes use the same kind of mapping to create the contact like the one on step 2
                 * if the node is not present on payload do not add the object on service request payload
                 */
                repairFacility = reservationHelper.findRepairFacilityClaimContact(claim, baseHertzRequest);

                if(repairFacility!=null) {
                    serviceRequestPost.getData().getAttributes().setHertzRepairFacility_Ext(new ServiceRequestPostComposite.IDObject());
                    serviceRequestPost.getData().getAttributes().getHertzRepairFacility_Ext().setId(repairFacility.getAttributes().getInternalId_Ext());
                }
                else {
                    serviceRequestPost.getData().getAttributes().setHertzRepairFacility_Ext(null);
                }
  /*             }
            if (baseHertzRequest.getRepairFacility() != null) {
                    repairFacility = reservationHelper.findRepairFacilityClaimContact(claim, baseHertzRequest);

                    if (repairFacility == null) {

                    }
                     ClaimContactPost newRepairFacility = new ClaimContactPost();
                        newRepairFacility.setData(new ClaimContactPost.Data());
                        newRepairFacility.getData().setAttributes(new ClaimContactPost.Attributes());
                        newRepairFacility.getData().getAttributes().setContactSubtype(ContactSubType.AUTO_REPAIR_SHOP.getType());
                        newRepairFacility.getData().getAttributes().setHertzIDStoreOffice_Ext(baseHertzRequest.getRepairFacility().getId());
                        newRepairFacility.getData().getAttributes().setEditableRoles(new ArrayList<>());
                        ClaimContactPost.EditableRole editableRole = new ClaimContactPost.EditableRole();
                        editableRole.setActive(true);
                        ClaimContactPost.CodeName role = new ClaimContactPost.CodeName();
                        role.setCode(ServiceVendorType.SPECIALIST_SERVICE_VENDOR.getCode());
                        role.setName(ServiceVendorType.SPECIALIST_SERVICE_VENDOR.getName());
                        editableRole.setRole(role);
                        editableRole.getRelatedTo().setId(claim.getData().getAttributes().getId());
                        editableRole.getRelatedTo().setType(EntityEventType.CLAIM.getType());
                        newRepairFacility.getData().getAttributes().getEditableRoles().add(editableRole);
                        newRepairFacility.getData().getAttributes().setPrimaryAddress(new ClaimContactPost.PrimaryAddress());
                        newRepairFacility.getData().getAttributes().getPrimaryAddress().setAddressLine1(baseHertzRequest.getRepairFacility().getStreet1());
                        if (baseHertzRequest.getRepairFacility().getStreet2() != null && baseHertzRequest.getRepairFacility().getStreet2() != "")
                            newRepairFacility.getData().getAttributes().getPrimaryAddress().setAddressLine2(baseHertzRequest.getRepairFacility().getStreet2());
                        else
                            newRepairFacility.getData().getAttributes().getPrimaryAddress().setAddressLine2("N/A");

                        newRepairFacility.getData().getAttributes().getPrimaryAddress().setCity(baseHertzRequest.getRepairFacility().getCity());
                        newRepairFacility.getData().getAttributes().getPrimaryAddress().setPostalCode(baseHertzRequest.getRepairFacility().getZip());
                        newRepairFacility.getData().getAttributes().getPrimaryAddress().setCountry(reservationHelper.getDefaultCountry());
                        TypeLists.Data.Attributes.TypeKey typeKeyState = reservationHelper.getTypeKey(exchange, TypeListType.State, baseHertzRequest.getRepairFacility().getState());
                        if (!reservationHelper.isCanadaModuleActive()) {
                            newRepairFacility.getData().getAttributes().getPrimaryAddress().setState(new ClaimContactPost.CodeName());
                            newRepairFacility.getData().getAttributes().getPrimaryAddress().getState().setCode(typeKeyState.getCode());
                            newRepairFacility.getData().getAttributes().getPrimaryAddress().getState().setName(typeKeyState.getName());
                        } else {
                            newRepairFacility.getData().getAttributes().getPrimaryAddress().setProvince(new ClaimContactPost.CodeName());
                            newRepairFacility.getData().getAttributes().getPrimaryAddress().getProvince().setCode(typeKeyState.getCode());
                            newRepairFacility.getData().getAttributes().getPrimaryAddress().getProvince().setName(typeKeyState.getName());
                        }
                        newRepairFacility.getData().getAttributes().getPrimaryAddress().setAddressType(new ClaimContactPost.CodeName());
                        newRepairFacility.getData().getAttributes().getPrimaryAddress().getAddressType().setCode(AddressType.BUSINESS.getCode());
                        newRepairFacility.getData().getAttributes().getPrimaryAddress().getAddressType().setName(AddressType.BUSINESS.getName());
                        newRepairFacility.getData().getAttributes().setEmailAddress1(baseHertzRequest.getRepairFacility().getEmail());
                        newRepairFacility.getData().getAttributes().setCompanyName(baseHertzRequest.getRepairFacility().getName());

                        newRepairFacility.getData().getAttributes().setWorkPhone(new ClaimContactPost.WorkPhone());
                        newRepairFacility.getData().getAttributes().getWorkPhone().setCountryCode(new ClaimContactPost.CodeName());
                        TypeLists.Data.Attributes.TypeKey typeCountry = reservationHelper.getTypeKey(exchange, TypeListType.COUNTRY, baseHertzRequest.getRepairFacility().getCountry());
                        newRepairFacility.getData().getAttributes().getWorkPhone().getCountryCode().setCode(typeCountry.getCode());
                        newRepairFacility.getData().getAttributes().getWorkPhone().getCountryCode().setName(reservationHelper.getDefaultCountryArea());
                        newRepairFacility.getData().getAttributes().getWorkPhone().setNumber(baseHertzRequest.getRepairFacility().getContactPhone());
                        repairFacilityResponse = reservationHelper.addRepairFacility(exchange, claim, newRepairFacility);

                        serviceRequestPost.getData().getAttributes().setHertzRepairFacility_Ext(new ServiceRequestPost.IDObject());
                        serviceRequestPost.getData().getAttributes().getHertzRepairFacility_Ext().setId(repairFacilityResponse.getData().getAttributes().getInternalId_Ext());*/

                  /*  } else {
                        serviceRequestPost.getData().getAttributes().setHertzRepairFacility_Ext(new ServiceRequestPost.IDObject());
                        serviceRequestPost.getData().getAttributes().getHertzRepairFacility_Ext().setId(repairFacility.getAttributes().getInternalId_Ext());
                    }
                } else {
                    serviceRequestPost.getData().getAttributes().setHertzRepairFacility_Ext(null);
                }*/

                Policy policy = reservationHelper.findPolicy(claim);
                if (policy != null) {
                    ClaimContactData InsuredContact = reservationHelper.findPolicyInsured(policy, claim);
                    if (InsuredContact != null && InsuredContact.getData() != null) {
                        serviceRequestPost.getData().getAttributes().setInstruction(new ServiceRequestPostComposite.Instruction());
                        serviceRequestPost.getData().getAttributes().getInstruction().setCustomer(new ServiceRequestPostComposite.IDObject());
                        serviceRequestPost.getData().getAttributes().getInstruction().getCustomer().setId(InsuredContact.getData().getAttributes().getId());
                        serviceRequestPost.getData().getAttributes().getInstruction().setServiceAddress(new ServiceRequestPostComposite.ServiceAddress());
                        serviceRequestPost.getData().getAttributes().getInstruction().getServiceAddress().setAddressLine1(InsuredContact.getData().getAttributes().getPrimaryAddress().getAddressLine1());
                        serviceRequestPost.getData().getAttributes().getInstruction().getServiceAddress().setCity(InsuredContact.getData().getAttributes().getPrimaryAddress().getCity());
                        serviceRequestPost.getData().getAttributes().getInstruction().getServiceAddress().setCountry(InsuredContact.getData().getAttributes().getPrimaryAddress().getCountry());
                        serviceRequestPost.getData().getAttributes().getInstruction().getServiceAddress().setPostalCode(InsuredContact.getData().getAttributes().getPrimaryAddress().getPostalCode());
                        serviceRequestPost.getData().getAttributes().getInstruction().getServiceAddress().setPolicyLabel("Policy Contact Address (Insured)");
                        if (!reservationHelper.isCanadaModuleActive() && InsuredContact.getData().getAttributes().getPrimaryAddress().getCountry().equals(CountryCode.US.getCode())) {
                            serviceRequestPost.getData().getAttributes().getInstruction().getServiceAddress().setState(new ServiceRequestPostComposite.CodeName());
                            serviceRequestPost.getData().getAttributes().getInstruction().getServiceAddress().getState().setCode(InsuredContact.getData().getAttributes().getPrimaryAddress().getState().getCode());
                            serviceRequestPost.getData().getAttributes().getInstruction().getServiceAddress().getState().setName(InsuredContact.getData().getAttributes().getPrimaryAddress().getState().getName());
                        } else {
                            if (reservationHelper.isCanadaModuleActive() &&  InsuredContact.getData().getAttributes().getPrimaryAddress().getCountry().equals(CountryCode.CA.getCode())) {
                                serviceRequestPost.getData().getAttributes().getInstruction().getServiceAddress().setProvince(new ServiceRequestPostComposite.CodeName());
                                serviceRequestPost.getData().getAttributes().getInstruction().getServiceAddress().getProvince().setCode(InsuredContact.getData().getAttributes().getPrimaryAddress().getProvince().getCode());
                                serviceRequestPost.getData().getAttributes().getInstruction().getServiceAddress().getProvince().setName(InsuredContact.getData().getAttributes().getPrimaryAddress().getProvince().getName());
                            }
                        }
                    }
                }
                serviceRequestPost.getData().getAttributes().getInstruction().setServices(new ArrayList<>());
                ServiceRequestPostComposite.Service rentalService = new ServiceRequestPostComposite.Service();
                rentalService.setCode(ServiceSubTypes.AUTO_RENTAL.getType());
                serviceRequestPost.getData().getAttributes().getInstruction().addService(ServiceSubTypes.AUTO_RENTAL.getType());
                serviceRequestPost.getData().getAttributes().setTier(new ServiceRequestPostComposite.CodeName());
                serviceRequestPost.getData().getAttributes().getTier().setCode(TierType.LOW.getCode());
                serviceRequestPost.getData().getAttributes().getTier().setName(TierType.LOW.getName());
                serviceRequestPost.getData().getAttributes().setSpecialistCommMethod(new ServiceRequestPostComposite.CodeName());
                serviceRequestPost.getData().getAttributes().getSpecialistCommMethod().setCode(SpecialistCommType.THIRD_PARTY_PORTAL.getCode());
                serviceRequestPost.getData().getAttributes().getSpecialistCommMethod().setName(SpecialistCommType.THIRD_PARTY_PORTAL.getName());
                serviceRequestPost.getData().getAttributes().setKind(new ServiceRequestPostComposite.CodeName());
                serviceRequestPost.getData().getAttributes().getKind().setCode(ServiceKind.SERVICE_ONLY.getCode());
                serviceRequestPost.getData().getAttributes().getKind().setName(ServiceKind.SERVICE_ONLY.getName());
                serviceRequestPost.getData().getAttributes().setHertzContractStatus_Ext(new ServiceRequestPostComposite.CodeName());
                serviceRequestPost.getData().getAttributes().getHertzContractStatus_Ext().setCode(ContractStatus.RESERVATION_OPEN_WALKUP.getCode());
                serviceRequestPost.getData().getAttributes().getHertzContractStatus_Ext().setName(ContractStatus.RESERVATION_OPEN_WALKUP.getName());

                serviceRequestPost.getData().getAttributes().setHertzClassCode_Ext(baseHertzRequest.getRentalInfo().getRateClass());
                serviceRequestPost.getData().getAttributes().setHertzClassName_Ext(baseHertzRequest.getRentalInfo().getRateClass());
                serviceRequestPost.getData().getAttributes().setHertzCustomerSelfPay_Ext(false);
                serviceRequestPost.getData().getAttributes().setHertzDateType_Ext(new ServiceRequestPostComposite.CodeName());
                //todo
                serviceRequestPost.getData().getAttributes().getHertzDateType_Ext().setCode(DateType.CALENDAR_DAY.getCode());
                serviceRequestPost.getData().getAttributes().getHertzDateType_Ext().setName(DateType.CALENDAR_DAY.getCode());

                //todo
                serviceRequestPost.getData().getAttributes().setHertzDayCount_Ext(baseHertzRequest.getClaimInfo().getTotalDays());
                serviceRequestPost.getData().getAttributes().setHertzIncrementalDays_Ext(baseHertzRequest.getClaimInfo().getIncrementalDays());

                if (baseHertzRequest.getClaimInfo().getAdditionalCharges() != null && !baseHertzRequest.getClaimInfo().getAdditionalCharges().isEmpty()) {
                    var ldw = baseHertzRequest.getClaimInfo().getAdditionalCharges().stream().filter(e -> e.getCode().equalsIgnoreCase(AdditionalChargeType.LOST_DAMAGE_WAIVER.getCode()) && e.getDescription().equalsIgnoreCase(AdditionalChargeType.LOST_DAMAGE_WAIVER.getName().toLowerCase())).findFirst().orElse(null);
                    serviceRequestPost.getData().getAttributes().setHertzLossDamageWaiver_Ext(ldw != null);
                    //CM-8714-Enable winter tires logic as per discussion with Hertz Team
                    var winterTires = baseHertzRequest.getClaimInfo().getAdditionalCharges().stream().filter(e -> e.getCode().equalsIgnoreCase(AdditionalChargeType.WINTER_TIRES.getCode()) && e.getDescription().equalsIgnoreCase(AdditionalChargeType.WINTER_TIRES.getName().toLowerCase())).findFirst().orElse(null);
                    serviceRequestPost.getData().getAttributes().setHertzWinterTires_Ext(winterTires != null);
                }

                serviceRequestPost.getData().getAttributes().setHertzMaxAuthAmount_Ext(new ServiceRequestPostComposite.Amount());
                serviceRequestPost.getData().getAttributes().getHertzMaxAuthAmount_Ext().setAmount(String.valueOf(baseHertzRequest.getPolicy().getMaxCoverage()));
                serviceRequestPost.getData().getAttributes().getHertzMaxAuthAmount_Ext().setCurrency(reservationHelper.getDefaultCurrency());
                serviceRequestPost.getData().getAttributes().setHertzRateInclusivePrice_Ext(new ServiceRequestPostComposite.Amount());
                serviceRequestPost.getData().getAttributes().getHertzRateInclusivePrice_Ext().setAmount(AppUtils.getValidCurrencyAmount(String.valueOf(baseHertzRequest.getClaimInfo().getRentalDailyAmount())));
                serviceRequestPost.getData().getAttributes().getHertzRateInclusivePrice_Ext().setCurrency(reservationHelper.getDefaultCurrency());

                if (baseHertzRequest.getPolicy().getDailyMaxCoverage() > 0) {
                    serviceRequestPost.getData().getAttributes().setHertzRentalDailyAmount_Ext(new ServiceRequestPostComposite.Amount());
                    serviceRequestPost.getData().getAttributes().getHertzRentalDailyAmount_Ext().setAmount(String.valueOf(baseHertzRequest.getPolicy().getDailyMaxCoverage()));
                    serviceRequestPost.getData().getAttributes().getHertzRentalDailyAmount_Ext().setCurrency(reservationHelper.getDefaultCurrency());
                } else {
                    serviceRequestPost.getData().getAttributes().setHertzRentalDailyAmount_Ext(new ServiceRequestPostComposite.Amount());
                    serviceRequestPost.getData().getAttributes().getHertzRentalDailyAmount_Ext().setAmount(AppUtils.getValidCurrencyAmount(String.valueOf(baseHertzRequest.getClaimInfo().getRentalDailyAmount())));
                    serviceRequestPost.getData().getAttributes().getHertzRentalDailyAmount_Ext().setCurrency(reservationHelper.getDefaultCurrency());
                }
                //CM-8368, CM-8684 - PayAllTaxes will override the taxExempt Field at VehicleIncident, this is not required.
                // serviceRequestPost.getData().getAttributes().setHertzPayAllTaxes_Ext(!AppUtils.getValidStringValue(baseHertzRequest.getClaimInfo().getPayTaxes()).equalsIgnoreCase("N"));
                serviceRequestPost.getData().getAttributes().setHertzPercentagePay_Ext(String.valueOf(baseHertzRequest.getPolicy().getPercentPay()));
                if(baseHertzRequest.getRentalInfo().getPickupDate()!=null)
                    serviceRequestPost.getData().getAttributes().setHertzPickupDate_Ext(baseHertzRequest.getRentalInfo().getPickupDate());

                serviceRequestPost.getData().getAttributes().setHertzRentalBeginDate_Ext(AppUtils.getDateISO8601(baseHertzRequest.getRentalInfo().getStartDate()));

                var endDate = baseHertzRequest.getRentalInfo().getEndDate() != null ? AppUtils.getDateISO8601(baseHertzRequest.getRentalInfo().getEndDate()) : null;
                if (endDate == null) {
                    if(baseHertzRequest.getClaimInfo().getTotalDays() > 0){
                        endDate = Converter.parseDateToStringUSFormat(Converter.addDays(Converter.parseStringToDateUSFormat(baseHertzRequest.getRentalInfo().getStartDate()), baseHertzRequest.getClaimInfo().getTotalDays() - 1));
                        serviceRequestPost.getData().getAttributes().setHertzRentalEndDate_Ext(endDate);
                    }
                }

                serviceRequestPost.getData().getAttributes().setRequestedServiceCompletionDate(Converter.parseDateToStringUSFormat(Converter.addDays(Converter.parseStringToDateUSFormat(baseHertzRequest.getRentalInfo().getStartDate()), 30)));
                serviceRequestPost.getData().getAttributes().setHertzRateInclusivePrice_Ext(new ServiceRequestPostComposite.Amount());
                serviceRequestPost.getData().getAttributes().getHertzRateInclusivePrice_Ext().setAmount(AppUtils.getValidCurrencyAmount(String.valueOf(baseHertzRequest.getClaimInfo().getRentalDailyAmount())));
                serviceRequestPost.getData().getAttributes().getHertzRateInclusivePrice_Ext().setCurrency(reservationHelper.getDefaultCurrency());
                serviceRequestPost.getData().getAttributes().setHertzRateType_Ext(new ServiceRequestPostComposite.CodeName());
                RateType rate = RateType.fromType(baseHertzRequest.getRentalInfo().getRateClass());
                serviceRequestPost.getData().getAttributes().getHertzRateType_Ext().setCode(rate.getCode());
                serviceRequestPost.getData().getAttributes().getHertzRateType_Ext().setName(rate.getDescription());
                serviceRequestPost.getData().getAttributes().setHertzRentalCompany_Ext(new ServiceRequestPostComposite.CodeName());
                serviceRequestPost.getData().getAttributes().getHertzRentalCompany_Ext().setCode(RentalCompany.HERTZ.getCode());
                serviceRequestPost.getData().getAttributes().getHertzRentalCompany_Ext().setName(RentalCompany.HERTZ.getDescription());
                serviceRequestPost.getData().getAttributes().setHertzTransactionDate_Ext(AppUtils.getDateISO8601(baseHertzRequest.getTransactionDate()));
                RentalRole rentalRole = RentalRole.fromType(baseHertzRequest.getClaimInfo().getType());
                serviceRequestPost.getData().getAttributes().setHertzRentalRole_Ext(new ServiceRequestPostComposite.CodeName());
                serviceRequestPost.getData().getAttributes().getHertzRentalRole_Ext().setCode(rentalRole.getCode());
                serviceRequestPost.getData().getAttributes().getHertzRentalRole_Ext().setName(rentalRole.getName());
                serviceRequestPost.getData().getAttributes().setHertzTotalDaysApproved_Ext(baseHertzRequest.getClaimInfo().getTotalDays());
                serviceRequestPost.getData().getAttributes().setHertzVehicleCondition_Ext("D");
                serviceRequestPost.getData().getAttributes().setHertzTransactionContractID_Ext(baseHertzRequest.getRentalInfo().getContractId());
                serviceRequestPost.getData().getAttributes().setHertzTransactionTSDID_Ext(baseHertzRequest.getRentalInfo().getContractId());
                serviceRequestPost.getData().getAttributes().setHertzTransactionGUID_Ext(baseHertzRequest.getTransactionGUID());

                HistoryComposite newHistory = new HistoryComposite();
                newHistory.setData(new HistoryComposite.Data());
                newHistory.getData().setAttributes(new HistoryComposite.Data.Attributes());
                newHistory.getData().getAttributes().setClaim(new HistoryComposite.Data.Attributes.Claim());
                newHistory.getData().getAttributes().getClaim().setId(claim.getData().getAttributes().getId());
                newHistory.getData().getAttributes().getClaim().setType(EntityEventType.CLAIM.getType());
                newHistory.getData().getAttributes().setServiceRequest(new HistoryComposite.Data.Attributes.ServiceRequest());
                newHistory.getData().getAttributes().setUser(new HistoryComposite.Data.Attributes.User());
                newHistory.getData().getAttributes().getUser().setId(claim.getData().getAttributes().getAssignedUser().getId());
                newHistory.getData().getAttributes().getUser().setType(EntityEventType.USER.getType());
                newHistory.getData().getAttributes().setType(new HistoryComposite.Data.Attributes.Type());
                newHistory.getData().getAttributes().getType().setCode(HistoryType.HERTZ_WALK_UP_AUTHORIZATION_ACC.getCode());
                newHistory.getData().getAttributes().getType().setName(HistoryType.HERTZ_WALK_UP_AUTHORIZATION_ACC.getName());
                newHistory.getData().getAttributes().setDescription(HistoryType.HERTZ_WALK_UP_AUTHORIZATION_ACC.getDescription().replace("$1", String.valueOf(baseHertzRequest.getClaimInfo().getTotalDays())));
                newHistory.getData().getAttributes().setRequest(reservationHelper.parseRequestAsJSON(baseHertzRequest));

                ActivityPostComposite newActivity = new ActivityPostComposite();
                newActivity.setData(new ActivityPostComposite.Data());
                newActivity.getData().setAttributes(new ActivityPostComposite.Attributes());
                newActivity.getData().getAttributes().setActivityPattern(ActivityPattern.HERTZ_WALK_UP_AUTHORIZATION_ACC.getCode());
                newActivity.getData().getAttributes().setRelatedTo(new ActivityPostComposite.RelatedTo());
                newActivity.getData().getAttributes().setSubject(ActivityPattern.HERTZ_WALK_UP_AUTHORIZATION_ACC.getSubject());
                newActivity.getData().getAttributes().setDescription(ActivityPattern.HERTZ_WALK_UP_AUTHORIZATION_ACC.getDescription().replace("$1", String.valueOf(baseHertzRequest.getClaimInfo().getTotalDays())));

                String stickySessionToken = UUID.randomUUID().toString();
                var abstractRequest = compositeRentalWalkUpHelper.buildCompositeRequest(claim,
                        serviceRequestPost,
                        newHistory,
                        newActivity);
                String result = compositeClient.executeCompositeRequest(exchange, stickySessionToken, abstractRequest);
                ServiceRequestPostResponse compositeBodyResponse = CompositeResponseMapper.mapFirstResponse(result, ServiceRequestPostResponse.class);

                Thread.sleep(10000);
                if(compositeBodyResponse!=null){
                    if (compositeBodyResponse.getData().getAttributes().getProgress().getCode().equalsIgnoreCase(ServiceRequestProgress.DRAFT.getCode())) {
                        //Move to requested state using normal Rest Call since Composite DO NOT SUPPORT Submit Service request operation
                        compositeBodyResponse = reservationHelper.markAsSubmitted(stickySessionToken,claim, compositeBodyResponse.getData().getAttributes().getId());
                    }
                    response = new BaseHertzResponse();
                    response.setMessage(HistoryType.HERTZ_WALK_UP_AUTHORIZATION_ACC.getName() + " processed and waiting for adjuster approval");
                    response.setMsgType("success");
                    response.setTransactionGuid(baseHertzRequest.getTransactionGUID());
                    response.setTransactionContractId(baseHertzRequest.getTransactionContractId());
                    response.setTransactionType(baseHertzRequest.getTransactionType());
                    response.setMsgGuid(baseHertzRequest.getTransactionGUID());
                    response.setTransactionDate(baseHertzRequest.getTransactionDate());
                    response.setMsgDate(Converter.parseDateToJSON(new Date()));
                }
                else{
                    _log.info("Unable to parse Composite Response to ServiceRequestPostResponse", new Object() {
                    }.getClass().getEnclosingMethod().getName());
                }
            } else {
                _log.info("Invalid driver information not matches with Claim Incident", new Object() {
                }.getClass().getEnclosingMethod().getName());
                throw new Exception("Invalid driver information not matches with Claim Incident");
            }
        } catch (Exception e) {
            _log.error("Error : ", new Object() {
            }.getClass().getEnclosingMethod().getName(), e);
            throw e;
        }
        return response;
    }

}
