package acc.hertz.model.enums;

public enum AdditionalChargeType {
    WINTER_TIRES("999","WTRS"),
    LOST_DAMAGE_WAIVER("103","LDW");
    private final String code;

    public String getName() {
        return name;
    }

    private final String name;

    AdditionalChargeType(String code, String name) {
        this.code = code;
        this.name=name;
    }

    public String getCode() {
        return code;
    }

    public static AdditionalChargeType fromType(String type) {
        for (AdditionalChargeType charge : values()) {
            if (charge.getCode().equals(type)) {
                return charge;
            }
        }
        throw new IllegalArgumentException("Unknown : " + type);
    }
}
