package acc.hertz.client.history;


import acc.hertz.client.core.IClient;
import acc.hertz.client.core.WebMethodType;
import acc.hertz.client.service.IHistoryClient;
import acc.hertz.model.cloudapi.history.History;
import acc.hertz.model.enums.MimeType;
import acc.hertz.model.response.IResponseHandler;
import acc.hertz.security.IServerSelector;
import acc.hertz.security.authorization.AuthorizationType;
import acc.hertz.util.AppUtils;
import acc.hertz.util.GenericJSONTransformer;
import org.apache.camel.Exchange;
import acc.hertz.util.TransformerFactory;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import static acc.hertz.util.AppUtils.X_GWRE_SESSION;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Named
public class HistoryClient implements IHistoryClient {
    @Inject
    private IServerSelector serverSelector;
    @Inject
    private IResponseHandler IResponseHandler;
    @Inject
    private IClient client;
	   private static final Logger _log = LoggerFactory.getLogger(HistoryClient.class);

    private final GenericJSONTransformer<History> historyGenericJSONTransformer = TransformerFactory.getTransformer(History.class);

    @Override
    public boolean createHistoryEntry(Exchange exchange, final String stickySessionToken,History body) throws Exception {
        try {
            String bodyToPost = historyGenericJSONTransformer.toJson(body);
            String server = serverSelector.getServer();
            client.setExchange(exchange);
            client.clearHeaders();
            client.addHeaderParameter(AppUtils.API_CONTENT_TYPE, MimeType.JSON.getCode());
            client.addHeaderParameter(AppUtils.API_X_GWRE_SESSION, stickySessionToken);
            client.doExecute(server + AppUtils.CLOUD_API_CREATE_HISTORY_ENTRY, bodyToPost, WebMethodType.POST, AuthorizationType.CLOUD_DETAILED_ACCESS);
            if (client.isSuccessExecuted()) {
                return true;
            } else {
                throw new Exception(AppUtils.sanitize(client.getResponseBody()));
            }
        } catch (Exception e) {
            throw e;
        }
    }
}
