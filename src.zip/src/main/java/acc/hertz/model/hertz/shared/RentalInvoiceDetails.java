package acc.hertz.model.hertz.shared;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RentalInvoiceDetails {

    @JsonProperty("Id")
    private String id;

    @JsonProperty("Binary")
    private String binary;

    @JsonProperty("Format")
    private int format;

    @JsonProperty("TotalBillAmt")
    private double totalBillAmt;

    // Getters and setters

    public String getId() { return id; }

    public void setId(String id) { this.id = id; }

    public String getBinary() { return binary; }

    public void setBinary(String binary) { this.binary = binary; }

    public int getFormat() { return format; }

    public void setFormat(int format) { this.format = format; }

    public double getTotalBillAmt() { return totalBillAmt; }

    public void setTotalBillAmt(double totalBillAmt) { this.totalBillAmt = totalBillAmt; }
}
