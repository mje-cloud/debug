package acc.hertz.model.enums;

public enum InvoiceStatemenLineCategory {
    LINE_OTHER("other","Other");
    private final String code;

    public String getName() {
        return name;
    }

    private final String name;

    InvoiceStatemenLineCategory(String code, String name) {
        this.code = code;
        this.name=name;
    }

    public String getCode() {
        return code;
    }

    public static InvoiceStatemenLineCategory fromType(String type) {
        for (InvoiceStatemenLineCategory charge : values()) {
            if (charge.getCode().equals(type)) {
                return charge;
            }
        }
        throw new IllegalArgumentException("Unknown : " + type);
    }
}
