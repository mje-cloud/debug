package acc.hertz.model.enums;

public enum DocumentType {
    HERTZ_INVOICE_ACC("hertz_invoice_acc");

    private final String type;

    DocumentType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public static DocumentType fromType(String type) {
        for (DocumentType requestType : values()) {
            if (requestType.getType().equals(type)) {
                return requestType;
            }
        }
        throw new IllegalArgumentException("Unknown Type: " + type);
    }
}
