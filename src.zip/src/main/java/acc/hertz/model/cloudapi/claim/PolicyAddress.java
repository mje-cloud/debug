package acc.hertz.model.cloudapi.claim;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PolicyAddress {
    @JsonProperty("addressLine1")
    private String addressLine1;

    @JsonProperty("city")
    private String city;

    @JsonProperty("country")
    private String country;

    @JsonProperty("displayName")
    private String displayName;

    @JsonProperty("id")
    private String id;

    @JsonProperty("policyAddress")
    private boolean policyAddress;

    @JsonProperty("policyLabel")
    private String policyLabel;

    @JsonProperty("postalCode")
    private String postalCode;

    @JsonProperty("state")
    private State state;

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isPolicyAddress() {
        return policyAddress;
    }

    public void setPolicyAddress(boolean policyAddress) {
        this.policyAddress = policyAddress;
    }

    public String getPolicyLabel() {
        return policyLabel;
    }

    public void setPolicyLabel(String policyLabel) {
        this.policyLabel = policyLabel;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }
}


