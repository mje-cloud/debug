package acc.hertz.model.enums;

public enum AddressType {
    BUSINESS("business","Business");

    private final String code;

    public String getName() {
        return name;
    }

    private final String name;

    AddressType(String code, String name) {
        this.code = code;
        this.name=name;
    }

    public String getCode() {
        return code;
    }

    public static AddressType fromType(String type) {
        for (AddressType kind : values()) {
            if (kind.getCode().equals(type)) {
                return kind;
            }
        }
        throw new IllegalArgumentException("Unknown Type: " + type);
    }
}
