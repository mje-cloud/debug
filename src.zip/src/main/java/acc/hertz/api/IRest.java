package acc.hertz.api;

import acc.hertz.model.hertz.inbound.AssignmentRequest;
import acc.hertz.model.hertz.inbound.LocationSearchRequest;
import acc.hertz.model.hertz.inbound.LocationSearchResponse;
import acc.hertz.model.hertz.shared.TransactionResponseHeader;

public interface IRest {

    TransactionResponseHeader createNewReservation(AssignmentRequest payload)throws Exception;

    LocationSearchResponse getLocation(LocationSearchRequest locationSearchRequest)throws Exception;

    TransactionResponseHeader editReservation(AssignmentRequest payload)throws Exception;

}
