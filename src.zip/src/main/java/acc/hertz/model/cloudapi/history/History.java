package acc.hertz.model.cloudapi.history;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class History {

    public Data getData() {
        return data;
    }

    @JsonProperty("data")
    private Data data;
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Data {
        @JsonProperty("attributes")
        private Attributes attributes;

        public Attributes getAttributes(){
            return attributes;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Setter
        @Getter
        public static  class Attributes {
            @JsonProperty("claim")
            private Claim claim;
            @JsonProperty("description")
            private String description;

            @JsonProperty("request")
            private String request;

            @JsonProperty("serviceRequest")
            private ServiceRequest serviceRequest;

            @JsonProperty("type")
            private Type type;

            @JsonProperty("user")
            private User user;

            public Claim getClaim(){
                return claim;
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @Setter
            @Getter
            public static class Claim {
                @JsonProperty("id")
                private String id;
                @JsonProperty("type")
                private String type;

                public String getId(){
                    return id;
                }
            }


            @JsonIgnoreProperties(ignoreUnknown = true)
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @Setter
            @Getter
            public static class ServiceRequest {
                @JsonProperty("id")
                private String id;
                @JsonProperty("type")
                private String type;

            }
            @JsonIgnoreProperties(ignoreUnknown = true)
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @Setter
            @Getter
            public static class Type {
                @JsonProperty("code")
                private String code;
                @JsonProperty("name")
                private String name;

            }
            @JsonIgnoreProperties(ignoreUnknown = true)
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @Setter
            @Getter
            public static class User {
                @JsonProperty("id")
                private String id;

                @JsonProperty("type")
                private String type;
            }
		@JsonProperty("eventName")
		private String eventName;
        }
    }
}


