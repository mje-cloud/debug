package acc.hertz.route.base;

import acc.hertz.model.response.IResponseHandler;
import gw.impl.ig.route.GwRouteBuilder;

import jakarta.inject.Inject;

public abstract class AbstractRouteBuilder extends GwRouteBuilder {

    @Inject
    public IResponseHandler IResponseHandler;


}
