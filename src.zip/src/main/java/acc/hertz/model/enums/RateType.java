package acc.hertz.model.enums;

public enum RateType {
    DAILY("D", "Daily Rate Type"),
    MONTHLY("M", "Monthly Rate Type"),
    WEEKLY("W", "Weekly Rate Type"),
    PER_HOUR("H", "Per Hour Rate Type"),
    SPECIAL("S", "Special Rate Type");

    private final String code;
    private final String description;

    RateType(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public static RateType fromType(String type) {
        for (RateType rateType : values()) {
            if (rateType.getCode().equals(type)) {
                return rateType;
            }
        }
        return DAILY;
    }
}