package acc.hertz.model.cloudapi.claim;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClaimContact {
    @JsonProperty("attributes")
    private Attributes attributes;

    // Constructor, getters, and setters
    public Attributes getAttributes() {
        return attributes;
    }

    public void setAttributes(Attributes attributes) {
        this.attributes = attributes;
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Getter
    @Setter
    public static class Attributes {
        @JsonProperty("authorizationID")
        private String authorizationID;

        @JsonProperty("companyName")
        private String companyName;

        @JsonProperty("contactSubtype")
        private String contactSubtype;

        @JsonProperty("displayName")
        private String displayName;

        @JsonProperty("hertzIDStoreOffice_Ext")
        private String hertzIDStoreOffice_Ext;
        @JsonProperty("internalId_Ext")
        private String internalId_Ext;

        @JsonProperty("id")
        private String id;

        @JsonProperty("emailAddress1")
        private String emailAddress1;

        @JsonProperty("emailAddress2")
        private String emailAddress2;

        @JsonProperty("firstName")
        private String firstName;

        @JsonProperty("lastName")
        private String lastName;

        @JsonProperty("primaryPhone")
        private String primaryPhone;

        @JsonProperty("roles")
        private List<Role> roles;

        private void writeObject(ObjectOutputStream oos) throws IOException {
            throw new NotSerializableException("Serialization is not supported on this object!");
        }

        private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
            throw new NotSerializableException("Serialization is not supported on this object!");
        }

        // Constructor, getters, and setters
        public String getAuthorizationID() {
            return authorizationID;
        }

        public void setAuthorizationID(String authorizationID) {
            this.authorizationID = authorizationID;
        }

        public String getCompanyName() {
            return companyName;
        }

        public void setCompanyName(String companyName) {
            this.companyName = companyName;
        }

        public String getContactSubtype() {
            return contactSubtype;
        }

        public void setContactSubtype(String contactSubtype) {
            this.contactSubtype = contactSubtype;
        }

        public String getDisplayName() {
            return displayName;
        }

        public void setDisplayName(String displayName) {
            this.displayName = displayName;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getEmailAddress1() {
            return emailAddress1;
        }

        public void setEmailAddress1(String emailAddress1) {
            this.emailAddress1 = emailAddress1;
        }

        public String getEmailAddress2() {
            return emailAddress2;
        }

        public void setEmailAddress2(String emailAddress2) {
            this.emailAddress2 = emailAddress2;
        }

        public String getFirstName() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public String getPrimaryPhone() {
            return primaryPhone;
        }

        public void setPrimaryPhone(String primaryPhone) {
            this.primaryPhone = primaryPhone;
        }

        public List<Role> getRoles() {
            return roles;
        }

        public void setRoles(List<Role> roles) {
            this.roles = roles;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Role {
        @JsonProperty("active")
        private boolean active;

        @JsonProperty("relatedTo")
        private RelatedTo relatedTo;

        @JsonProperty("role")
        private RoleInfo role;

        // Constructor, getters, and setters
        public boolean isActive() {
            return active;
        }

        public void setActive(boolean active) {
            this.active = active;
        }

        public RelatedTo getRelatedTo() {
            return relatedTo;
        }

        public void setRelatedTo(RelatedTo relatedTo) {
            this.relatedTo = relatedTo;
        }

        public RoleInfo getRole() {
            return role;
        }

        public void setRole(RoleInfo role) {
            this.role = role;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class RelatedTo {
            @JsonProperty("displayName")
            private String displayName;

            @JsonProperty("id")
            private String id;

            @JsonProperty("type")
            private String type;

            // Constructor, getters, and setters
            public String getDisplayName() {
                return displayName;
            }

            public void setDisplayName(String displayName) {
                this.displayName = displayName;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class RoleInfo {
            @JsonProperty("code")
            private String code;

            @JsonProperty("name")
            private String name;

            // Constructor, getters, and setters
            public String getCode() {
                return code;
            }

            public void setCode(String code) {
                this.code = code;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }
        }
    }
}



