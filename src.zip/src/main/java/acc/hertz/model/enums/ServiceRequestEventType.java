package acc.hertz.model.enums;

public enum ServiceRequestEventType {

    HERTZ_SERVICE_REQUEST_FNOL_ADDED("HertzServiceRequestFNOLAdded_Acc"),
    HERTZ_SERVICE_REQUEST_ADDED("HertzServiceRequestAdded_Acc"),
    HERTZ_SERVICE_REQUEST_CHANGED("HertzServiceRequestChanged_Acc"),
    HERTZ_SERVICE_REQUEST_FINAL_DATE_CHANGED("HertzServiceRequestFinalDay_Acc"),
    HERTZ_SERVICE_REQUEST_CANCELED("HertzServiceRequestCancel_Acc"),
    HERTZ_SERVICE_REQUEST_APPROVED_OR_REJECTED("HertzServiceRequestApproveReject_Acc");

    private final String type;

    ServiceRequestEventType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public static ServiceRequestEventType fromType(String type) {
        for (ServiceRequestEventType requestType : values()) {
            if (requestType.getType().equals(type)) {
                return requestType;
            }
        }
        throw new IllegalArgumentException("Unknown ServiceRequestType: " + type);
    }

    public static boolean isValidAppEvent(String type) {
        for (ServiceRequestEventType requestType : values()) {
            if (requestType.getType().equals(type)) {
                return true;
            }
        }
        return false;
    }
}
