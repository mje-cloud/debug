package acc.hertz.model.enums;

public enum ClaimStatus {
    OPEN("open","Open");

    private final String code;

    public String getName() {
        return name;
    }

    private final String name;

    ClaimStatus(String code, String name) {
        this.code = code;
        this.name=name;
    }

    public String getCode() {
        return code;
    }

    public static ClaimStatus fromType(String type) {
        for (ClaimStatus kind : values()) {
            if (kind.getCode().equals(type)) {
                return kind;
            }
        }
        throw new IllegalArgumentException("Unknown : " + type);
    }
}
