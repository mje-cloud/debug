package acc.hertz.model.enums;

public enum RestRelopType {
    NO_EQ_OPERATOR(":ne:"),
    LESS_THAN_OPERATOR(":lt:"),
    GREATER_THAN_OPERATOR(":gt:"),
    GREATER_THAN_OR_EQUALS_OPERATOR(":ge:"),
    IN_OPERATOR(":in:"),
    NOT_IN_OPERATOR(":ni:"),
    STARTS_WITH_OPERATOR(":ws:"),
    CONTAINS_OPERATOR(":cn:"),
    LESS_THAN_OR_EQUALS_OPERATOR(":le:"),

    EQUALS("="),
    COMMA_SEPARATOR(","),

    AND_OPERATOR("&"),
    EQ_OPERATOR(":eq:");

    private String code;
    private RestRelopType(String code ) {
        this.code = code;
    }
    public final String getCode() {
        return code;
    }

    @Override
    public String toString() {
        return String.valueOf(code);
    }


}
