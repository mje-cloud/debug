package acc.hertz.client.core;

import acc.hertz.security.authorization.AuthorizationType;
import org.apache.camel.Exchange;

import java.util.List;
import java.util.Map;

public interface IClient {

    void clearHeaders();

    void doExecute(String serviceURL, String body, WebMethodType webMethodType, AuthorizationType type) throws Exception;

    void doExecuteBinary(String serviceURL, List<byte[]> body, WebMethodType webMethodType, AuthorizationType type) throws Exception;

    void doExecute(String serviceURL, WebMethodType webMethodType, AuthorizationType type) throws Exception;

    void addHeaderParameter(String name, String value);

    String getResponseBody();

    byte[] getResponseBinary();

    int getResponseCode();

    boolean isSuccessExecuted();

    void doExecuteBinary(String serviceURL, WebMethodType webMethodType, AuthorizationType type) throws Exception;

    Map<String, Object> getHeaderResponse();

    void setExchange(Exchange exchange);
}
