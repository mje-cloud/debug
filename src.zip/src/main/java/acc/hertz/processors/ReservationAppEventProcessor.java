package acc.hertz.processors;

import acc.hertz.api.ProcessorConsumer;
import acc.hertz.model.cloudapi.claim.ClaimData;
import acc.hertz.model.cloudapi.servicerequest.ServiceRequestList;
import acc.hertz.model.enums.Filter;
import acc.hertz.model.enums.RentalCompany;
import acc.hertz.model.enums.RestRelopType;
import acc.hertz.model.enums.ServiceRequestEventType;
import acc.hertz.model.hertz.shared.TransactionResponseHeader;
import acc.hertz.process.ReservationHelper;
import acc.hertz.util.AppUtils;
import com.guidewire.camel.AppEvents;
import gw.api.ig.GwUtilities;
import io.micrometer.common.util.StringUtils;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;

import java.util.Optional;

@Named
public class ReservationAppEventProcessor implements Processor {

    @Inject
    private ProcessorConsumer processorTSDConsumer;
    @Inject
    private ReservationHelper reservationHelper;
    @Override
    public void process(Exchange exchange) throws Exception {
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
        try{

            var eventType = findAppEventType(exchange.getMessage(),exchange);
            log.info("ReservationAppEventProcessor", "Entering the Process Method", "EventType", eventType);

            if(ServiceRequestEventType.isValidAppEvent(eventType)){
                var objPrimaryObjectInfo = AppEvents.getPrimaryObjectInfo(exchange);
                var objectInfo = AppEvents.getObjectInfo(exchange);
                ClaimData claim = reservationHelper.findClaimById(exchange, objPrimaryObjectInfo.getId());
                log.info("ReservationAppEventProcessor", "Inside the Process Method, Valid Event Block", "EventType", eventType, "ClaimNumber", objPrimaryObjectInfo.getId(), "serviceRequestNumber", objectInfo.getId());
                if (claim == null){
                    log.error("ReservationAppEventProcessor", "Inside the Process Method, Claim not Found ", null, "EventType", eventType, "ClaimNumber", objPrimaryObjectInfo.getId(), "serviceRequestNumber", objectInfo.getId());
                    throw new Exception("ReservationAppEventProcessor - Event Claim Id Not Found");
                }
                log.info("ReservationAppEventProcessor", "Inside the Process Method, Checking ObjectInfo Id before getValidIdentifierToFilter", "ObjectInfo Id", objectInfo.getId());
                log.info("ReservationAppEventProcessor", "Inside the Process Method, Checking ObjectInfo Id after getValidIdentifierToFilter", "ObjectInfo Id", AppUtils.getValidIdentifierToFilter(objectInfo.getId()));

                String filter = Filter.FILTER_KEYWORD.getCode() + RestRelopType.EQUALS.getCode() + Filter.HERTZ_SERVICE_REQUEST_RENTAL_EXT.getCode() + RestRelopType.EQ_OPERATOR.getCode() + AppUtils.getValidIdentifierToFilter(objectInfo.getId());
                ServiceRequestList.ServiceRequest serviceRequest = reservationHelper.findServiceRequestByFilter(objPrimaryObjectInfo.getId(), filter);
                log.info("ReservationAppEventProcessor", "Inside the Process Method, Checking Service Request", "serviceRequest", serviceRequest);
                log.info("ReservationAppEventProcessor", "Inside the Process Method, Checking Service Request Attributes", "serviceRequest.getAttributes()", serviceRequest.getAttributes());
                if (serviceRequest == null || serviceRequest.getAttributes() == null){
                    log.error("ReservationAppEventProcessor", "Inside the Process Method, ServiceRequest Id Not Found ", null, "EventType", eventType, "ClaimNumber", objPrimaryObjectInfo.getId(), "serviceRequestNumber", objectInfo.getId());
                    throw new Exception("ReservationAppEventProcessor - Event ServiceRequest Id Not Found");
                }
                if (serviceRequest.getAttributes().isHertzRequestType_Ext() && serviceRequest.getAttributes().getHertzRentalCompany_Ext().getCode().equalsIgnoreCase(RentalCompany.HERTZ.getCode())) {
                    TransactionResponseHeader responseTSD = processorTSDConsumer.processTSDTransaction(exchange, ServiceRequestEventType.fromType(eventType), claim, serviceRequest);
                    if (responseTSD != null)
                        log.info("ReservationAppEventProcessor", "Inside the Process Method, Event Processed,responseTSD is not null", "EventType", eventType, "ClaimNumber", objPrimaryObjectInfo.getId(), "serviceRequestNumber", objectInfo.getId(),
                                "responseCode", responseTSD.getCode());
                    else {
                        log.info("ReservationAppEventProcessor", "Inside the Process Method, Event Failed ,responseTSD is  null", "EventType", eventType, "ClaimNumber", objPrimaryObjectInfo.getId(), "serviceRequestNumber", objectInfo.getId());
                        throw new Exception("ReservationAppEventProcessor - Event " + eventType + " has failed");
                    }
                } else {
                    log.info("Invalid Hertz Rental Company", new Object() {
                    }.getClass().getEnclosingMethod().getName());
                }
            } else {
                log.info("ReservationAppEventProcessor - Event Type " + eventType + " is not valid", new Object() {
                }.getClass().getEnclosingMethod().getName());
            }
        } catch (Exception e) {
            log.error("Error ReservationAppEventProcessor -", new Object() {
            }.getClass().getEnclosingMethod().getName(), e);
            throw e;
        }
    }

    private String findAppEventType(Message message, Exchange exchange) {
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
        log.info("Entered the findAppEventType" + message.getHeader("type", String.class), "findAppEventType");
        return Optional.ofNullable(message.getHeader("type", String.class))
                .filter(StringUtils::isNotBlank)
                .map(s -> s.replace("com.guidewire.iscc.", ""))
                .orElseThrow(() -> new IllegalStateException("ReservationAppEventProcessor - Event type header was not set on the message."));
    }

}
