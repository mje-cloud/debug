package acc.hertz.security.authorization;

import acc.hertz.util.AppProperty;
import gw.api.ig.GwUtilities;
import org.apache.camel.Exchange;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.inject.Singleton;
import java.util.Base64;
import java.util.Optional;

@Singleton
@Named
public class CloudAuthorizer implements IAuthorizer {

    @Inject
    private AppProperty properties;
    public String getTSDAuthToken() {
        StringBuilder basic = new StringBuilder();
        basic.append(properties.getUserNameTSD())
             .append(":")
             .append(properties.getPasswordTSD());
        return AuthorizationType.TSD_TOKEN_ACCESS.getName() + " " +  Base64.getEncoder().encodeToString((basic.toString()).getBytes());
    }

    @Override
    public String getCCDetailedAuthToken(Exchange exchange) {
       var gwUtilities = GwUtilities.get(exchange.getContext());
       Optional<String> accessToken = gwUtilities.getAuthUtils().getAccessToken(properties.getIgAppLowerPlanet(), properties.getIgAppGWCP(),properties.getIgAppTenant());
        return AuthorizationType.CLOUD_DETAILED_ACCESS.getName() + " " + accessToken.get();
    }

}