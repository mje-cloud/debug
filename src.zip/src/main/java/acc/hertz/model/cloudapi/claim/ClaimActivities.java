package acc.hertz.model.cloudapi.claim;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClaimActivities {

    @JsonProperty("count")
    private int count;

    @JsonProperty("data")
    private List<Data> data;

    @JsonProperty("links")
    private Links links;

    // Getters and Setters
    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public List<Data> getData() {
        return data;
    }

    public void setData(List<Data> data) {
        this.data = data;
    }

    public Links getLinks() {
        return links;
    }

    public void setLinks(Links links) {
        this.links = links;
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Data {

        @JsonProperty("attributes")
        private Attributes attributes;

        // Getters and Setters
        public Attributes getAttributes() {
            return attributes;
        }

        public void setAttributes(Attributes attributes) {
            this.attributes = attributes;
        }
        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Attributes {

            @JsonProperty("activityPattern")
            private String activityPattern;

            @JsonProperty("id")
            private String id;

            @JsonProperty("status")
            private Status status;
            @JsonProperty("assignmentStatus")
            private AssignmentStatus assignmentStatus;
            public AssignmentStatus getAssignmentStatus() {
                return assignmentStatus;
            }

            public void setAssignmentStatus(AssignmentStatus assignmentStatus) {
                this.assignmentStatus = assignmentStatus;
            }



            // Getters and Setters
            public String getActivityPattern() {
                return activityPattern;
            }

            public void setActivityPattern(String activityPattern) {
                this.activityPattern = activityPattern;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public Status getStatus() {
                return status;
            }

            public void setStatus(Status status) {
                this.status = status;
            }
            @JsonIgnoreProperties(ignoreUnknown = true)
            @JsonInclude(JsonInclude.Include.NON_NULL)
            public static class Status {

                @JsonProperty("code")
                private String code;

                // Getters and Setters
                public String getCode() {
                    return code;
                }

                public void setCode(String code) {
                    this.code = code;
                }
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            @JsonInclude(JsonInclude.Include.NON_NULL)
            public static class AssignmentStatus {

                @JsonProperty("code")
                private String code;

                // Getters and Setters
                public String getCode() {
                    return code;
                }

                public void setCode(String code) {
                    this.code = code;
                }
            }
        }
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Links {

        @JsonProperty("first")
        private Link first;

        @JsonProperty("next")
        private Link next;

        @JsonProperty("self")
        private Link self;

        // Getters and Setters
        public Link getFirst() {
            return first;
        }

        public void setFirst(Link first) {
            this.first = first;
        }

        public Link getNext() {
            return next;
        }

        public void setNext(Link next) {
            this.next = next;
        }

        public Link getSelf() {
            return self;
        }

        public void setSelf(Link self) {
            this.self = self;
        }
        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Link {

            @JsonProperty("href")
            private String href;

            @JsonProperty("methods")
            private List<String> methods;

            // Getters and Setters
            public String getHref() {
                return href;
            }

            public void setHref(String href) {
                this.href = href;
            }

            public List<String> getMethods() {
                return methods;
            }

            public void setMethods(List<String> methods) {
                this.methods = methods;
            }
        }
    }
}