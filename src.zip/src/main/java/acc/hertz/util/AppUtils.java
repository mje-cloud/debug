package acc.hertz.util;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;
public class AppUtils {
    public static final String COMPOSITE_API_REST_PATH = "/rest/";
    public static final String API_X_GWRE_SESSION = "x-gwre-session";
    public static final String COMPOSITE_CREATE = "/rest/composite/v1/composite";
    public static final String SEARCH_LOCATION_SERVICE_TITLE = "Location Search";
    public static final String SEARCH_LOCATION_SERVICE = "location/search";
    public static final String ASSIGNMENT_SERVICE_TITLE = "Assignment";
    public static final String ASSIGNMENT_SERVICE = "assignment";
    public static final String ROUTE_ROOT_PATH = "/cc/rest/acc/hertz/v1";
    public static final String API_CONTENT_DISPOSITION= "Content-Disposition";
    public static final String API_CONTENT_TYPE= "Content-Type";
    public static final String X_GWRE_SESSION = "x-gwre-session";
    public static final String AUTHORIZATION= "Authorization";
    public static final String MSG_SOURCE ="MSGSource";
    public static final String MSG_SOURCE_AUTHENTICATION = "MSGSourceAuthentication";
    public static final String MSG_SOURCE_GROUP = "MSGSourceGroup";
    public static final String CLOUD_API_CLAIMS_GET ="/rest/claim/v1/claims/";
    public static final String CLOUD_API_CLAIMS_PUBLIC ="/rest/claim/v1/claims";
    public static final String CLOUD_API_DOCUMENT_CREATION ="/rest/claim/v1/claims/$1/documents";
     public static final String CLOUD_API_DOCUMENT_GET = "/rest/claim/v1/claims/$1/documents";
    public static final String CLOUD_API_SERVICE_REQUEST_GET ="/rest/claim/v1/claims/$1/service-requests";
    public static final String CLOUD_API_SERVICE_REQUEST_POST ="/rest/claim/v1/claims/$1/service-requests";
    public static final String CLOUD_API_SERVICE_REQUEST_INVOICE_POST ="/rest/claim/v1/claims/$1/service-requests/$2/invoices";
    public static final String CLOUD_API_SERVICE_REQUEST_SUBMIT ="/rest/claim/v1/claims/$1/service-requests/$2/submit";
    public static final String CLOUD_API_SERVICE_REQUEST_CANCEL="/rest/claim/v1/claims/$1/service-requests/$2/cancel";
    public static final String CLOUD_API_SERVICE_REQUEST_DECLINE="/rest/claim/v1/claims/$1/service-requests/$2/decline";
    public static final String CLOUD_API_SERVICE_REQUEST_WORK_COMPLETED ="/rest/claim/v1/claims/$1/service-requests/$2/complete-work";
    public static final String CLOUD_API_SERVICE_REQUEST_ACCEPT ="/rest/claim/v1/claims/$1/service-requests/$2/accept";
    public static final String CLOUD_API_CLAIM_CONTACT_REQUEST_GET ="/rest/claim/v1/claims/$1/contacts/$2";
    public static final String CLOUD_API_CLAIM_CONTACT_REQUEST_POST ="/rest/claim/v1/claims/$1/contacts/";
    public static final String CLOUD_API_ASSIGNED_USER_REQUEST_GET ="/rest/admin/v1/users/$1";
    public static final String CLOUD_API_TYPE_LIST_REQUEST_GET = "/rest/common/v1/typelists/$1";
    public static final String CLOUD_API_SERVICE_REQUEST_PATCH ="/rest/claim/v1/claims/$1/service-requests/$2";
    public static final String ROUTE_ID_LOCATION_SEARCH_WEB_SERVICE ="direct:LocationSearchWebService";
    public static final String CLAIM_POST_ACTIVITIES="/rest/claim/v1/claims/$1/activities";
    public static final String CLOUD_API_CREATE_HISTORY_ENTRY ="/rest/common/v1/hertz-rental-status-history-accs-ext";
    public static final String ROUTE_ID_RENTAL_WEB_SERVICE ="direct:RentalWebService";
	public static final String CLOUD_API_CREATE_VENDOR_CONTACT_REQUEST_POST ="/rest/coop/claim-ext/v1/$1/create-rentalvendor-ext";
    public static String sanitize(String input) {
        // Initialize the sanitized string with the input
        String sanitizedString = input;
        // Check if the input is null or empty
        if (sanitizedString == null || sanitizedString.isEmpty()) {
            return "";
        }
        sanitizedString = sanitizedString.replace("\n", "").replace("\r","").replace("\t", "");
        // Define the first pattern to match invalid Unicode characters
        Pattern pattern = Pattern.compile("[^\\u0009\\u000A\\u000D\\u0020-\\uD7FF\\uE000-\\uFFFD\\x{10000}-\\x{10FFFF}]");
        // Replace invalid Unicode characters with an empty string
        sanitizedString = pattern.matcher(sanitizedString).replaceAll("");
        // Define the second pattern to match the special characters (*, ?, <, >)
        pattern = Pattern.compile("(\\*)|(\\?)|(\\<)|(\\>)");
        // Replace the special characters with an empty string
        return pattern.matcher(sanitizedString).replaceAll("");
    }

    public static String stringSizeRefactoring(String value ,int size )  {
        if(value == null)
            return "";

        if(value.length() > size){
            return value.substring(0, size -1);
        }
        return value;
    }

   public static String getValidStringValue(String value )  {
        if(value == null)
            return "";
        return value;
    }

    public static String getDateISO8601(String inputDate )  {
        DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        DateTimeFormatter formatterISO = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

        try {
            LocalDate localDate = LocalDate.parse(inputDate, formatter1);
            return localDate.atStartOfDay().atOffset(ZoneOffset.UTC).format(DateTimeFormatter.ISO_DATE_TIME);
        } catch (Exception ignored) {
            try {
                LocalDateTime localDateTime = LocalDateTime.parse(inputDate, formatterISO);
                return localDateTime.atOffset(ZoneOffset.UTC).format(DateTimeFormatter.ISO_DATE_TIME);
            } catch (Exception ignoredFormatter) {
                return inputDate;
            }
        }
    }

    public static String getValidIdentifierToFilter(String value )  {
        return value.replace(":","::");
    }

    public static String getValidCurrencyAmount(String value){
        if(value == null || value == "")
            return "0";

        double valueConvert = Double.parseDouble(value);
        return String.format("%.2f", valueConvert);
    }
}