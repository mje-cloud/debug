package acc.hertz.model.hertz.shared;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class RepairOrder {

    @JsonProperty("Status")
    private String status;

    @JsonProperty("OrderId")
    private String orderId;

    @JsonProperty("AppointmentDate")
    private String appointmentDate;

    @JsonProperty("ActualStartDate")
    private String actualStartDate;

    @JsonProperty("CreateDate")
    private String createDate;

    @JsonProperty("EstimatedCompleteDate")
    private Date estimatedCompleteDate;

    @JsonProperty("ActualCompleteDate")
    private String actualCompleteDate;

    @JsonProperty("DeliveryDate")
    private String deliveryDate;

    @JsonProperty("StatusMessage")
    private String statusMessage;

    @JsonProperty("ContactEmail")
    private String contactEmail;

    @JsonProperty("ContactFirstName")
    private String contactFirstName;

    @JsonProperty("ContactLastName")
    private String contactLastName;

    @JsonProperty("ContactPhone")
    private String contactPhone;

}
