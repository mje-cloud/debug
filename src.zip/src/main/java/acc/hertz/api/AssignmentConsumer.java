package acc.hertz.api;

import acc.hertz.model.hertz.outbound.BaseHertzRequest;
import acc.hertz.model.hertz.outbound.BaseHertzResponse;
import acc.hertz.process.*;
import gw.api.ig.GwUtilities;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;



@Named
public class AssignmentConsumer implements IAssignment {

    @Inject
    private WalkUpOpenProcess walkUpOpenProcess;
    @Inject
    private ReactiveExtensionProcess reactiveExtensionProcess;

    @Inject
    private RentalOpenProcess rentalOpenProcess;

    @Inject
    private RentalCloseProcess rentalCloseProcess;

    @Inject
    private RentalCancelProcess rentalCancelProcess;

    @Inject
    private RentalInvoiceProcess rentalInvoiceProcess;

    @Inject
    private RentalStatusChangeProcess rentalStatusChangeProcess;


    public BaseHertzResponse createWalkUpOpenProcess(BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception {
        BaseHertzResponse response;
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
            try {
                response = walkUpOpenProcess.processNewReservation(baseHertzRequest, exchange);
            } catch (Exception e) {
                log.error(" There is an error trying process walkUp Open" , "createRentalOpen", e);
                throw e;
            }
        return response;
    }

    public  BaseHertzResponse reactiveExtension(BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception {
        BaseHertzResponse response;
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
            try {
                response = reactiveExtensionProcess.processReactiveExtension(baseHertzRequest, exchange);
            } catch (Exception e) {
                log.error(" There is an error trying process reactiveExtension" , "reactiveExtension", e);
                throw e;
            }
        return response;
    }

    public  BaseHertzResponse rentalOpenStatusChange( BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception {
        BaseHertzResponse response = null;
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
        try{
            response = rentalOpenProcess.processRentalOpen(baseHertzRequest,exchange);
        }catch(Exception e){
            log.error(" There is an error trying process rental Open " , "rentalOpenStatusChange", e);
            throw  e;
        }
        return response;
    }

    public  BaseHertzResponse rentalCloseStatusChange( BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception {
        BaseHertzResponse response = null;
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
        try{
            response = rentalCloseProcess.processRentalClose(baseHertzRequest,exchange);
        }catch(Exception e){
            log.error(" There is an error trying process rentalCloseStatusChange" , "rentalCloseStatusChange", e);
            throw  e;
        }
        return response;
    }

    public  BaseHertzResponse rentalCancellationStatusChange( BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception {
        BaseHertzResponse response = null;
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
        try{
            response = rentalCancelProcess.processRentalCancel(baseHertzRequest,exchange);
        }catch(Exception e){
            log.error(" There is an error trying process rentalCancellationStatusChange" , "rentalCancellationStatusChange", e);
            throw  e;
        }
        return response;
    }


    public  BaseHertzResponse createInvoice( BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception {
        BaseHertzResponse response = null;
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
        try{
            response = rentalInvoiceProcess.processRentalInvoice(baseHertzRequest,exchange);
        }catch(Exception e){
            log.error(" There is an error trying process createInvoice" , "createInvoice", e);
            throw  e;
        }
        return response;
    }

    @Override
    public BaseHertzResponse rentalStatusChange(BaseHertzRequest baseHertzRequest, Exchange exchange) throws Exception {
        BaseHertzResponse response = null;
        var log = GwUtilities.get(exchange.getContext()).getLogUtils();
        try{
            response = rentalStatusChangeProcess.processRentalStatusChange(baseHertzRequest,exchange);
        }catch(Exception e){
            log.error(" There is an error trying process rental StatusChange" , "rentalStatusChange", e);
            throw  e;
        }
        return response;
    }
}
