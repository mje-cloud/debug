package acc.hertz.route.base.types.appevent;



import acc.hertz.route.base.AbstractRouteBuilder;
import acc.hertz.util.AppProperty;

import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named
public abstract class AbstractAppEventRouteBuilder extends AbstractRouteBuilder {
    @Inject
    private AppProperty property;
    public AbstractAppEventRouteBuilder(){
       super();
    }


    protected abstract void setupAppEvent();
    @Override
    public void configure() {
        setupAppEvent();
    }

}
