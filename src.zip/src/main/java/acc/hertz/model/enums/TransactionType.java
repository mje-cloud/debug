
package acc.hertz.model.enums;

public enum TransactionType {
  LOCATION_SEARCH("locationsearch", "Get Location Search", "LocationSearch"),
  NEW_ASSIGNMENT("newassignment", "New Service Request createdNew", "NewAssignment"),
  AUTH_UPDATE("authupdate", "Authenticate the user and password", "AuthUpdate"),
  CANCEL("cancel", "Cancel a reservation", "Cancel"),
  REQUEST_AUTH("requestauth", "Authenticate the user and password", "RequestAuth"),
  RENTAL_OPEN("rentalopen", "Open Rental Agreement", "RentalOpen"),
  STATUS_CHANGE("statuschange", "Update the service request", "StatusChange"),
  STATUS_CANCEL("statuscancel", "Cancel Reservation", "StatusCancel"),
  RENTAL_CLOSE("rentalclose", "Move a rental car request to Close from Hertz to ClaimCenter", "RentalClose"),
  SUBMIT_INVOICE("submitinvoice", "Receive invoice document", "SubmitInvoice");

  private final String code;
  private final String description;
  private final String name;

  TransactionType(String code, String description, String name) {
    this.code = code;
    this.description = description;
    this.name = name;
  }

  public String getCode() {
    return code;
  }

  public String getDescription() {
    return description;
  }

  public String getName() {
    return name;
  }

  public static TransactionType fromCode(String code) {
    for (TransactionType type : values()) {
      if (type.code.equalsIgnoreCase(code)) {
        return type;
      }
    }
    throw new IllegalArgumentException("Unknown code: " + code);
  }
}

