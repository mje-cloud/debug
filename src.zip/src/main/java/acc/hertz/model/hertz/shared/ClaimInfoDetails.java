package acc.hertz.model.hertz.shared;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class ClaimInfoDetails {
    @JsonProperty("Id")
    private String id;

    @JsonProperty("Type")
    private String type;

    @JsonProperty("DriverFirstName")
    private String driverFirstName;

    @JsonProperty("DriverLastName")
    private String driverLastName;

    @JsonProperty("LossDate")
    private String lossDate;

    @JsonProperty("ClaimVehicleCondition")
    private String claimVehicleCondition;

    @JsonProperty("ClaimVehicleColor")
    private String claimVehicleColor;

    @JsonProperty("ClaimVehicleID")
    private String claimVehicleId;

    @JsonProperty("ClaimVehicleMake")
    private String claimVehicleMake;

    @JsonProperty("ClaimVehicleModel")
    private String claimVehicleModel;

    @JsonProperty("ClaimVehicleYear")
    private String claimVehicleYear;

    @JsonProperty("DriverPhone")
    private String driverPhone;

    @JsonProperty("DriverPhoneExt")
    private String driverPhoneExt;

    @JsonProperty("DriverZIP")
    private String driverZip;

    @JsonProperty("DriverStreet1")
    private String driverStreet1;

    @JsonProperty("DriverStreet2")
    private String driverStreet2;

    @JsonProperty("DriverCity")
    private String driverCity;

    @JsonProperty("DriverState")
    private String driverState;

    @JsonProperty("DriverCountry")
    private String driverCountry;

    @JsonProperty("PayDailyAmount")
    private double payDailyAmount;

    @JsonProperty("PayTaxes")
    private String payTaxes;

    @JsonProperty("PayTotalBill")
    private String payTotalBill;

    @JsonProperty("RentalDailyAmount")
    private double rentalDailyAmount;

    @JsonProperty("TotalDays")
    private int totalDays;

    @JsonProperty("RentalRequestedClass")
    private String rentalRequestedClass;

    @JsonIgnoreProperties("ClaimNoteRentalInstructions")
    private String claimNoteRentalInstructions;

    @JsonProperty("IncrementalDays")
    private int incrementalDays;

    @JsonProperty("FRPflag")
    private boolean frpFlag;

    @JsonProperty("AuthFinalDate")
    private String authFinalDate;

    @JsonProperty("AdditionalCharges")
    private List<AdditionalCharges> additionalCharges;

}
