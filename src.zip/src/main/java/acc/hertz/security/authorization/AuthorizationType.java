package acc.hertz.security.authorization;

public enum AuthorizationType {
    TSD_TOKEN_ACCESS("basic","Basic"),

    CLOUD_DETAILED_ACCESS("bearer","Bearer"),
    NO_AUTHORIZATION_ACCESS("no","no");
    private String code,name;

    private AuthorizationType(String code, String name) {
        this.code = code; this.name=name;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String toString() {
        return String.valueOf(code);
    }

    public static AuthorizationType fromCode(String code) {
        for ( AuthorizationType b : AuthorizationType.values()) {
            if (b.getCode().equals(code)) {
                return b;
            }
        }
        return null;
    }

    public static AuthorizationType fromName(String name) {
        for ( AuthorizationType b : AuthorizationType.values()) {
            if (b.getName().equals(name)) {
                return b;
            }
        }
        return null;
    }

}
