package acc.hertz.client.service;


import acc.hertz.model.cloudapi.history.History;
import org.apache.camel.Exchange;

public interface IHistoryClient {
    boolean createHistoryEntry(Exchange exchange, String stickySessionToken,History body) throws Exception;


}
