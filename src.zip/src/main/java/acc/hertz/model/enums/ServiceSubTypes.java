package acc.hertz.model.enums;

public enum ServiceSubTypes {
    AUTO_RENTAL("autootherrental");

    private final String type;

    ServiceSubTypes(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public static ServiceSubTypes fromType(String type) {
        for (ServiceSubTypes requestType : values()) {
            if (requestType.getType().equals(type)) {
                return requestType;
            }
        }
        throw new IllegalArgumentException("Unknown Type: " + type);
    }
}
