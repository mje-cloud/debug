package acc.hertz.model.cloudapi.servicerequest;

import acc.hertz.model.cloudapi.claim.AssignedUser;
import acc.hertz.model.cloudapi.claim.User;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class ServiceRequestList {
   @JsonProperty("count")
   private int count;
    @JsonProperty("data")
    private List<ServiceRequest> data;

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class ServiceRequest {

        @JsonProperty("attributes")
        private Attributes attributes;

        @JsonProperty("checksum")
        private String checksum;

        @JsonProperty("links")
        private Map<String, Link> links;

        public Attributes getAttributes() {
            return attributes;
        }

        public void setAttributes(Attributes attributes) {
            this.attributes = attributes;
        }

        public String getChecksum() {
            return checksum;
        }

        public void setChecksum(String checksum) {
            this.checksum = checksum;
        }

        public Map<String, Link> getLinks() {
            return links;
        }

        public void setLinks(Map<String, Link> links) {
            this.links = links;
        }
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Attributes {
        @JsonProperty("hertzRequestType_Ext")
        private boolean hertzRequestType_Ext;
        @JsonProperty("hertzLicensePlate_Ext")
        private String hertzLicensePlate_Ext;
        @JsonProperty("hertzModel_Ext")
        private String hertzModel_Ext;
        @JsonProperty("hertzMake_Ext")
        private String hertzMake_Ext;
        @JsonProperty("hertzColor_Ext")
        private String hertzColor_Ext;
        @JsonProperty("hertzYear_Ext")
        private String hertzYear_Ext;

        @JsonProperty("assignedGroup")
        private Entity assignedGroup;

        @JsonProperty("assignedUser")
        private Entity assignedUser;

        @JsonProperty("assignmentDate")
        private String assignmentDate;
        @JsonProperty("canceledReason")
        private String canceledReason;

        @JsonProperty("assignmentDateTime")
        private String assignmentDateTime;
        @JsonProperty("incident")
        private Entity incident;
        @JsonProperty("claim")
        private Entity claim;

        @JsonProperty("createTime")
        private String createTime;

        @JsonProperty("expectedQuoteCompletionDate")
        private String expectedQuoteCompletionDate;

        @JsonProperty("expectedQuoteCompletionDateTime")
        private String expectedQuoteCompletionDateTime;

        @JsonProperty("externalStatus")
        private CodeName externalStatus;

        @JsonProperty("hertzLossDamageWaiver_Ext")
        private boolean hertzLossDamageWaiver_Ext;


        @JsonProperty("hertzWinterTires_Ext")
        private boolean hertzWinterTires_Ext;

        @JsonProperty("hertzPayAllTaxes_Ext")
        private boolean hertzPayAllTaxes_Ext;

        @JsonProperty("hertzPercentagePay_Ext")
        private String hertzPercentagePay_Ext;

        @JsonProperty("hertzRentalCompany_Ext")
        private CodeName hertzRentalCompany_Ext;

        @JsonProperty("hertzRentalRole_Ext")
        private CodeName hertzRentalRole_Ext;

        @JsonProperty("hertzRentalDailyAmount_Ext")
        private Amount hertzRentalDailyAmount_Ext;

        @JsonProperty("hertzTotalDaysApproved_Ext")
        private int hertzTotalDaysApproved_Ext;

        @JsonProperty("hertzRentalVehicle_Ext")
        private Entity hertzRentalVehicle_Ext;

        @JsonProperty("hertzBestTimeToPickup_Ext")
        private String hertzBestTimeToPickup_Ext;
        @JsonProperty("hertzClassCode_Ext")
        private String hertzClassCode_Ext;
        @JsonProperty("hertzRateType_Ext")
        private CodeName hertzRateType_Ext;
        @JsonProperty("hertzRentalBeginDate_Ext")
        private String hertzRentalBeginDate_Ext;

        @JsonProperty("hertzRentalEndDate_Ext")
        private String hertzRentalEndDate_Ext;

        @JsonProperty("hertzRateClass_Ext")
        private String hertzRateClass_Ext;
        @JsonProperty("hertzIncrementalDays_Ext")
        private int hertzIncrementalDays_Ext;
        @JsonProperty("hertzPickupDate_Ext")
        private String hertzPickupDate_Ext;

        @JsonProperty("hertzRateInclusivePrice_Ext")
        private Amount hertzRateInclusivePrice_Ext;
        @JsonProperty("hertzMaxAuthAmount_Ext")
        private Amount hertzMaxAuthAmount_Ext;
        @JsonProperty("hertzTransactionTSDID_Ext")
        private String hertzTransactionTSDID_Ext;

        @JsonProperty("hertzTransactionGUID_Ext")
        private String hertzTransactionGUID_Ext;
        @JsonProperty("hertzTransactionContractID_Ext")
        private String hertzTransactionContractID_Ext;
        @JsonProperty("hertzCustomerSelfPay_Ext")
        private boolean hertzCustomerSelfPay_Ext;

        @JsonProperty("hertzVehicleCondition_Ext")
        private String hertzVehicleCondition_Ext;

        @JsonProperty("hertzFinalDay_Ext")
        private String hertzFinalDay_Ext;

        @JsonProperty("hertzDrivable_Ext")
        private boolean hertzDrivable_Ext;

        @JsonProperty("hertzDaysForCarRental_Ext")
        private int hertzDaysForCarRental_Ext;


        @JsonProperty("hertzDayCount_Ext")
        private int hertzDayCount_Ext;
        @JsonProperty("id")
        private String id;

        @JsonProperty("instruction")
        private Instruction instruction;

        @JsonProperty("kind")
        private CodeName kind;

        @JsonProperty("latestQuote")
        private LatestQuote latestQuote;

        @JsonProperty("nextStep")
        private CodeName nextStep;

        @JsonProperty("progress")
        private CodeName progress;

        @JsonProperty("hertzContractStatus_Ext")
        private CodeName hertzContractStatus_Ext;

        @JsonProperty("hertzDateType_Ext")
        private CodeName hertzDateType_Ext;

        @JsonProperty("quoteStatus")
        private CodeName quoteStatus;

        @JsonProperty("hertzClassName_Ext")
        private String hertzClassName_Ext;
        @JsonProperty("requestedQuoteCompletionDate")
        private String requestedQuoteCompletionDate;

        @JsonProperty("requestedQuoteCompletionDateTime")
        private String requestedQuoteCompletionDateTime;

        @JsonProperty("serviceRequestNumber")
        private String serviceRequestNumber;

        @JsonProperty("specialist")
        private Entity specialist;

        @JsonProperty("exposure")
        private Entity exposure;

        @JsonProperty("specialistCommMethod")
        private CodeName specialistCommMethod;

        @JsonProperty("tier")
        private CodeName tier;

        @JsonProperty("expectedServiceCompletionDateTime")
        private String expectedServiceCompletionDateTime;
        @JsonProperty("expectedServiceCompletionDate")
        private String expectedServiceCompletionDate;

        @JsonProperty("hertzRepairFacility_Ext")
        private Entity hertzRepairFacility_Ext;
        @JsonProperty("hertzSendEmail_Ext")
        private boolean hertzSendEmail_Ext;

        @JsonProperty("hertzRentalLocation_Ext")
        private Entity hertzRentalLocation_Ext;

        @JsonProperty("hertzAdjuster_Ext")
        private Entity hertzAdjuster_Ext;

        // Add getters and setters for all fields here
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Entity {

        @JsonProperty("displayName")
        private String displayName;

        @JsonProperty("id")
        private String id;

        @JsonProperty("type")
        private String type;

        @JsonProperty("uri")
        private String uri;

        // Add getters and setters for all fields here
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class CodeName {

        @JsonProperty("code")
        private String code;

        @JsonProperty("name")
        private String name;

        // Add getters and setters for all fields here
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Instruction {

        @JsonProperty("customer")
        private Entity customer;

        @JsonProperty("id")
        private String id;

        @JsonProperty("instructionText")
        private String instructionText;

        @JsonProperty("serviceAddress")
        private ServiceAddress serviceAddress;

        @JsonProperty("services")
        private List<Service> services;

        // Add getters and setters for all fields here
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class ServiceAddress {

        @JsonProperty("addressLine1")
        private String addressLine1;

        @JsonProperty("city")
        private String city;

        @JsonProperty("country")
        private String country;

        @JsonProperty("displayName")
        private String displayName;

        @JsonProperty("id")
        private String id;

        @JsonProperty("policyAddress")
        private boolean policyAddress;

        @JsonProperty("postalCode")
        private String postalCode;

        @JsonProperty("state")
        private CodeName state;

        // Add getters and setters for all fields here
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Service {

        @JsonProperty("active")
        private boolean active;

        @JsonProperty("code")
        private String code;

        @JsonProperty("description")
        private String description;

        @JsonProperty("id")
        private String id;

        @JsonProperty("name")
        private String name;

        @JsonProperty("parent")
        private CodeName parent;

        // Add getters and setters for all fields here
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class LatestQuote {

        @JsonProperty("creationTime")
        private String creationTime;

        @JsonProperty("description")
        private String description;

        @JsonProperty("expectedDaysToPerformService")
        private int expectedDaysToPerformService;

        @JsonProperty("id")
        private String id;

        @JsonProperty("lineItems")
        private List<LineItem> lineItems;

        @JsonProperty("referenceNumber")
        private String referenceNumber;

        @JsonProperty("subtype")
        private CodeName subtype;

        @JsonProperty("total")
        private Amount total;

        // Add getters and setters for all fields here
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class LineItem {

        @JsonProperty("amount")
        private Amount amount;

        @JsonProperty("description")
        private String description;

        @JsonProperty("id")
        private String id;

        // Add getters and setters for all fields here
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Amount {

        @JsonProperty("amount")
        private String amount;

        @JsonProperty("currency")
        private String currency;

        // Add getters and setters for all fields here
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Link {

        @JsonProperty("href")
        private String href;

        @JsonProperty("methods")
        private List<String> methods;

        // Add getters and setters for all fields here
    }
}

