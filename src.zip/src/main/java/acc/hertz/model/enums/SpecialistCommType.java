package acc.hertz.model.enums;

public enum SpecialistCommType {
    THIRD_PARTY_PORTAL("otherportal","Third-party Portal");

    private final String code;

    public String getName() {
        return name;
    }

    private final String name;

    SpecialistCommType(String code, String name) {
        this.code = code;
        this.name=name;
    }

    public String getCode() {
        return code;
    }

    public static SpecialistCommType fromType(String type) {
        for (SpecialistCommType requestType : values()) {
            if (requestType.getCode().equals(type)) {
                return requestType;
            }
        }
        throw new IllegalArgumentException("Unknown Type: " + type);
    }
}
