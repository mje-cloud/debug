package acc.hertz.model.cloudapi.servicerequest;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "data"
})
public class ServiceRequestPatch {
    @JsonProperty("data")
    private Data data;

    // Constructor, getters, and setters
    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonPropertyOrder({
            "attributes"
    })
    @Setter
    @Getter
    public static class Data {
        @JsonProperty("attributes")
        private Attributes attributes;

        // Constructor, getters, and setters
        public Attributes getAttributes() {
            return attributes;
        }

        public void setAttributes(Attributes attributes) {
            this.attributes = attributes;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Setter
        @Getter
        public static class Attributes {

            @JsonProperty("hertzRequestType_Ext")
            private boolean hertzRequestType_Ext;
            @JsonProperty("hertzTransactionGUID_Ext")
            private String hertzTransactionGUID_Ext;

            @JsonProperty("hertzTransactionTSDID_Ext")
            private String hertzTransactionTSDID_Ext;
            @JsonProperty("hertzTransactionContractID_Ext")
            private String hertzTransactionContractID_Ext;

            @JsonProperty("hertzFinalDay_Ext")
            private String hertzFinalDay_Ext;

            @JsonProperty("hertzContractStatus_Ext")
            private CodeName hertzContractStatus_Ext;

            @JsonProperty("hertzTotalDaysApproved_Ext")
            private int hertzTotalDaysApproved_Ext;

            @JsonProperty("hertzIncrementalDays_Ext")
            private int hertzIncrementalDays_Ext;
            @JsonProperty("hertzRentalEndDate_Ext")
            private String hertzRentalEndDate_Ext;
        }
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class CodeName {

        @JsonProperty("code")
        private String code;

        @JsonProperty("name")
        private String name;

    }
}
