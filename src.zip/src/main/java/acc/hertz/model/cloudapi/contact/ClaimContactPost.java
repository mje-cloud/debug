package acc.hertz.model.cloudapi.contact;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class ClaimContactPost {
    @JsonProperty("data")
    private Data data;
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Data {
        @JsonProperty("attributes")
        private Attributes attributes;
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class Attributes {
        @JsonProperty("companyName")
        private String companyName;

        @JsonProperty("contactSubtype")
        private String contactSubtype;

        @JsonProperty("editableRoles")
        private List<EditableRole> editableRoles;

        @JsonProperty("hertzIDStoreOffice_Ext")
        private String hertzIDStoreOffice_Ext;

        @JsonProperty("primaryAddress")
        private PrimaryAddress primaryAddress;

        @JsonProperty("workPhone")
        private WorkPhone workPhone;
        @JsonProperty("emailAddress1")
        private String emailAddress1;
        @JsonProperty("taxId")
        private String taxId;

    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class EditableRole {
        @JsonProperty("active")
        private boolean active;

        @JsonProperty("relatedTo")
        private RelatedTo relatedTo;
        @JsonProperty("role")
        private CodeName role;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class RelatedTo {
        @JsonProperty("id")
        private String id;

        @JsonProperty("type")
        private String type;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class PrimaryAddress {
        @JsonProperty("addressLine1")
        private String addressLine1;

        @JsonProperty("addressLine2")
        private String addressLine2;

        @JsonProperty("addressType")
        private CodeName addressType;

        @JsonProperty("city")
        private String city;

        @JsonProperty("country")
        private String country;

        @JsonProperty("postalCode")
        private String postalCode;

        @JsonProperty("state")
        private CodeName state;

        @JsonProperty("province")
        private CodeName province;
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class WorkPhone {
        @JsonProperty("countryCode")
        private CodeName countryCode;

        @JsonProperty("number")
        private String number;
    }
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Setter
    @Getter
    public static class CodeName {
        @JsonProperty("code")
        private String code;

        @JsonProperty("name")
        private String name;
    }
}
