package acc.hertz.model.cloudapi.claim;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Attributes {

    @JsonProperty("assignedUser")
    private AssignedUser assignedUser;

    @JsonProperty("claimNumber")
    private String claimNumber;

    @JsonProperty("description")
    private String description;

    @JsonProperty("id")
    private String id;

    @JsonProperty("incidentOnly")
    private boolean incidentOnly;

    @JsonProperty("insured")
    private Insured insured;

    @JsonProperty("lobCode")
    private LobCode lobCode;

    @JsonProperty("lossCause")
    private LossCause lossCause;

    @JsonProperty("lossDate")
    private String lossDate;

    @JsonProperty("lossLocation")
    private LossLocation lossLocation;

    @JsonProperty("lossType")
    private LossType lossType;

    @JsonProperty("mainContact")
    private MainContact mainContact;

    @JsonProperty("policyAddresses")
    private List<PolicyAddress> policyAddresses;

    @JsonProperty("policyNumber")
    private String policyNumber;

    @JsonProperty("reportedDate")
    private String reportedDate;

    @JsonProperty("state")
    private State state;

    @JsonProperty("CompanyName_Ext")
    private Company_CG companyName_Ext;

    public AssignedUser getAssignedUser() {
        return assignedUser;
    }

    public void setAssignedUser(AssignedUser assignedUser) {
        this.assignedUser = assignedUser;
    }

    public String getClaimNumber() {
        return claimNumber;
    }

    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

     public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isIncidentOnly() {
        return incidentOnly;
    }

    public void setIncidentOnly(boolean incidentOnly) {
        this.incidentOnly = incidentOnly;
    }

    public Insured getInsured() {
        return insured;
    }

    public void setInsured(Insured insured) {
        this.insured = insured;
    }

    public LobCode getLobCode() {
        return lobCode;
    }

    public void setLobCode(LobCode lobCode) {
        this.lobCode = lobCode;
    }

    public LossCause getLossCause() {
        return lossCause;
    }

    public void setLossCause(LossCause lossCause) {
        this.lossCause = lossCause;
    }

    public String getLossDate() {
        return lossDate;
    }

    public void setLossDate(String lossDate) {
        this.lossDate = lossDate;
    }

    public LossLocation getLossLocation() {
        return lossLocation;
    }

    public void setLossLocation(LossLocation lossLocation) {
        this.lossLocation = lossLocation;
    }

    public LossType getLossType() {
        return lossType;
    }

    public void setLossType(LossType lossType) {
        this.lossType = lossType;
    }

    public MainContact getMainContact() {
        return mainContact;
    }

    public void setMainContact(MainContact mainContact) {
        this.mainContact = mainContact;
    }

    public List<PolicyAddress> getPolicyAddresses() {
        return policyAddresses;
    }

    public void setPolicyAddresses(List<PolicyAddress> policyAddresses) {
        this.policyAddresses = policyAddresses;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getReportedDate() {
        return reportedDate;
    }

    public void setReportedDate(String reportedDate) {
        this.reportedDate = reportedDate;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public Company_CG getCompanyName_Ext() {
        return companyName_Ext;
    }

    public void setCompanyName_Ext(Company_CG companyName_Ext) {
        this.companyName_Ext = companyName_Ext;
    }



}


